#!/usr/bin/env node
/**
 * Local bridge — the one process that ties the pieces together.
 *
 *   browser UI  <-->  bridge  <-->  ESP32 sensor node (HTTP POST)
 *                       |
 *                       +--> the engineering engine (same code the CLI and tests use)
 *
 * Why a bridge instead of a pure browser app: the engine reads the vendor price book
 * from disk and writes cut lists and DXFs. Keeping one implementation means the file the
 * UI shows you is byte-identical to the file the CLI and the test suite produce.
 *
 * Everything is Node standard library. No dependencies, nothing to install, no cloud.
 * Binds to 127.0.0.1 by default so it is not exposed on the network unless asked.
 *
 *   BLOB_HOST=0.0.0.0 BLOB_NODE_TOKEN=secret node bridge/server.mjs
 */

import http from 'node:http';
import { readFile, writeFile, mkdir, readdir, stat } from 'node:fs/promises';
import { existsSync, readFileSync } from 'node:fs';
import {
  createProject,
  generateDesign,
  evaluateReality,
  exportPackage,
  loadProjectState
} from '../src/api/service.js';
import { extname, join, resolve, basename, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const OUT = join(ROOT, 'output');
const PORT = Number(process.env.PORT || 8787);
const HOST = process.env.BLOB_HOST || '127.0.0.1';
const NODE_TOKEN = process.env.BLOB_NODE_TOKEN || null;

const { runPipeline, dreamState } = await import(join(ROOT, 'src', 'pipeline.js'));
const { toCutListCSV, toNestedSVG, toDXF, toPackageJSON } = await import(join(ROOT, 'src', 'export', 'index.js'));
const { parseTelemetry, summariseWindow } = await import(join(ROOT, 'src', 'sensors', 'telemetry.js'));
const { reachabilityReport } = await import(join(ROOT, 'src', 'vendor', 'vendors.js'));

await mkdir(OUT, { recursive: true });

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.csv': 'text/csv; charset=utf-8',
  '.dxf': 'application/dxf',
  '.md': 'text/markdown; charset=utf-8',
  '.jsonl': 'application/x-ndjson'
};

const clients = new Set();
const telemetryLog = [];
let latestReading = null;

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  try {
    // --- Alpha spec v1.1 section 14: internal API contracts -------------------------------
    // Response envelopes match the spec exactly so a client written against the spec needs no
    // changes. Errors carry a machine-readable code plus the reason, never a bare 500.
    if (req.method === 'POST' && url.pathname === '/api/project/create') return await handleContract(req, res, (b) => createProject(b));
    if (req.method === 'POST' && url.pathname === '/api/design/generate') return await handleContract(req, res, (b) => generateDesign(b));
    if (req.method === 'POST' && url.pathname === '/api/reality/evaluate') return await handleContract(req, res, (b) => evaluateReality(b));
    if (req.method === 'POST' && url.pathname === '/api/export') return await handleContract(req, res, (b) => exportPackage(b));
    if (req.method === 'GET' && url.pathname.startsWith('/api/project/')) {
      const id = url.pathname.slice('/api/project/'.length);
      const state = loadProjectState(id);
      return state ? sendJSON(res, 200, state) : sendJSON(res, 404, { error: `unknown project "${id}"`, status: 404 });
    }

    if (req.method === 'POST' && url.pathname === '/api/run') return await handleRun(req, res);
    if (req.method === 'POST' && url.pathname === '/api/dream') return await handleDream(req, res);
    if (req.method === 'POST' && url.pathname === '/api/telemetry') return await handleTelemetry(req, res);
    if (req.method === 'GET' && url.pathname === '/api/stream') return handleStream(req, res);
    if (req.method === 'GET' && url.pathname === '/api/bootstrap') return await handleBootstrap(res);
    if (req.method === 'GET' && url.pathname === '/api/health') return sendJSON(res, 200, { ok: true, outputDir: OUT, nodeTokenRequired: !!NODE_TOKEN });
    if (req.method === 'GET' && url.pathname.startsWith('/api/output/')) return await handleOutput(url.pathname, res);
    if (req.method === 'GET') return await handleStatic(url.pathname, res);
    sendJSON(res, 405, { error: 'method not allowed' });
  } catch (err) {
    sendJSON(res, 500, { error: String(err && err.message), stack: process.env.BLOB_DEBUG ? err.stack : undefined });
  }
});

async function handleRun(req, res) {
  const body = await readJSON(req);
  if (!body || typeof body.utterance !== 'string' || !body.utterance.trim()) {
    return sendJSON(res, 400, { error: 'body must include a non-empty "utterance"' });
  }
  const options = {
    quantity: Number(body.quantity ?? 1),
    currency: body.currency || undefined,
    specOverrides: body.specOverrides || {},
    room: body.room || undefined
  };
  const result = runPipeline(body.utterance, options);
  const generatedAt = new Date().toISOString();

  // Same writers the CLI uses, so UI output and CLI output cannot drift apart.
  await writeFile(join(OUT, 'cut-list.csv'), toCutListCSV(result.cutList, { generatedAt }));
  await writeFile(join(OUT, 'nested-layout.dxf'), toDXF(result.cutList));
  await writeFile(join(OUT, 'nested-layout.svg'), toNestedSVG(result.cutList));
  await writeFile(join(OUT, 'package.json'), toPackageJSON(result, { generatedAt }));
  await writeFile(join(OUT, 'vendor-rfq.md'), renderRfq(result));
  await writeFile(join(OUT, 'cnc-quote-request.md'), renderCnc(result));

  const payload = toWire(result, generatedAt);
  await append(join(OUT, 'history.jsonl'), JSON.stringify({
    generatedAt,
    utterance: body.utterance,
    spec: result.cutList.spec,
    realityScore: result.reality.score,
    band: result.reality.band,
    costTotal: result.cost.total,
    currency: result.cost.currency,
    sheetCount: result.cutList.nesting.sheetCount,
    source: 'ui'
  }) + '\n');

  sendJSON(res, 200, payload);
}

async function handleDream(req, res) {
  const body = await readJSON(req);
  const result = dreamState(body?.utterance || 'build me a bookshelf', {
    specOverrides: body?.specOverrides || {},
    maxVariants: Math.min(24, Number(body?.maxVariants ?? 16))
  });
  await writeFile(join(OUT, 'dream-state.json'), JSON.stringify(result, null, 2));
  sendJSON(res, 200, result);
}

async function handleTelemetry(req, res) {
  if (NODE_TOKEN && req.headers['x-node-token'] !== NODE_TOKEN) {
    return sendJSON(res, 401, { error: 'bad or missing x-node-token' });
  }
  const raw = await readBody(req);
  const parsed = parseTelemetry(raw, {
    environment: loadEnvironmentSync()
  });
  if (!parsed.ok) return sendJSON(res, 422, { error: 'payload rejected', details: parsed.errors });

  latestReading = parsed;
  telemetryLog.push(parsed);
  if (telemetryLog.length > 500) telemetryLog.shift();
  await append(join(OUT, 'telemetry-history.jsonl'), JSON.stringify({ ...parsed, ingestedAt: new Date().toISOString() }) + '\n');
  broadcast('telemetry', { reading: parsed, window: summariseWindow(telemetryLog) });
  sendJSON(res, 202, { accepted: true, advisories: parsed.advisories.length });
}

function handleStream(req, res) {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    Connection: 'keep-alive'
  });
  res.write(`event: hello\ndata: ${JSON.stringify({ outputDir: OUT })}\n\n`);
  if (latestReading) res.write(`event: telemetry\ndata: ${JSON.stringify({ reading: latestReading, window: summariseWindow(telemetryLog) })}\n\n`);
  clients.add(res);
  const keepAlive = setInterval(() => res.write(': keep-alive\n\n'), 15000);
  req.on('close', () => {
    clearInterval(keepAlive);
    clients.delete(res);
  });
}

async function handleBootstrap(res) {
  const priceBook = JSON.parse(await readFile(join(ROOT, 'vendor', 'price-book.json'), 'utf8'));
  const services = JSON.parse(await readFile(join(ROOT, 'config', 'services.json'), 'utf8'));
  let outputs = [];
  try {
    const names = await readdir(OUT);
    outputs = await Promise.all(
      names.map(async (n) => ({ name: n, bytes: (await stat(join(OUT, n))).size }))
    );
  } catch { /* first run */ }

  const history = await readTail(join(OUT, 'history.jsonl'), 10);
  let latest = null;
  try {
    latest = JSON.parse(await readFile(join(OUT, 'latest.json'), 'utf8'));
  } catch { /* no run yet */ }

  sendJSON(res, 200, {
    root: ROOT,
    outputDir: OUT,
    priceBook: { asOf: priceBook.asOf, currency: priceBook.defaultCurrency, items: Object.keys(priceBook.items).length },
    services: services.services,
    reachability: reachabilityReport(),
    outputs,
    history,
    latest,
    latestReading,
    nodeTokenRequired: !!NODE_TOKEN,
    environment: loadEnvironmentSync()
  });
}

async function handleOutput(pathname, res) {
  const name = basename(decodeURIComponent(pathname.replace('/api/output/', '')));
  const file = join(OUT, name);
  if (!file.startsWith(OUT) || !existsSync(file)) return sendJSON(res, 404, { error: 'no such output' });
  const data = await readFile(file);
  res.writeHead(200, { 'Content-Type': MIME[extname(file)] || 'application/octet-stream', 'Content-Length': data.length });
  res.end(data);
}

async function handleStatic(pathname, res) {
  let rel = decodeURIComponent(pathname === '/' ? '/index.html' : pathname);
  const allowed = ['/index.html', '/src/', '/vendor/', '/config/', '/bridge/'];
  if (!allowed.some((a) => rel === a || rel.startsWith(a))) return sendJSON(res, 404, { error: 'not found' });
  const file = resolve(ROOT, '.' + rel);
  if (!file.startsWith(ROOT) || !existsSync(file)) return sendJSON(res, 404, { error: 'not found' });
  const data = await readFile(file);
  res.writeHead(200, { 'Content-Type': MIME[extname(file)] || 'text/plain; charset=utf-8', 'Content-Length': data.length });
  res.end(data);
}

// ---------------------------------------------------------------------------
function toWire(result, generatedAt) {
  return {
    generatedAt,
    utterance: result.utterance,
    intent: result.intent,
    spec: result.spec,
    stages: result.stages,
    form: result.form,
    roomCheck: result.roomCheck,
    reality: result.reality,
    materialDecision: result.materialDecision,
    cutList: {
      spec: result.cutList.spec,
      material: result.cutList.material,
      joinery: result.cutList.joinery,
      spanMm: result.cutList.spanMm,
      clearBayMm: result.cutList.clearBayMm,
      parts: result.cutList.parts,
      nesting: result.cutList.nesting,
      checks: result.cutList.checks,
      remedy: result.cutList.remedy,
      fasteners: result.cutList.fasteners,
      edgeBandingMm: result.cutList.edgeBandingMm,
      totalMassKg: result.cutList.totalMassKg,
      flags: result.cutList.flags,
      plan: result.cutList.plan,
      sheets: result.cutList.nesting.carcass.sheets
    },
    cost: result.cost,
    assembly: result.assembly,
    elevations: result.elevations,
    blob: result.blob,
    vendor: result.vendor,
    openQuestions: result.openQuestions,
    files: ['cut-list.csv', 'nested-layout.dxf', 'nested-layout.svg', 'package.json', 'vendor-rfq.md', 'cnc-quote-request.md']
  };
}

function renderRfq(r) {
  const rfq = r.vendor.rfq;
  return [
    `# RFQ — ${r.spec.widthMm} x ${r.spec.heightMm} x ${r.spec.depthMm} mm ${r.intent.kind}`,
    '',
    `To: ${rfq.to}`,
    rfq.supplierListingUrl ? `Supplier listing: ${rfq.supplierListingUrl}` : 'Supplier: not yet selected — pick one from vendor/sourcing-results.md',
    '',
    '```text',
    rfq.body,
    '```',
    '',
    `Attachments: ${rfq.attachments.join(', ')}`,
    ''
  ].join('\n');
}

function renderCnc(r) {
  return [
    '# Cut-to-size / CNC quote request',
    '',
    '```text',
    r.vendor.cnc.body,
    '```',
    '',
    '## Verified services that accept a DXF upload',
    ...r.vendor.cnc.services.map((s) => `- ${s.name} — ${s.url}`),
    ''
  ].join('\n');
}

function broadcast(event, data) {
  const chunk = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const c of clients) {
    try { c.write(chunk); } catch { clients.delete(c); }
  }
}

function sendJSON(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}

/**
 * Shared handler for the spec's contract endpoints. The service functions return either a
 * result or { error, status, details }, so status handling lives here once rather than in
 * every route.
 */
async function handleContract(req, res, fn) {
  let body;
  try {
    const raw = await readBody(req);
    body = raw ? JSON.parse(raw) : {};
  } catch {
    return sendJSON(res, 400, { error: 'request body is not valid JSON', status: 400 });
  }
  try {
    const out = await fn(body);
    if (out && out.error) return sendJSON(res, out.status ?? 400, out);
    return sendJSON(res, 200, out);
  } catch (err) {
    // A thrown error here is a bug in the engine, not a client error, so it is reported as
    // such rather than dressed up as a 400.
    return sendJSON(res, 500, { error: 'internal error', status: 500, details: [String(err?.message ?? err)] });
  }
}

function readBody(req) {
  return new Promise((done, fail) => {
    let data = '';
    req.on('data', (c) => {
      data += c;
      if (data.length > 1e6) fail(new Error('payload too large'));
    });
    req.on('end', () => done(data));
    req.on('error', fail);
  });
}

async function readJSON(req) {
  const raw = await readBody(req);
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

async function append(file, line) {
  const existing = existsSync(file) ? await readFile(file, 'utf8') : '';
  await writeFile(file, existing + line);
}

async function readTail(file, n) {
  if (!existsSync(file)) return [];
  const text = await readFile(file, 'utf8');
  return text.trim().split('\n').filter(Boolean).slice(-n).map((l) => {
    try { return JSON.parse(l); } catch { return { raw: l }; }
  });
}

function loadEnvironmentSync() {
  try {
    const p = join(ROOT, 'config', 'environment.json');
    return existsSync(p) ? JSON.parse(readFileSync(p, 'utf8')) : {};
  } catch {
    return {};
  }
}

server.listen(PORT, HOST, () => {
  console.log(`Sovereign Blob bridge listening on http://${HOST}:${PORT}`);
  console.log(`  workspace : ${ROOT}`);
  console.log(`  outputs   : ${OUT}`);
  console.log(`  sensor    : POST /api/telemetry${NODE_TOKEN ? '  (x-node-token required)' : '  (no token set — set BLOB_NODE_TOKEN to require one)'}`);
});
