package dev.sovereignblob.tools

import dev.sovereignblob.reality.RealityChecks

/**
 * Cross-implementation parity harness.
 *
 * The structural verdict is computed twice: once in JavaScript (`src/engine/sag.js`, used by
 * the bridge, the CLI and the exports) and once in Kotlin (`RealityChecks`, used on-device with
 * no network). Two implementations of a physical law is two ways to be wrong, so this program
 * prints the Kotlin numbers as JSON and `tests/parity.test.mjs` asserts the JavaScript engine
 * produces the same values.
 *
 * Run:  kotlinc android/app/src/main/java/dev/sovereignblob/reality/RealityChecks.kt \
 *               tools/parity/ParityMain.kt -include-runtime -d parity.jar && java -jar parity.jar
 */
object ParityMain {

    // Must match the JS defaults: birch plywood, 680 kg/m3, E 10300 MPa, 25 kg per shelf.
    const val DEPTH_MM = 300.0
    const val DENSITY = 680.0
    const val ELASTIC = 10300.0
    const val LOAD_KG = 25.0
    const val WIDTH_MM = 900.0

    @JvmStatic
    fun main(args: Array<String>) {
        val stocked = listOf(12.0, 15.0, 18.0, 21.0, 25.0)
        val thickness = 18.0
        val span = RealityChecks.clearSpan(WIDTH_MM, thickness)

        val lines = mutableListOf<String>()
        lines += "\"spanMm\": ${span.toInt()}"
        lines += "\"material\": { \"depthMm\": ${DEPTH_MM.toInt()}, \"densityKgM3\": ${DENSITY.toInt()}, \"elasticModulusMpa\": ${ELASTIC.toInt()}, \"loadKg\": ${LOAD_KG.toInt()} }"

        val cases = stocked.joinToString(",\n    ") { t ->
            val selfMass = DEPTH_MM * t * span * DENSITY / 1_000_000_000.0
            val r = RealityChecks.shelfDeflection(span, t, DEPTH_MM, ELASTIC, LOAD_KG, selfMass)
            """"${t.toInt()}": { "immediateMm": ${r.immediateMm}, "longTermMm": ${r.longTermMm}, "limitMm": ${r.limitMm}, "utilisation": ${r.utilisation}, "passes": ${r.passes}, "selfMassKg": ${round3(selfMass)} }"""
        }
        lines += "\"deflection\": {\n    $cases\n  }"

        val min = RealityChecks.minimumPassingThickness(stocked, span, DEPTH_MM, ELASTIC, LOAD_KG) { t ->
            DEPTH_MM * t * span * DENSITY / 1_000_000_000.0
        }
        lines += "\"minimumPassingThicknessMm\": $min"
        lines += "\"tipOverMargin\": ${RealityChecks.tipOverMargin(WIDTH_MM, 1800.0, DEPTH_MM, 30.0, LOAD_KG)}"

        // 1758 mm span, the geometry in the spec's own SBM example.
        val wideSpan = RealityChecks.clearSpan(1800.0, 21.0)
        val wideSelf = DEPTH_MM * 21.0 * wideSpan * DENSITY / 1_000_000_000.0
        val wide = RealityChecks.shelfDeflection(wideSpan, 21.0, DEPTH_MM, ELASTIC, 35.0, wideSelf)
        lines += "\"wideSpan21mm\": { \"spanMm\": ${wideSpan.toInt()}, \"longTermMm\": ${wide.longTermMm}, \"limitMm\": ${wide.limitMm}, \"passes\": ${wide.passes} }"

        println("{\n  " + lines.joinToString(",\n  ") + "\n}")
    }

    private fun round3(v: Double) = Math.round(v * 1000.0) / 1000.0
}
