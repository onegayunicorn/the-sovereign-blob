#!/usr/bin/env python3
"""
Independent DXF verification (Phase 4).

The claim under test is "the DXF is importable into CAD software". Until now that was
unproven: our own tests parsed the file with our own regexes, which proves the bytes are
self-consistent, not that another implementation accepts them.

This uses **ezdxf**, an independent third-party DXF library, to read the file. That is real
evidence and it is also the limit of it: ezdxf is not LibreCAD or QCAD, and no GUI CAD was run
here. If this passes and a GUI still rejects the file, the file is fine and the GUI wants
something specific — which is a different problem with a different fix.

Checks:
  1. the file parses with an independent reader
  2. $INSUNITS is millimetres (4), so the geometry is not silently interpreted as inches
  3. entities exist, on the expected layers
  4. every part rectangle lies inside a sheet outline (geometry that overruns the sheet cannot
     be cut, however well it parses)
  5. ezdxf's own audit reports no errors

Usage: python3 tools/verify-dxf.py output/sbm/nested-layout.dxf
"""

import sys
from collections import Counter

try:
    import ezdxf
except ImportError:
    print("ezdxf is not installed. pip install ezdxf", file=sys.stderr)
    sys.exit(2)


def rects_from(lines):
    """
    Group LINE entities into closed loops, by walking shared endpoints.

    The first version of this walked loops with a nested search and found nothing, reporting a
    perfectly good file as broken. Replaced with an endpoint adjacency walk, which is the
    straightforward way to do it: build a point -> incident lines map, then follow unused lines
    from one endpoint to the next until you arrive back where you started.
    """
    def key(p):
        return (round(p[0], 4), round(p[1], 4))

    adj = {}
    for i, e in enumerate(lines):
        a, b = key(e.dxf.start), key(e.dxf.end)
        adj.setdefault(a, []).append((i, b))
        adj.setdefault(b, []).append((i, a))

    unused = set(range(len(lines)))
    rects = []
    while unused:
        start_i = next(iter(unused))
        unused.discard(start_i)
        origin = key(lines[start_i].dxf.start)
        loop = [origin]
        cur = key(lines[start_i].dxf.end)
        guard = 0
        while cur != origin and guard < 64:
            guard += 1
            step = next(((i, other) for (i, other) in adj.get(cur, []) if i in unused), None)
            if step is None:
                break
            i, other = step
            unused.discard(i)
            loop.append(cur)
            cur = other
        if cur == origin and len(loop) >= 4:
            xs = [p[0] for p in loop]
            ys = [p[1] for p in loop]
            rects.append(
                {
                    "layer": lines[start_i].dxf.layer,
                    "x0": min(xs),
                    "x1": max(xs),
                    "y0": min(ys),
                    "y1": max(ys),
                }
            )
    return rects


def main(path):
    doc = ezdxf.readfile(path)
    problems = []

    insunits = doc.header.get("$INSUNITS", None)
    if insunits != 4:
        problems.append(f"$INSUNITS is {insunits}, expected 4 (millimetres)")

    msp = doc.modelspace()
    counts = Counter(e.dxftype() for e in msp)
    layers = Counter(e.dxf.layer for e in msp)

    auditor = doc.audit()
    if auditor.errors:
        problems.append(f"ezdxf audit reported {len(auditor.errors)} error(s): {auditor.errors[:3]}")
    if auditor.fixes:
        # Auto-fixes are reported, not hidden: a file that needs repairing on open is a file
        # that will annoy someone later.
        problems.append(f"ezdxf applied {len(auditor.fixes)} auto-fix(es): {auditor.fixes[:3]}")

    lines = [e for e in msp if e.dxftype() == "LINE"]
    rects = rects_from(lines)
    sheets = [r for r in rects if r["layer"] == "SHEET"]
    parts = [r for r in rects if r["layer"] != "SHEET"]

    if not sheets:
        problems.append("no SHEET outline found")
    if not parts:
        problems.append("no PART rectangles found")

    outside = 0
    for p in parts:
        if not any(
            p["x0"] >= s["x0"] - 0.01
            and p["x1"] <= s["x1"] + 0.01
            and p["y0"] >= s["y0"] - 0.01
            and p["y1"] <= s["y1"] + 0.01
            for s in sheets
        ):
            outside += 1
    if outside:
        problems.append(f"{outside} part rectangle(s) lie outside every sheet outline")

    print(f"file        : {path}")
    print(f"reader      : ezdxf {ezdxf.__version__} (independent implementation)")
    print(f"dxf version : {doc.dxfversion}")
    print(f"$INSUNITS   : {insunits} (4 = mm)")
    print(f"entities    : {dict(counts)}")
    print(f"layers      : {dict(layers)}")
    print(f"rectangles  : {len(sheets)} sheet outline(s), {len(parts)} part(s)")
    print(f"audit       : {len(auditor.errors)} error(s), {len(auditor.fixes)} fix(es)")

    if problems:
        print("\nVERDICT: PROBLEMS")
        for p in problems:
            print(f"  - {p}")
        return 1
    print("\nVERDICT: OK — an independent DXF implementation reads the file, units are "
          "millimetres, and every part sits inside its sheet.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else "output/sbm/nested-layout.dxf"))
