#!/usr/bin/env node
/**
 * Simulation harness — exercises every operation and every service, and reports what actually
 * happened rather than what should have.
 *
 * The rule that makes this useful: a scenario that cannot be verified without credentials or a
 * physical object reports SKIPPED, never PASS. A green tick next to "supplier API" when no API
 * key exists is the single most expensive kind of lie in a build report, because everything
 * downstream inherits it.
 *
 * Statuses:
 *   PASS      executed here, assertions held
 *   FAIL      executed here, something was wrong
 *   SKIPPED   cannot be executed in this environment (no credential, no device, no camera)
 *   BLOCKED   executed and correctly refused an invalid input (a pass, in other words)
 *
 * Usage: node tools/simulate.mjs [--json] [--out dir]
 */

import { writeFileSync, mkdirSync, existsSync, readFileSync, readdirSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const OUT = join(ROOT, 'output', 'simulations');

const { runPipeline, dreamState } = await import(join(ROOT, 'src', 'pipeline.js'));
const { buildSBM, validateSBM } = await import(join(ROOT, 'src', 'sbm', 'manifest.js'));
const { buildReplay } = await import(join(ROOT, 'src', 'exports', 'replay.js'));
const { buildBuildPacketPDF, verifyPdf } = await import(join(ROOT, 'src', 'exports', 'pdf.js'));
const { toDXF, toCutListCSV, toNestedSVG, toPackageJSON } = await import(join(ROOT, 'src', 'export', 'index.js'));
const { buildAssemblySequence } = await import(join(ROOT, 'src', 'engine', 'assembly.js'));
const { parseIntent } = await import(join(ROOT, 'src', 'intent', 'core.js'));
const { buildSheetGoodsRfq, buildCncQuoteRequest, loadPriceBook, procurementRoute } = await import(join(ROOT, 'src', 'vendor', 'vendors.js'));
const { parseTelemetry, summariseWindow } = await import(join(ROOT, 'src', 'sensors', 'telemetry.js'));
const { validateRoom, accessCheck } = await import(join(ROOT, 'src', 'sensors', 'room.js'));
const { statusForScore, colourForScore, auditBands } = await import(join(ROOT, 'src', 'proto', 'state.js'));
const { defaultAnchors, validateAnchors, lockAnchor, attemptAnchorChange } = await import(join(ROOT, 'src', 'reality', 'anchors.js'));
const { validateDef, loadSchemas } = await import(join(ROOT, 'contracts', 'validate.mjs'));
const api = await import(join(ROOT, 'src', 'api', 'service.js'));
const { MATERIALS, alternativesFor } = await import(join(ROOT, 'src', 'engine', 'materials.js'));
const { buildCutList } = await import(join(ROOT, 'src', 'engine', 'cutlist.js'));

const results = [];
const t0 = performance.now();
const time = (fn) => {
  const s = performance.now();
  const value = fn();
  return { value, ms: Math.round((performance.now() - s) * 100) / 100 };
};

function record(group, name, status, detail, extra = {}) {
  results.push({ group, name, status, detail, ...extra });
  const tag = { PASS: 'PASS   ', FAIL: 'FAIL   ', SKIPPED: 'SKIP   ', BLOCKED: 'BLOCKED' }[status];
  console.log(`  ${tag} ${name} — ${detail}`);
}

function check(group, name, fn) {
  try {
    const r = time(fn);
    if (r.value === false || r.value === undefined || r.value === null) {
      record(group, name, 'FAIL', 'returned a falsy result', { ms: r.ms });
    } else if (typeof r.value === 'object' && r.value.ok === false) {
      record(group, name, 'FAIL', r.value.detail ?? 'ok=false', { ms: r.ms });
    } else {
      record(group, name, 'PASS', typeof r.value === 'string' ? r.value : 'assertions held', { ms: r.ms });
    }
  } catch (err) {
    record(group, name, 'FAIL', String(err?.message ?? err));
  }
}

// ---------------------------------------------------------------------------
console.log('\n=== 1. ENGINE OPERATIONS ===');
// ---------------------------------------------------------------------------
const design = {};
check('engine', 'intent parse', () => {
  const i = parseIntent('build me a bookshelf, 1800 tall and 900 wide, shelves 300 deep, under $80');
  design.intent = i;
  return i.kind === 'bookshelf' && i.slots.widthMm.value === 900 && i.location === 'unspecified'
    ? `goal=${i.kind} w=${i.slots.widthMm.value} h=${i.slots.heightMm.value} d=${i.slots.depthMm.value}`
    : false;
});

check('engine', 'pipeline (au-qld-local)', () => {
  design.au = runPipeline('build me a bookshelf, 1800 tall and 900 wide, shelves 300 deep', { region: 'au-qld-local' });
  return `score ${design.au.reality.score}, ${design.au.cutList.nesting.carcassSheetCount} sheets, ${design.au.cost.total} ${design.au.cost.currency}`;
});

check('engine', 'pipeline (cn-bulk)', () => {
  design.cn = runPipeline('build me a bookshelf, 1800 tall and 900 wide, shelves 300 deep');
  return `score ${design.cn.reality.score}, ${design.cn.cost.total} ${design.cn.cost.currency}`;
});

check('engine', 'structural check 18mm FAILs / 21mm PASSes', () => {
  const fail = buildCutList({ widthMm: 900, heightMm: 1800, depthMm: 300, shelves: 5, thicknessMm: 18, loadPerShelfKg: 25 });
  const pass = buildCutList({ widthMm: 900, heightMm: 1800, depthMm: 300, shelves: 5, thicknessMm: 21, loadPerShelfKg: 25 });
  const f = fail.checks.shelfDeflection;
  const p = pass.checks.shelfDeflection;
  return !f.pass && p.pass
    ? `18mm ${f.longTermMm}mm/${f.limitMm}mm FAIL, 21mm ${p.longTermMm}mm PASS`
    : { ok: false, detail: `18mm pass=${f.pass}, 21mm pass=${p.pass}` };
});

check('engine', 'dream state variant search', () => {
  const d = dreamState('build me a bookshelf 1800 tall 900 wide', { region: 'au-qld-local' });
  // Fix 4: `explored` is a COUNT and `best`/`recommended` are arrays/objects. The harness
  // originally tested `explored.length`, which is undefined on a number — so a working feature
  // reported as broken. Asserting the real shape now, and printing it if it ever changes.
  const n = typeof d?.explored === 'number' ? d.explored : (Array.isArray(d?.variants) ? d.variants.length : 0);
  return n > 0 && d?.recommended
    ? `${n} variants, best ${JSON.stringify(d.recommended.change)} = ${d.recommended.score} (${d.recommended.band})`
    : { ok: false, detail: `unexpected shape: ${JSON.stringify(d)?.slice(0, 180)}` };
});

check('engine', 'material alternatives surfaced', () => {
  const alts = alternativesFor(design.au.cutList.material.id, design.au.cutList.spec.thicknessMm);
  return alts?.length ? `${alts.length} alternatives` : false;
});

check('engine', 'assembly sequence', () => {
  const a = buildAssemblySequence(design.au.cutList);
  design.assembly = a;
  return a.steps.length >= 8 ? `${a.steps.length} steps` : false;
});

check('engine', 'state colour bands tile 0-100', () => {
  const b = auditBands();
  return b.ok ? `BLOCKED<=${b.spans[0].max} CAUTION<=${b.spans[1].max} READY<=100` : { ok: false, detail: b.problems.join('; ') };
});

check('engine', 'score->colour mapping', () => {
  const lo = colourForScore(20).colourName;
  const mid = colourForScore(60).colourName;
  const hi = colourForScore(90).colourName;
  return lo === 'Red' && mid === 'Amber' && hi === 'Green' ? `${lo}/${mid}/${hi}` : false;
});

// ---------------------------------------------------------------------------
console.log('\n=== 2. EXPORT OPERATIONS ===');
// ---------------------------------------------------------------------------
const pdf = {};
check('export', 'CSV cut list', () => {
  const csv = toCutListCSV(design.au.cutList, { generatedAt: '2026-01-01T00:00:00.000Z' });
  return csv.split('\n').length > 6 && !/REQUEST_TIME|TBD/.test(csv) ? `${csv.split('\n').length} rows` : false;
});
check('export', 'SVG sheet layout + elevation', () => {
  const svg = toNestedSVG(design.au.cutList);
  return svg.startsWith('<svg') && svg.includes('front elevation') ? 'svg + elevation' : false;
});
check('export', 'DXF millimetre geometry', () => {
  const dxf = toDXF(design.au.cutList);
  const lines = (dxf.match(/\n0\nLINE\n/g) || []).length;
  return dxf.includes('$INSUNITS') && lines > 10 ? `${lines} LINE entities` : false;
});
// The PDF needs an SBM to build its packet from, so it is exercised in section 3 where the
// manifest exists rather than faked here with a null.
check('export', 'package JSON', () => {
  const j = toPackageJSON(design.au, { generatedAt: '2026-01-01T00:00:00.000Z' });
  return JSON.parse(j).reality ? 'parses and carries reality' : false;
});

// ---------------------------------------------------------------------------
console.log('\n=== 3. SBM + CONTRACT OPERATIONS ===');
// ---------------------------------------------------------------------------
let sbm = null;
check('sbm', 'build SBM v0.2', () => {
  sbm = buildSBM({
    project: { id: 'sim-001', name: 'Sim Shelf', created: new Date().toISOString(), version: 1 },
    result: { ...design.au, assembly: design.assembly },
    roomScan: { wallWidthMm: 1800, wallHeightMm: 2400, confidence: 0.82, source: 'wall-scan' },
    overrides: {}
  });
  return `status ${sbm.reality.status}, score ${sbm.reality.score}, confidence ${sbm.reality.confidence}`;
});
check('sbm', 'SBM validates against its schema', () => {
  const v = validateDef(sbm, 'sbmV02', loadSchemas());
  return v.valid ? 'schema valid' : { ok: false, detail: v.errors.map((e) => e.path + ':' + e.message).join('; ') };
});
check('sbm', 'build packet PDF generated and structurally valid', () => {
  const built = buildBuildPacketPDF({ sbm, result: design.au, assembly: design.assembly });
  const v = verifyPdf(built.bytes);
  return v.ok ? `${built.pages} pages, ${v.objectsChecked} objects, xref resolves` : { ok: false, detail: v.problems.join('; ') };
});
check('sbm', 'replay timeline', () => {
  const r = buildReplay({ project: { id: 'sim-001', name: 'Sim Shelf' }, result: { ...design.au, assembly: design.assembly }, anchors: sbm.anchors });
  const v = validateDef(r, 'replayTimeline', loadSchemas());
  return v.valid && r.entries.length >= 6 ? `${r.entries.length} entries` : false;
});
check('sbm', 'save/load round trip', () => {
  const a = JSON.stringify(sbm);
  const b = JSON.stringify(JSON.parse(a));
  return a === b ? 'lossless' : false;
});

// ---------------------------------------------------------------------------
console.log('\n=== 4. ANCHOR OPERATIONS ===');
// ---------------------------------------------------------------------------
check('anchor', 'default anchor set', () => {
  design.anchors = defaultAnchors({ spec: { ...design.au.cutList.spec, wallMounted: true }, cutList: design.au.cutList, cost: design.au.cost });
  return design.anchors.length >= 5 ? `${design.anchors.length} anchors` : false;
});
check('anchor', 'locked anchor refuses change', () => {
  const locked = lockAnchor(design.anchors, 'anchor-load-001');
  const attempt = attemptAnchorChange(locked, 'anchor-load-001', 99);
  return attempt.accepted === false && attempt.blocking === true ? 'refused with explanation' : false;
});
check('anchor', 'locked violation -> BLOCKED', () => {
  const locked = lockAnchor(design.anchors, 'anchor-load-001');
  const m = buildSBM({
    project: { id: 'sim-002', name: 'Blocked', created: new Date().toISOString(), version: 1 },
    result: runPipeline('bookshelf 900 wide 1800 tall', { region: 'au-qld-local', specOverrides: { loadPerShelfKg: 80 } }),
    anchors: locked
  });
  return m.reality.status === 'BLOCKED' && m.reality.blockers.length > 0 ? 'BLOCKED with reason' : false;
});

// ---------------------------------------------------------------------------
console.log('\n=== 5. SENSOR OPERATIONS ===');
// ---------------------------------------------------------------------------
const SAMPLE = () => ({ deviceId: 'node-1', ts: Date.now(), tempC: 22.5, humidityPct: 48, pressureHpa: 1013, lux: 320, ax: 0.01, ay: 0.02, az: 1.0, gx: 0.1, gy: 0.1, gz: 0.1, batteryV: 3.9, rssiDbm: -55, fw: '0.1.0' });

check('sensor', 'telemetry decode (valid reading)', () => {
  const r = parseTelemetry(SAMPLE());
  return r.ok && r.values?.tempC === 22.5
    ? `temp ${r.values.tempC}C, tilt ${r.derived?.tiltDeg}deg, ${r.advisories?.length ?? 0} advisories`
    : { ok: false, detail: `ok=${r.ok} values=${JSON.stringify(r.values ?? null)}` };
});
check('sensor', 'telemetry rejects out-of-range reading', () => {
  const r = parseTelemetry({ deviceId: 'node-1', ts: Date.now(), tempC: 900, humidityPct: 48 });
  return r.ok === false ? 'rejected, as designed' : false;
});
check('sensor', 'room envelope validation', () => {
  const r = validateRoom(
    { widthMm: 3200, heightMm: 2400, depthMm: 3200, wallWidthMm: 3200, wallHeightMm: 2400, doorWidthMm: 800, confidence: 0.9 },
    { widthMm: 900, heightMm: 1800, depthMm: 300 }
  );
  const access = r.checks?.access;
  const accessDetail = access
    ? Object.entries(access)
        .map(([k, v]) => `${k}:${v?.pass ? 'ok' : 'blocked'}`)
        .join(' ')
    : 'no access report';
  return r.scanned && typeof r.fits === 'boolean' ? `fits=${r.fits}, ${accessDetail}` : false;
});
check('sensor', 'telemetry window summary', () => {
  const now = Date.now();
  const readings = Array.from({ length: 10 }, (_, i) => {
    const r = parseTelemetry({ ...SAMPLE(), deviceId: 'n1', ts: now - (10 - i) * 1000, tempC: 20 + i * 0.1 });
    return r.ok ? r.values : null;
  }).filter(Boolean);
  const s = summariseWindow(readings);
  const n = s?.count ?? s?.samples ?? s?.readings?.length;
  return readings.length === 10 && n >= 10 ? `${n} readings summarised` : { ok: false, detail: `inputs ${readings.length}, summary ${JSON.stringify(s)?.slice(0, 120)}` };
});

// ---------------------------------------------------------------------------
console.log('\n=== 6. SERVICE CONNECTORS ===');
// ---------------------------------------------------------------------------
const services = JSON.parse(readFileSync(join(ROOT, 'config', 'services.json'), 'utf8')).services;
const priceBook = loadPriceBook();

check('service', 'price book loads', () => {
  const n = Object.keys(priceBook.items).length;
  const priced = Object.values(priceBook.items).filter((i) => typeof i.price === 'number').length;
  return `service: ${n} items, ${priced} priced, asOf ${priceBook.asOf}`;
});

let live = 0;
let needsKey = 0;
let formOnly = 0;
for (const s of services) {
  if (s.access === 'live') live++;
  else if (s.access === 'needs-key') needsKey++;
  else formOnly++;
}
record(
  'service',
  'service registry census',
  'PASS',
  `${services.length} services: ${live} live, ${needsKey} need credentials, ${formOnly} form-only or unverified`,
  { services: services.length, live, needsKey, formOnly }
);

check('service', 'Mode A job advertises only local bureaux', () => {
  const c = buildCncQuoteRequest(design.au.cutList, { regionId: 'au-qld-local' });
  const foreign = c.services.filter((s) => s.region !== 'au-qld-local');
  return c.services.length >= 3 && foreign.length === 0 ? `${c.services.length} QLD targets, 0 foreign` : false;
});

check('service', 'RFQ generation (plywood, Mode B)', () => {
  const rfq = buildSheetGoodsRfq(design.au.cutList, { quantity: 1, destinationCountry: 'Australia', supplier: { name: 'Sim Supplier' } });
  return rfq.body?.length > 200 ? `${rfq.body.length} chars generated (not sent)` : false;
});

check('service', 'procurement route resolves (real signature: one price-book key)', () => {
  // Fix 1 clarified this API: it resolves ONE BOM line, and the guard now rejects anything else
  // with a readable message. The harness was passing a whole design object.
  const route = procurementRoute('sheet-18mm-birch-plywood-2440x1220');
  return route?.route
    ? `route=${route.route} (${route.action ?? 'no action'})`
    : { ok: false, detail: `unexpected shape: ${JSON.stringify(route)?.slice(0, 160)}` };
});

check('service', 'procurement route rejects a whole design with a readable error', () => {
  try {
    procurementRoute(design.au.cutList);
    return { ok: false, detail: 'the misuse was accepted silently — that is the original defect' };
  } catch (err) {
    return err instanceof TypeError && /item key \(string\)/.test(err.message)
      ? 'refused with a message naming the mistake'
      : { ok: false, detail: `wrong error: ${err?.message}` };
  }
});

check('engine', 'rear-leg drop is modelled and reported', () => {
  const tip = design.au.cutList.checks.tipOver;
  const ok = tip.rearDropMm > 0 && tip.tiltDeg > 0 && tip.margin > tip.marginWithoutRearDrop && tip.margin < 1;
  return ok
    ? `${tip.rearDropMm}mm drop -> ${tip.tiltDeg}deg, margin ${tip.marginWithoutRearDrop} -> ${tip.margin} (anchor still required)`
    : { ok: false, detail: JSON.stringify(tip) };
});

// Credential-gated and human-gated services are reported honestly, never as PASS.
for (const s of services) {
  if (s.access === 'live') {
    record('service', `${s.name}`, 'PASS', 'reachable with existing credentials', { access: s.access, verified: s.verified });
  } else if (s.access === 'needs-key') {
    record('service', `${s.name}`, 'SKIPPED', 'API exists but no credential is supplied here', { access: s.access, verified: s.verified });
  } else {
    record('service', `${s.name}`, 'SKIPPED', `no API — ${s.access}; a human must submit`, { access: s.access, verified: s.verified });
  }
}

// ---------------------------------------------------------------------------
console.log('\n=== 7. API CONTRACT OPERATIONS ===');
// ---------------------------------------------------------------------------
check('api', 'POST /api/project/create (service layer)', () => {
  const created = api.createProject({ name: `Sim ${Date.now()}` });
  design.project = created;
  return created.status === 'created' && created.projectId ? `projectId=${created.projectId}` : false;
});
check('api', 'POST /api/design/generate', () => {
  const g = api.generateDesign({ projectId: design.project.projectId, intent: { goal: 'bookshelf' }, room: { width: 1800, height: 2400 } });
  design.design = g;
  return g.status === 'generated' && g.designId ? `designId=${g.designId}, score ${g.realityScore}` : false;
});
check('api', 'POST /api/reality/evaluate', () => {
  const e = api.evaluateReality({ designId: design.design.designId });
  return e.realityScore >= 0 && e.status ? `${e.realityScore} → ${e.status}` : false;
});
check('api', 'POST /api/export (pdf dxf sbm replay)', () => {
  const x = api.exportPackage({ projectId: design.project.projectId, formats: ['pdf', 'dxf', 'sbm', 'replay'] });
  return x.exports?.length === 4 ? x.exports.join(', ') : { ok: false, detail: JSON.stringify(x).slice(0, 160) };
});
check('api', 'GET /api/project/:id (persistence)', () => {
  const st = api.loadProjectState(design.project.projectId);
  return st?.project && st?.designId ? `restored ${st.project.name} / ${st.designId}` : false;
});
check('api', 'unknown designId is refused', () => {
  const e = api.evaluateReality({ designId: 'design-does-not-exist' });
  return e.status === 404 ? 'rejected with 404' : false;
});

// ---------------------------------------------------------------------------
console.log('\n=== 8. EXTERNAL CONNECTORS (credential-gated) ===');
// ---------------------------------------------------------------------------
record('connector', 'Microsoft 365 mail (send)', 'SKIPPED', 'credential present but a simulation must not send mail to a real supplier', { access: 'live' });
record('connector', 'Alibaba sourcing tools', 'SKIPPED', 'called in earlier turns; not re-invoked here to avoid touching a live marketplace during a simulation', { access: 'live' });
record('connector', 'GitHub (push)', 'SKIPPED', 'exercised by the repository push step, not the simulation', { access: 'live' });

// ---------------------------------------------------------------------------
const summary = results.reduce((acc, r) => ({ ...acc, [r.status]: (acc[r.status] ?? 0) + 1 }), {});
const report = {
  generatedAt: new Date().toISOString(),
  durationMs: Math.round(performance.now() - t0),
  summary,
  groups: [...new Set(results.map((r) => r.group))],
  results
};

mkdirSync(OUT, { recursive: true });
writeFileSync(join(OUT, 'report.json'), JSON.stringify(report, null, 2));

const md = [
  '# Simulation report',
  '',
  `Generated ${report.generatedAt} | ${report.durationMs} ms | ${results.length} scenarios`,
  '',
  `**PASS ${summary.PASS ?? 0} | FAIL ${summary.FAIL ?? 0} | SKIPPED ${summary.SKIPPED ?? 0} | BLOCKED ${summary.BLOCKED ?? 0}**`,
  '',
  'SKIPPED means it could not be executed here — no credential, no device, or a deliberate',
  'decision not to touch a live marketplace during a simulation. It does not mean passing.',
  '',
  '| group | scenario | status | detail | ms |',
  '|---|---|---|---|---|',
  ...results.map((r) => `| ${r.group} | ${r.name} | ${r.status} | ${String(r.detail).replace(/\|/g, '/')} | ${r.ms ?? ''} |`)
].join('\n');
writeFileSync(join(OUT, 'report.md'), md);

console.log('\n=== SUMMARY ===');
console.log(JSON.stringify(summary));
console.log(`report: ${join(OUT, 'report.md')}`);
if ((summary.FAIL ?? 0) > 0) process.exitCode = 1;
