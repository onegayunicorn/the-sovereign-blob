/**
 * Zero-dependency JSON Schema validator — the subset this project actually uses.
 *
 * Why not a library: the whole repo has zero runtime dependencies, and pulling in Ajv to
 * check six schemas would break that for no benefit. The supported keywords are listed
 * below and anything unsupported is reported rather than silently ignored, so a schema
 * that uses a keyword this validator does not understand fails loudly instead of passing
 * vacuously — a validator that silently accepts everything is worse than no validator.
 *
 * Supported: $ref (#/defs/...), type, required, properties, items, enum, const,
 *           minimum, maximum, exclusiveMinimum, minLength, minItems, additionalProperties
 */

import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
export const SCHEMAS_PATH = join(HERE, 'schemas.json');

const SUPPORTED = new Set([
  '$schema', '$id', 'title', 'description', 'defs', '$ref',
  'type', 'required', 'properties', 'items', 'enum', 'const',
  'minimum', 'maximum', 'exclusiveMinimum', 'minLength', 'minItems',
  'additionalProperties'
]);

let cache = null;
export function loadSchemas(path = SCHEMAS_PATH) {
  if (!path || path === SCHEMAS_PATH) {
    if (!cache) cache = JSON.parse(readFileSync(SCHEMAS_PATH, 'utf8'));
    return cache;
  }
  return JSON.parse(readFileSync(path, 'utf8'));
}

export function resolveRef(doc, ref) {
  if (!ref.startsWith('#/')) throw new Error(`only local refs are supported, got ${ref}`);
  const result = ref
    .slice(2)
    .split('/')
    .reduce((node, key) => {
      if (node == null) throw new Error(`unresolvable ref ${ref}`);
      return node[key];
    }, doc);
  // A ref that walks to a missing key used to return undefined and then validate nothing at
  // all, which silently turns a typo'd $ref into a schema that accepts anything.
  if (result == null) throw new Error(`unresolvable ref ${ref}`);
  return result;
}

function typeOf(value) {
  if (value === null) return 'null';
  if (Array.isArray(value)) return 'array';
  if (Number.isInteger(value)) return 'integer';
  return typeof value;
}

function typeMatches(value, expected) {
  const actual = typeOf(value);
  if (expected === 'number') return actual === 'number' || actual === 'integer';
  if (expected === 'integer') return actual === 'integer';
  return actual === expected;
}

/** Validates `value` against `schema`. Returns { valid, errors[] }. */
export function validate(value, schema, { doc = loadSchemas(), path = '$' } = {}) {
  const errors = [];
  walk(value, schema, doc, path, errors);
  return { valid: errors.length === 0, errors };
}

/** Validates against a named definition in schemas.json. */
export function validateDef(value, defName, doc = loadSchemas()) {
  const schema = doc.defs?.[defName];
  if (!schema) throw new Error(`unknown schema definition "${defName}"`);
  return validate(value, schema, { doc, path: `$(${defName})` });
}

function walk(value, schema, doc, path, errors) {
  if (schema == null) return;

  for (const key of Object.keys(schema)) {
    if (!SUPPORTED.has(key)) {
      errors.push({ path, message: `schema uses unsupported keyword "${key}" — refusing to pass vacuously` });
      return;
    }
  }

  if (schema.$ref) {
    walk(value, resolveRef(doc, schema.$ref), doc, path, errors);
    return;
  }

  if (schema.const !== undefined && value !== schema.const) {
    errors.push({ path, message: `expected const ${JSON.stringify(schema.const)}, got ${JSON.stringify(value)}` });
  }

  if (schema.enum && !schema.enum.includes(value)) {
    errors.push({ path, message: `expected one of ${schema.enum.join(', ')}, got ${JSON.stringify(value)}` });
  }

  if (schema.type) {
    const types = Array.isArray(schema.type) ? schema.type : [schema.type];
    if (!types.some((t) => typeMatches(value, t))) {
      errors.push({ path, message: `expected type ${types.join('|')}, got ${typeOf(value)}` });
      return;
    }
  }

  if (typeof value === 'number') {
    if (schema.minimum !== undefined && value < schema.minimum) errors.push({ path, message: `${value} < minimum ${schema.minimum}` });
    if (schema.maximum !== undefined && value > schema.maximum) errors.push({ path, message: `${value} > maximum ${schema.maximum}` });
    if (schema.exclusiveMinimum !== undefined && value <= schema.exclusiveMinimum) {
      errors.push({ path, message: `${value} <= exclusiveMinimum ${schema.exclusiveMinimum}` });
    }
  }

  if (typeof value === 'string' && schema.minLength !== undefined && value.length < schema.minLength) {
    errors.push({ path, message: `string shorter than minLength ${schema.minLength}` });
  }

  if (Array.isArray(value)) {
    if (schema.minItems !== undefined && value.length < schema.minItems) {
      errors.push({ path, message: `array has ${value.length} items, needs ${schema.minItems}` });
    }
    if (schema.items) value.forEach((item, i) => walk(item, schema.items, doc, `${path}[${i}]`, errors));
  }

  if (value && typeof value === 'object' && !Array.isArray(value)) {
    for (const key of schema.required || []) {
      if (!(key in value) || value[key] === undefined) errors.push({ path, message: `missing required "${key}"` });
    }
    for (const [key, sub] of Object.entries(schema.properties || {})) {
      if (key in value && value[key] !== undefined) walk(value[key], sub, doc, `${path}.${key}`, errors);
    }
    if (schema.additionalProperties === false) {
      for (const key of Object.keys(value)) {
        if (!(schema.properties || {})[key] && !(schema.required || []).includes(key)) {
          errors.push({ path, message: `unexpected property "${key}"` });
        }
      }
    }
  }
}

export function formatErrors(result) {
  return result.errors.map((e) => `${e.path}: ${e.message}`).join('\n');
}
