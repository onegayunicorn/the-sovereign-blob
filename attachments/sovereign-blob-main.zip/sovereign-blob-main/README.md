# Sovereign Blob — working core

Turns a spoken design intent into a buildable, priced, nested cut list with the
engineering checks that decide whether it can physically exist.

Zero runtime dependencies. Node standard library only. Binds to `127.0.0.1`. No account,
no cloud, no telemetry leaving the machine.

```bash
npm test          # 91 tests, all passing
npm start         # bridge + UI on http://127.0.0.1:8787
npm run blob -- "build me a bookshelf, 1800 tall and 900 wide, shelves 300 deep"
npm run sbm       # SBM build package: hashed artifacts + pass/block status
npm run sbm -- --thickness 21    # the same package at the remedied thickness
npm run quote-pack               # Mode A quote pack for the Gold Coast
npm run validate -- output/sbm/validation-record.template.json   # calibrate E from a real build
```

## Where this is right now

The build decision is **Mode A: local fabrication**, Gold Coast / Queensland. The reason is in the
numbers: container-tier supply prices a 2-sheet build at US$58, but its minimum order is roughly
250x what one build needs, so it is not purchasable at that price. A local bureau that holds its
own stock quotes about A$368 for the same job — roughly 6x — and you can actually buy it.

| | Mode A (local) | Mode B (container) |
|---|---|---|
| Material basis | A$135/sheet, local stock | US$15.50/sheet at MOQ 400 |
| Minimum order | none | 400 pcs, or a 20'GP container |
| Freight, customs | none | not modelled and not included |
| Total for this build | ~A$368 incl GST | US$58, a low bound you cannot buy at |

Switch between them with `--region` (`au-qld-local` or `cn-bulk`). A region pins the sheet size
*before* nesting runs — Australian sheet goods are commonly 2400 x 1200 rather than 2440 x 1220 —
so the DXF is nested against the board you can actually buy.

**Two emails have been sent** to a local bureau (EB Cabinetry, Woodridge QLD, serves the Gold
Coast) on 2026-09-28: the RFQ, then a correction. Records are in
`output/quote-requests/sent-email-*.txt`. No reply yet, so no quote exists yet.

**The design as spoken does not pass.** At 18 mm the predicted long-term sag is 3.091 mm against a
2.4 mm allowance. At 21 mm it is 1.940 mm and passes, at the same sheet count and the same cost.
`npm run sbm` at the default 18 mm reports status **BLOCKED** and says so at the top of the
manifest rather than burying it; `--thickness 21` produces the buildable package.

**Success is not cost.** It is whether a real person can take this package and build the shelf.
Until that shelf is measured, every number here is a prediction — which is what
`validation-record.template.json` and `npm run validate` exist to fix: measure the built sag, and
the tool derives the real elastic modulus of the board you were actually shipped, replacing the
handbook value the engine currently assumes.

## Alpha layer — spec v1.1

The Alpha specification adds five things on top of the engine, and each one is a directory
rather than a promise:

| Path | What it is |
|---|---|
| `contracts/schemas.json` | Single source of truth for every data shape in the spec: Intent Model, Reality Result, Reality Anchor, Material, Room Model, SBM v0.2, Replay, API error. `contracts/validate.mjs` validates against them with zero dependencies, and **fails loudly on a schema keyword it does not support** rather than passing vacuously. |
| `android/contracts/*.kt` | The six module interfaces and the data models, as specified. **Not compiled** — this environment has a JDK but no Kotlin compiler and no Gradle, which was checked rather than assumed. The *contract* is verified instead: `tests/contracts.test.mjs` reads the Kotlin source text and asserts its state colours match `config/proto-states.json`, so the two sides cannot drift. |
| `src/sbm/manifest.js` | SBM v0.2 builder. Status comes from the spec's score bands **except** that a violated *locked* anchor forces BLOCKED. `reality.confidence` is derived from information completeness and itemised in `confidenceBasis` — it is not a feeling. |
| `src/api/service.js` | The four internal API contracts, with project persistence under `output/projects/<id>/`. |
| `src/exports/pdf.js`, `src/exports/replay.js` | PDF build packet written from scratch (no dependency), and the conversation replay, which records the **rejected** options — a replay that omits the failure is a sales document. |

Four endpoints, envelopes exactly as specified:

```bash
curl -s -XPOST localhost:8787/api/project/create    -d '{"name":"Room Shelf"}'
curl -s -XPOST localhost:8787/api/design/generate   -d '{"projectId":"proj-001","intent":{"goal":"bookshelf"},"room":{"width":1800,"height":2400}}'
curl -s -XPOST localhost:8787/api/reality/evaluate  -d '{"designId":"design-001"}'
curl -s -XPOST localhost:8787/api/export            -d '{"projectId":"proj-001","formats":["pdf","dxf","sbm","replay"]}'
```

Status per sprint story: [`docs/SPRINT-STATUS.md`](docs/SPRINT-STATUS.md).
Where this disagrees with the spec and why: [`docs/SPEC-DEVIATIONS.md`](docs/SPEC-DEVIATIONS.md).
Beta extension points: [`docs/BETA-EXTENSION.md`](docs/BETA-EXTENSION.md).

**The two things not claimed:** no Android app exists (no Compose screen, no OpenGL renderer,
no CameraX wall capture), and no shelf has been physically built. Everything needing a device
or a physical object is marked as such in the sprint status rather than described as working.

## Status — read this first

**Verified working** (all of it executed in this repository, see `npm test`):

- Intent parsing from plain speech text (dimensions, imperial units, constraints, budgets, modifications)
- Load/deflection calculation, tip-over margin, racking check
- Joinery selection with material chemistry rules and explicit substitution reasoning
- MaxRects sheet nesting with a grain-direction constraint, plus an independent overlap audit
- Cut list, BOM, edge banding, fastener counts, assembly sequence, mass
- Costing against a price book of **real, dated, sourced prices** with MOQ and tier honesty
- Deterministic Reality Score with per-stage trace
- Exports: CSV, millimetre DXF (R12), SVG nested layout + elevation, self-contained package JSON
- HTTP bridge: run, telemetry ingest, SSE stream, output serving, path-traversal guard
- Sensor telemetry decode, validation and environment advisories

**Written but NOT verified on hardware:** the ESP32 firmware (`firmware/esp32-sensor-node`).
Compiles-in-principle code, reviewed against datasheets, never flashed.

**Not verified at all:** the canvas visuals (`src/blob/renderer.js`, `src/app.js`). The
renderer is tested headlessly against a stub 2D context for NaN geometry and missing
draw calls, but no browser ran in this environment. Expect one visual pass needed.

**Not built, and not pretended otherwise:** on-device speech recognition, AR depth
capture, any live supplier API call from inside the app, and any generative model.

## What it does not claim

The original concept describes a blob that physically forms designs in real time and a
system that closes the gap from imagination to manufacture in one continuous surface.
What is implemented is the part of that idea that survives contact with engineering:

- The "fluid" layer is a **visualisation** of the same numbers the cut list is built
  from — it is not a separate source of truth and it does not decide anything.
- There is **no AI in the design path**. Intent parsing is a deterministic parser;
  scoring is a deterministic function of computed values. That is deliberate: an
  engineering gate you cannot reproduce is not a gate.
- Material moduli are typical published handbook values, flagged `verified: false`, and
  the output package carries a `verify-datasheet` flag. Every structural figure is a
  first-order hand calculation, **not a structural certificate**.

## The bookshelf, as actually computed

`node bin/blob.mjs "build me a bookshelf, 1800 tall and 900 wide, shelves 300 deep"`

| Stage | Score | What the engine found |
|---|---|---|
| intent | 33 | 3 of 9 slots stated by the user; 5 defaults listed as open questions |
| form | 100 | proportions and fit plausible |
| geometry | 43 | span 864 mm; **3.091 mm long-term sag vs a 2.4 mm allowance — fails** |
| material | 70 | birch plywood; chosen for stiffness-to-mass and fastener behaviour |
| economics | 72 | 58.14 USD priced; 1 line unpriced; 1 line is a bulk tier |
| output | 64 | amber, REVIEW |

Full result:

- **Span 864 mm** = 900 − 2 × 18 mm, because shelves sit between the sides.
- **Deflection** 5wL⁴/(384EI) = 1.546 mm immediate, ×2.0 creep = **3.091 mm** against
  L/360 = 2.4 mm → 129% of allowance, **FAIL**.
- **Tip-over margin 0.166** — 200 N at 90% height against self-weight about the front
  edge → wall anchoring is mandatory, and the cost engine adds the anchor kit.
- **Racking** PASS only because the back panel is a fixed shear diaphragm.
- **Two sheets** of 18 mm at **41% yield** — the grain constraint forces every panel the
  same way. The engine says to batch with another project rather than pretending 80%.
- **30 pocket screws** (2 per shelf end, ≥32 mm from the edge), 9648 mm of edge banding.
- **Cost 58.14 USD**: 2 sheets at US$15.50 (bulk tier at MOQ 400 — flagged as not
  buyable at this quantity) + 1 pack of 500 Kreg screws at US$27.14 (retail). Back
  panel **unpriced**, reported as unpriced rather than guessed.
- Remedies computed, not suggested: 21 mm stock → 1.983 mm; mid-rail → 0.386 mm.

That `3.091 mm` failure is the whole point. The concept document asserted the blob would
say "that 900 mm shelf will sag in 18 mm ply — recommend 25 mm". It does say that, and
it shows the arithmetic.

## Module map — concept vs what exists

| Concept module | Status | Where |
|---|---|---|
| Intent Core | **built** (rule-based; no LLM) | `src/intent/core.js` |
| Reality Engine | **built** (6 weighted dimensions, deterministic) | `src/reality/engine.js` |
| Material Intelligence Layer | **built**, but moduli `verified: false` | `src/engine/materials.js` |
| Temporal Simulation | **partial** — creep factor 2.0 models long-term deflection; no ageing/rust/wear simulation | `src/engine/sag.js` |
| Living Components Library | **partial** — material + joinery libraries exist; no persisted parametric part library | `src/engine/materials.js`, `joinery.js` |
| Sensor-Reality Fusion | **partial** — room contract, access check, telemetry decode, orientation check; **no AR capture** | `src/sensors/` |
| Economic Engine | **built** — sourced price book, tier/MOQ honesty, marginal cost | `src/engine/cost.js`, `vendor/price-book.json` |
| Manufacturing Route Planner | **partial** — nesting + DXF + procurement routing; no machine post-processors | `src/engine/nesting.js`, `src/export/index.js` |
| AI Forge | **not built** — deliberately; the design path is deterministic | — |
| ProtoMatter | **partial** — morph from field to exact rectilinear plan; no physical simulation | `src/blob/shapes.js` |
| Dream State | **built** — 12–16 single-parameter variants, each fully recomputed | `src/reality/engine.js:exploreVariants` |
| Sovereign Memory Crystal | **built** — `output/package.json`, `history.jsonl`, `telemetry-history.jsonl`; nothing leaves disk | `output/` |

## Vendor and service connections

Sourcing was done against live listings (`vendor/sourcing-results.md`, 12/12 BOM lines,
11 with verifiable prices). The registry in `config/services.json` records what is
actually reachable, and the rule it follows is: *a vendor is listed live only if a real
call succeeded or its API docs came back from a tool; everything else is marked
unverified rather than assumed.*

- **Live now (no new credentials):** Alibaba.com product + RFQ data via the sourcing
  toolkit — live price tiers, MOQ, supplier verification status, product URLs.
- **Needs your key:** Digi-Key (`developer.digikey.com`), LCSC OpenAPI (`lcsc.com/docs/openapi`),
  AliExpress Open Platform (affiliate scope).
- **Form-only, no API found:** every sheet-goods and tool retailer, plus the CNC bureaux
  (uMake, Xometry, Hubs). The app generates the RFQ and the DXF; a human sends it.
- **Unverified:** Mouser (docs URL never surfaced), 1688 (third-party claims only).

What the app produces for purchasing: `output/vendor-rfq.md` (a real RFQ asking the
questions that change the price — measured thickness, moisture content, certificates,
tier breaks) and `output/cnc-quote-request.md` + `nested-layout.dxf`.

## Hardware

`firmware/esp32-sensor-node` — BME280 + BH1750 + MPU-6050 on one I2C bus, POSTs one
JSON reading every 5 s to `POST /api/telemetry`. Optional `x-node-token`. Readings
become: room stability advisories, finish advisories, capture-orientation checks, and a
vibration warning that tells you a scan taken now will be noisy. The node holds no design
data — it cannot corrupt a design by failing.

Not flashed on hardware. Wiring, build and verification steps are in the firmware README.

## Honest limitations

1. **Voice is not local.** The UI uses the browser SpeechRecognition API, which in Chrome
   typically sends audio to a server. Typed input is fully local; local STT (Whisper/WASM)
   is not wired up. The UI states which input produced the current design.
2. **No room measurement.** `src/sensors/room.js` consumes a room scan; nothing produces
   one. ARCore Depth / ARKit capture is a defined contract with no implementation.
3. **Structural figures are estimates.** Handbook moduli, first-order beam theory, no
   safety-factor certification, no fastener pull-out analysis, no seismic design.
4. **The nest is not guillotine-constrained.** Fine for a CNC or laser; a table-saw
   operator must re-sequence. Stated in the export.
5. **One currency is totalled at a time.** Lines in other currencies are listed
   separately rather than converted at an invented rate.
6. **The price book is a snapshot** (2026-09-28) with 12 items, not a live feed.

## Build phases to a shippable MVP

| Phase | Deliverable | Success criterion | Complexity |
|---|---|---|---|
| 1 | This core, hardened | 53 tests green; DXF opens in a cutter's software; a real 18 mm sheet produces the parts | done |
| 2 | Room capture (Android) | ARCore depth scan → the `RoomScan` contract; wall width and stud positions within 10 mm of a tape measure | high |
| 3 | Local voice | Whisper-class STT on device; no network call during a design session | medium |
| 4 | Live vendor pricing | Digi-Key + LCSC keys wired in; tier-correct pricing replaces the snapshot | medium |
| 5 | Closed loop | Measured deflection after build feeds back and corrects the modulus used | medium |

## File map

```
src/intent/core.js        intent parsing, intent graph, modifications
src/engine/               materials, sag/deflection, joinery, nesting, cutlist, cost, assembly
src/reality/engine.js     Reality Score, stage scoring, Dream State variant search
src/blob/                 metaball field, marching-squares contour, shape programs, renderer
src/sensors/              room-scan contract + access checks, telemetry decode
src/vendor/vendors.js     supplier registry, RFQ + CNC payload generation, procurement routing
src/export/index.js       CSV, millimetre DXF, SVG nested layout, package JSON
src/pipeline.js           the whole run, stage by stage
bin/blob.mjs              headless CLI
bridge/server.mjs         local HTTP bridge: run, telemetry, SSE, outputs
index.html + src/app.js   the UI
firmware/esp32-sensor-node/  sensor node
config/                   service registry, environment thresholds
vendor/                   price book, sourcing results
tests/                    53 tests
```

## Verify it yourself

```bash
npm test
node bin/blob.mjs "bookshelf 900 wide 1800 tall"          # full trace
node bin/blob.mjs --dream "bookshelf 900 wide"            # Dream State variants
node bin/blob.mjs --sources                               # vendor reachability
node bin/blob.mjs --sensor '{"deviceId":"x","ts":'$(date +%s000)',"tempC":21,"humidityPct":31,"lux":180}'
curl -s localhost:8787/api/bootstrap | head -c 400
```
