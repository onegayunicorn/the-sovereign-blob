import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

import { shelfCheck } from '../src/engine/sag.js';
import { MATERIALS } from '../src/engine/materials.js';

/**
 * Cross-implementation parity between the Kotlin device-side checks and the JavaScript engine.
 *
 * The structural verdict is computed twice: once in `src/engine/sag.js` (bridge, CLI, exports)
 * and once in `android/.../RealityChecks.kt` (on-device, no network). Two implementations of a
 * physical law is two ways to be wrong, so the Kotlin program prints its results and this test
 * asserts the JavaScript engine reproduces them.
 *
 * `android/parity-expected.json` is generated, not hand-written:
 *
 *   kotlinc android/app/src/main/java/dev/sovereignblob/reality/RealityChecks.kt \
 *           tools/parity/ParityMain.kt -include-runtime -d parity.jar && java -jar parity.jar \
 *           > android/parity-expected.json
 *
 * If either implementation drifts, this fails. Regenerate the fixture deliberately, never to
 * make a red test green.
 *
 * SCOPE NOTE: the deflection family is compared. Tip-over is deliberately NOT compared, because
 * each side derives the unit mass differently (the JS engine from the cut list, the Kotlin from
 * an explicit argument), so a mismatch there would say nothing about either implementation.
 */

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const expected = JSON.parse(readFileSync(join(ROOT, 'android', 'parity-expected.json'), 'utf8'));

const material = MATERIALS['birch-plywood'];

const jsCheck = (spanMm, thicknessMm, loadKg) => {
  const selfMassKg = expected.material.depthMm * thicknessMm * spanMm * expected.material.densityKgM3 / 1e9;
  return shelfCheck({
    spanMm,
    thicknessMm,
    depthMm: expected.material.depthMm,
    material,
    loadKg,
    selfMassKg
  });
};

test('the parity fixture is the geometry both implementations share', () => {
  assert.equal(expected.spanMm, 864, 'span must be 900 - 2x18');
  assert.equal(expected.material.depthMm, 300);
  assert.equal(expected.material.elasticModulusMpa, 10300);
  assert.equal(expected.material.loadKg, 25);
});

test('Kotlin and JavaScript agree on deflection for every stocked thickness', () => {
  for (const [thickness, exp] of Object.entries(expected.deflection)) {
    const actual = jsCheck(expected.spanMm, Number(thickness), expected.material.loadKg);
    const where = `${thickness}mm at ${expected.spanMm}mm span`;
    assert.equal(actual.immediateMm, exp.immediateMm, `immediate sag differs at ${where}`);
    assert.equal(actual.longTermMm, exp.longTermMm, `long-term sag differs at ${where}`);
    assert.equal(actual.limitMm, exp.limitMm, `allowance differs at ${where}`);
    assert.equal(actual.utilisation, exp.utilisation, `utilisation differs at ${where}`);
    assert.equal(actual.pass, exp.passes, `pass/fail verdict differs at ${where}`);
  }
});

test('both implementations place the pass/fail boundary at the same thickness', () => {
  const stocked = Object.keys(expected.deflection).map(Number).sort((a, b) => a - b);
  const passing = stocked.filter((t) => jsCheck(expected.spanMm, t, expected.material.loadKg).pass);
  assert.equal(passing[0], expected.minimumPassingThicknessMm, 'minimum passing thickness differs');

  // The definition of done depends on exactly this boundary, so it is asserted by name too.
  assert.equal(jsCheck(expected.spanMm, 18, 25).pass, false, '18 mm must FAIL in both');
  assert.equal(jsCheck(expected.spanMm, 21, 25).pass, true, '21 mm must PASS in both');
});

test('both implementations agree that no stocked thickness passes a wall-to-wall span', () => {
  const wide = expected.wideSpan21mm;
  const actual = jsCheck(wide.spanMm, 21, 35);
  assert.equal(actual.longTermMm, wide.longTermMm, 'long-term sag differs at the wall-fitted span');
  assert.equal(actual.limitMm, wide.limitMm, 'allowance differs at the wall-fitted span');
  assert.equal(actual.pass, false, 'both must refuse a 1758 mm span at 21 mm');
});
