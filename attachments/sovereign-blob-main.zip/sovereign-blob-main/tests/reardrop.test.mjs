import test from 'node:test';
import assert from 'node:assert/strict';

import { tipOverCheck } from '../src/engine/sag.js';
import { buildCutList, DEFAULT_SPEC } from '../src/engine/cutlist.js';
import { buildAssemblySequence } from '../src/engine/assembly.js';
import { runPipeline, dreamState } from '../src/pipeline.js';
import { buildSBM } from '../src/sbm/manifest.js';

/**
 * Fix 3 — the rear-leg drop as a first-class parameter.
 *
 * PHYSICS NOTE, because the blueprint's formula does not survive unit checking. It specified:
 *
 *     tipOverMargin = baseMargin + height * sin(atan(drop / depth))
 *
 * tipOverMargin is a RATIO (restoring moment / overturning moment). The second term is a length
 * in millimetres. At h=1800 that term is ~12, so the "margin" would go from 0.166 to 12.2 — a
 * 73x safety improvement from a 2 mm cut. The mechanism is real but the arithmetic is not.
 *
 * Implemented instead as a horizontal shift of the centre of mass, which is what a tilt
 * actually does, keeping both sides of the ratio as moments. The centre of mass is taken at
 * half the height (a uniform case) rather than the full height, which is what produced the
 * inflated figure.
 */

const ARGS = { massKg: 36.5, depthMm: 300, heightMm: 1800 };

test('zero drop reproduces the previous margin exactly — no regression', () => {
  const withParam = tipOverCheck({ ...ARGS, rearDropMm: 0 });
  const withoutParam = tipOverCheck({ ...ARGS });
  assert.equal(withParam.margin, withoutParam.margin, 'omitting the parameter must equal passing 0');
  assert.equal(withParam.comShiftMm, 0);
  assert.equal(withParam.tiltDeg, 0);
});

test('the margin rises monotonically with the rear drop', () => {
  const margins = [0, 1, 1.5, 2, 4, 8].map((mm) => tipOverCheck({ ...ARGS, rearDropMm: mm }).margin);
  for (let i = 1; i < margins.length; i++) {
    assert.ok(margins[i] > margins[i - 1], `margin must increase at step ${i}: ${margins.join(' -> ')}`);
  }
});

test('the tilt and centre-of-mass shift match the geometry', () => {
  const r = tipOverCheck({ ...ARGS, rearDropMm: 2 });
  const expectedTilt = Math.round((Math.atan(2 / 300) * 180) / Math.PI * 1000) / 1000;
  assert.equal(r.tiltDeg, expectedTilt, 'tilt is atan(drop / depth)');
  assert.ok(Math.abs(r.tiltDeg - 0.38) < 0.01, `expected about 0.38 deg, got ${r.tiltDeg}`);
  // Centre of mass at half height: 900 * sin(0.382 deg) = 6 mm, NOT the 12 mm the blueprint
  // quoted from using the full height.
  assert.ok(Math.abs(r.comShiftMm - 6) < 0.5, `expected about 6 mm, got ${r.comShiftMm}`);
});

test('the improvement is real but modest — it does not replace the wall fixing', () => {
  const base = tipOverCheck({ ...ARGS, rearDropMm: 0 });
  const best = tipOverCheck({ ...ARGS, rearDropMm: 2 });
  assert.ok(best.margin > base.margin, 'the drop must help');
  assert.ok(best.margin < 1, 'it must NOT be enough on its own — the wall anchor is still mandatory');
  const gainPercent = ((best.margin - base.margin) / base.margin) * 100;
  assert.ok(gainPercent < 10, `a 2 mm cut cannot deliver more than a few percent; got ${gainPercent.toFixed(1)}%`);
});

test('the cut list reports the drop, its gain, and carries the default', () => {
  assert.equal(DEFAULT_SPEC.rearDropMm, 1.5, 'the default must be 1.5 mm per the locked design decision');
  const cl = buildCutList({});
  const tip = cl.checks.tipOver;
  assert.equal(tip.rearDropMm, 1.5);
  assert.ok(tip.tiltDeg > 0);
  assert.ok(tip.comShiftMm > 0);
  assert.equal(tip.marginGain, Math.round((tip.margin - tip.marginWithoutRearDrop) * 1000) / 1000);
  assert.ok(tip.marginWithoutRearDrop < tip.margin);
});

test('the assembly sequence tells the builder to make the cut, with the number', () => {
  const cl = buildCutList({});
  const a = buildAssemblySequence(cl);
  const step = a.steps.find((s) => /rear bottom edge|backward lean|rear support/i.test(`${s.title} ${s.detail}`));
  assert.ok(step, 'the rear drop must appear as an assembly step, not only in a config value');
  assert.match(step.detail, /1\.5 mm/, 'the step must carry the actual measurement');
  assert.match(step.detail, /relieving the bottom rear corner/i, 'it must say where to cut');
  assert.match(step.reason, /spirit level/i, 'and how to verify the lean direction');

  // A zero drop must not emit a step telling someone to cut zero millimetres.
  const noDrop = buildCutList({ rearDropMm: 0 });
  const a2 = buildAssemblySequence(noDrop);
  assert.equal(
    a2.steps.some((s) => /rear bottom edge/i.test(`${s.title} ${s.detail}`)),
    false
  );
});

test('the manifest carries the drop as fabrication data and recommends anchoring', () => {
  const result = runPipeline('build me a bookshelf, 1800 tall and 900 wide, shelves 300 deep', { region: 'au-qld-local' });
  const variants = dreamState('build me a bookshelf, 1800 tall and 900 wide, shelves 300 deep', { region: 'au-qld-local' });
  const sbm = buildSBM({
    project: { id: 'proj-rear', name: 'Rear Drop', created: new Date().toISOString(), version: 1 },
    result,
    variants
  });
  assert.ok(sbm.fabrication.rearDrop, 'the manifest must expose the rear drop');
  assert.equal(sbm.fabrication.rearDrop.mm, 1.5);
  assert.match(sbm.fabrication.rearDrop.instruction, /1\.5 mm/);
  assert.ok(
    sbm.reality.recommendations.some((r) => /Wall anchoring is REQUIRED/.test(r)),
    'anchoring must be recommended, because it is the safety gate'
  );
  assert.ok(
    sbm.reality.recommendations.some((r) => /rear drop/.test(r)),
    'the recommendation must state that the lean helps but is not sufficient'
  );
});

test('Fix 2: the highest-scoring variant is exposed as recommended, and anchoring is what wins', () => {
  const variants = dreamState('build me a bookshelf, 1800 tall and 900 wide, shelves 300 deep', { region: 'au-qld-local' });
  assert.ok(variants.recommended, 'exploreVariants must expose the top variant without the caller re-sorting');
  assert.equal(variants.recommended.score, Math.max(...variants.best.map((b) => b.score)), 'recommended must be the best');
  const anchored = variants.best.find((b) => b.change?.anchored === true);
  assert.ok(anchored, 'the anchored variant must be among the best — that is the finding');
  assert.ok(anchored.score > 72, `the anchored variant must beat the free-standing score, got ${anchored.score}`);

  const result = runPipeline('build me a bookshelf, 1800 tall and 900 wide, shelves 300 deep', { region: 'au-qld-local' });
  const sbm = buildSBM({
    project: { id: 'proj-rec', name: 'Recommended', created: new Date().toISOString(), version: 1 },
    result,
    variants
  });
  const line = sbm.reality.recommendations.find((r) => /^RECOMMENDED:/.test(r));
  assert.ok(line, 'the manifest must print the recommended variant');
  assert.match(line, /RECOMMENDED: anchored=true/);
  assert.match(line, /score \d+/, 'the recommendation must carry the score it was chosen on');
  assert.match(line, /variants explored and checked/);
});
