import test from 'node:test';
import assert from 'node:assert/strict';
import { writeFileSync, readFileSync, mkdirSync, rmSync, existsSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

import { runPipeline } from '../src/pipeline.js';
import { parseIntent } from '../src/intent/core.js';
import { buildCutList } from '../src/engine/cutlist.js';
import { buildAssemblySequence } from '../src/engine/assembly.js';
import { buildSBM, validateSBM } from '../src/sbm/manifest.js';
import { buildReplay } from '../src/exports/replay.js';
import { buildBuildPacketPDF, verifyPdf, buildPacketLines } from '../src/exports/pdf.js';
import { toDXF } from '../src/export/index.js';
import { defaultAnchors, validateAnchors, lockAnchor, attemptAnchorChange, unlockAnchor } from '../src/reality/anchors.js';
import { validateRoom } from '../src/sensors/room.js';
import { statusForScore } from '../src/proto/state.js';
import { validateDef, loadSchemas } from '../contracts/validate.mjs';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const TMP = join(ROOT, 'output', 'test-tmp');

const wallScan = { wallWidthMm: 1800, wallHeightMm: 2400, confidence: 0.82, source: 'wall-scan' };

function design(opts = {}) {
  const result = runPipeline(opts.utterance ?? 'build me a bookshelf, 1800 tall and 900 wide, shelves 300 deep', {
    region: 'au-qld-local',
    ...(opts.overrides ? { specOverrides: opts.overrides } : {})
  });
  const assembly = buildAssemblySequence(result.cutList);
  return { result, assembly };
}

function manifest({ overrides, anchors, roomScan = wallScan } = {}) {
  const { result, assembly } = design({ overrides });
  const project = { id: 'proj-test', name: 'Room Shelf', created: new Date().toISOString(), version: 1 };
  const set =
    anchors ??
    defaultAnchors({ spec: { ...result.cutList.spec, wallMounted: true }, cutList: result.cutList, cost: result.cost, room: roomScan });
  const sbm = buildSBM({ project, result: { ...result, assembly }, roomScan, overrides: overrides ?? {}, anchors: set });
  return { project, result, assembly, sbm, anchors: set };
}

// ---------------------------------------------------------------------------
// Sprint 2 — Intent Engine
// ---------------------------------------------------------------------------
test('SB-011: "Build a bookshelf here" yields the goal, a location, and it persists', () => {
  const intent = parseIntent('Build a bookshelf here');
  assert.equal(intent.kind, 'bookshelf', 'goal must be extracted');
  // The two spec variants disagree on this value (section 7 says "wall", SB-011 says
  // "current_view"). Both are accepted; the discrepancy is recorded in SPEC-DEVIATIONS.md.
  assert.ok(['current_view', 'wall'].includes(intent.location), `location must be identified, got ${intent.location}`);
  assert.ok(intent.slots.widthMm.value > 0, 'the intent must carry usable dimensions, not just a label');
});

test('SB-011: the intent survives a modification rather than being replaced by it', () => {
  const intent = parseIntent('build me a bookshelf, make it taller');
  assert.equal(intent.kind, 'bookshelf', 'the goal must survive the modification');
  assert.ok(intent.modifications.some((m) => m.slot === 'heightMm'), 'the change must be recorded as a delta');
});

// ---------------------------------------------------------------------------
// Sprint 3 — Reality Engine
// ---------------------------------------------------------------------------
test('SB-020: a Reality Score is returned, in range, with a status', () => {
  const { result } = design();
  assert.ok(Number.isFinite(result.reality.score));
  assert.ok(result.reality.score >= 0 && result.reality.score <= 100);
  assert.ok(['BLOCKED', 'CAUTION', 'READY'].includes(statusForScore(result.reality.score)));
});

test('SB-021: 18 mm FAILS and 21 mm PASSES, as the definition of done requires', () => {
  const fail = buildCutList({ widthMm: 900, heightMm: 1800, depthMm: 300, shelves: 5, thicknessMm: 18, loadPerShelfKg: 25 });
  const pass = buildCutList({ widthMm: 900, heightMm: 1800, depthMm: 300, shelves: 5, thicknessMm: 21, loadPerShelfKg: 25 });
  assert.equal(fail.checks.shelfDeflection.pass, false, '18 mm must fail');
  assert.equal(pass.checks.shelfDeflection.pass, true, '21 mm must pass');
  assert.ok(fail.checks.shelfDeflection.longTermMm > fail.checks.shelfDeflection.limitMm);
  assert.ok(pass.checks.shelfDeflection.longTermMm < pass.checks.shelfDeflection.limitMm);
});

test('SB-022: a failing design states the failure AND the correction, with numbers', () => {
  const { sbm } = manifest({ overrides: { thicknessMm: 18 } });
  assert.equal(sbm.reality.checks.structural, 'FAIL');
  assert.ok(sbm.reality.recommendations.length > 0, 'a blocked design must recommend a correction');
  const decision = sbm.audit.realityDecisions.find((d) => /sag/i.test(d.reason) || /Correction/i.test(d.decision));
  assert.ok(decision, 'the audit trail must record the structural decision');
  assert.match(decision.reason, /\d/, 'the explanation must contain actual measurements, not adjectives');
});

// ---------------------------------------------------------------------------
// Sprint 4 — SBM
// ---------------------------------------------------------------------------
test('SB-030: a new project creates a schema-valid manifest with every section present', () => {
  const { sbm } = manifest({ overrides: { thicknessMm: 21 } });
  const v = validateDef(sbm, 'sbmV02', loadSchemas());
  assert.equal(v.valid, true, `manifest must validate: ${v.errors.map((e) => e.path + ':' + e.message).join('; ')}`);
  for (const key of ['project', 'intent', 'spatial', 'anchors', 'reality', 'materials', 'components', 'assembly', 'costing', 'fabrication', 'exports', 'audit']) {
    assert.ok(key in sbm, `SBM must carry "${key}"`);
  }
  assert.equal(sbm.sbmVersion, '0.2');
});

test('SB-031: save and load round-trips with no data loss', () => {
  const { sbm, result } = manifest({ overrides: { thicknessMm: 21 } });
  mkdirSync(TMP, { recursive: true });
  const path = join(TMP, 'roundtrip.sbm.json');
  writeFileSync(path, JSON.stringify(sbm, null, 2));
  const loaded = JSON.parse(readFileSync(path, 'utf8'));
  assert.deepEqual(loaded, sbm, 'the manifest must survive a file round-trip byte-for-byte in value');
  assert.equal(loaded.components.length, sbm.components.length);
  assert.equal(loaded.reality.score, sbm.reality.score);
  assert.equal(loaded.materials[0].thickness, result.cutList.spec.thicknessMm);
  rmSync(TMP, { recursive: true, force: true });
});

// ---------------------------------------------------------------------------
// Sprint 5 — Room scan
// ---------------------------------------------------------------------------
test('SB-040: a wall scan yields dimensions with a confidence score', () => {
  const { sbm } = manifest();
  assert.equal(sbm.spatial.wallWidth, 1800);
  assert.equal(sbm.spatial.wallHeight, 2400);
  assert.ok(sbm.spatial.confidence > 0 && sbm.spatial.confidence <= 1, 'confidence must be present and in range');
  assert.equal(sbm.spatial.source, 'wall-scan');
});

test('SB-040: no scan means confidence 0 and a stated source, never a fabricated measurement', () => {
  const { sbm } = manifest({ roomScan: null });
  assert.equal(sbm.spatial.confidence, 0);
  assert.equal(sbm.spatial.source, 'assumed-from-intent');
});

test('SB-041: a design wider than the wall is rejected, and constraints are applied', () => {
  const room = { wallWidthMm: 800, wallHeightMm: 2400, confidence: 0.8, source: 'wall-scan' };
  const { result } = design();
  const anchors = defaultAnchors({ spec: { ...result.cutList.spec, wallMounted: true }, cutList: result.cutList, cost: result.cost, room });
  const check = validateAnchors(anchors, { spec: result.cutList.spec, cutList: result.cutList, cost: result.cost, room });
  const bounds = check.violations.find((v) => v.anchorId === 'anchor-wall-bounds-001');
  assert.ok(bounds, 'a 900 mm unit on an 800 mm wall must be flagged');
  assert.equal(bounds.blocking, false, 'unlocked anchors advise rather than block');
  // validateRoom(scan, unitDims): the design is checked against the room envelope.
  // Two different checks, on purpose: the anchor enforces the WALL width, while validateRoom
  // enforces the ROOM envelope. Testing them separately is what proves neither is a no-op.
  const roomReport = validateRoom(
    { widthMm: 800, heightMm: 2400, depthMm: 3200, wallWidthMm: 800, wallHeightMm: 2400, doorWidthMm: 800, confidence: 0.8 },
    { widthMm: 900, heightMm: 1800, depthMm: 300 }
  );
  assert.equal(roomReport.scanned, true);
  assert.equal(roomReport.checks.footprint.pass, false, 'a 900 mm unit does not fit an 800 mm room envelope');
  assert.ok(roomReport.issues.length > 0, 'the room model must state the constraint it applied');
});

// ---------------------------------------------------------------------------
// Sprint 6 — Exports
// ---------------------------------------------------------------------------
test('SB-050: the PDF contains the cut list, the materials and the assembly steps', () => {
  const { sbm, result, assembly } = manifest({ overrides: { thicknessMm: 21 } });
  const pdf = buildBuildPacketPDF({ sbm, result, assembly });
  const text = pdf.bytes.toString('latin1');
  for (const needle of ['Build Packet', 'Cut list', 'Material', 'Assembly sequence', 'Tools required', 'Load rating', 'Safety warnings', 'TOTAL:']) {
    assert.ok(text.includes(needle), `build packet is missing "${needle}"`);
  }
  const lines = buildPacketLines({ sbm, result, assembly });
  assert.ok(lines.some((l) => /21 mm/.test(l.text)), 'the packet must state the actual thickness that was validated');
});

test('SB-050: the PDF is structurally valid — every xref offset resolves', () => {
  const { sbm, result, assembly } = manifest({ overrides: { thicknessMm: 21 } });
  const pdf = buildBuildPacketPDF({ sbm, result, assembly });
  const v = verifyPdf(pdf.bytes);
  assert.equal(v.ok, true, `PDF structure invalid: ${v.problems.join('; ')}`);
  assert.ok(v.pages >= 1);
  assert.ok(v.objectsChecked >= 5);
});

test('SB-051: the DXF is millimetre geometry with a closed, finite entity set', () => {
  const { result } = design({ overrides: { thicknessMm: 21 } });
  const dxf = toDXF(result.cutList);
  assert.match(dxf, /\$INSUNITS/);
  assert.match(dxf, /^0\nSECTION/m);
  assert.match(dxf, /EOF\s*$/);
  const xs = [...dxf.matchAll(/\n10\n(-?[\d.]+)/g)].map((m) => Number(m[1]));
  const ys = [...dxf.matchAll(/\n20\n(-?[\d.]+)/g)].map((m) => Number(m[1]));
  assert.ok(xs.length > 10 && ys.length > 10, 'expected geometry');
  for (const v of [...xs, ...ys]) {
    assert.ok(Number.isFinite(v), 'DXF coordinates must be finite');
    assert.ok(v >= 0, `negative DXF coordinate ${v}`);
  }
  // A LINE entity needs both endpoints; a half-written entity is a corrupt DXF.
  const lines = (dxf.match(/\n0\nLINE\n/g) || []).length;
  assert.ok(lines > 0);
  assert.equal(xs.length, lines, 'every LINE must carry a start point');
  assert.equal(ys.length, lines, 'every LINE must carry a start point');
});

test('SB-052: the replay contains the voice history, the rejected step, and the corrections', () => {
  const { project, result, assembly, anchors, sbm } = manifest({ overrides: { thicknessMm: 18 } });
  const anchorResult = validateAnchors(anchors, { spec: result.cutList.spec, cutList: result.cutList, cost: result.cost, room: wallScan });
  const replay = buildReplay({
    project,
    result: { ...result, assembly },
    anchors,
    anchorResult,
    overrides: { thicknessMm: 18 },
    exports: sbm.exports
  });
  const kinds = new Set(replay.entries.map((e) => e.kind));
  for (const k of ['voice', 'intent', 'engineering', 'reality', 'physical']) {
    assert.ok(kinds.has(k), `replay is missing "${k}" entries`);
  }
  assert.ok(replay.entries.some((e) => /Voice input/.test(e.detail)), 'the raw utterance must be recorded');
  assert.ok(replay.entries.some((e) => /REJECTED/.test(e.detail)), 'the failed thickness must appear, or the replay is a sales document');
  assert.ok(replay.entries.some((e) => /pending/.test(e.detail)), 'an unbuilt object must be described as a prediction');
  const v = validateDef(replay, 'replayTimeline', loadSchemas());
  assert.equal(v.valid, true);
});

// ---------------------------------------------------------------------------
// Sprint 7 — Reality Anchors
// ---------------------------------------------------------------------------
test('SB-060: a locked anchor cannot be changed, and the refusal explains itself', () => {
  const { result } = design();
  let anchors = defaultAnchors({ spec: { ...result.cutList.spec, wallMounted: true }, cutList: result.cutList, cost: result.cost, room: wallScan });
  anchors = lockAnchor(anchors, 'anchor-load-001');
  // The ceiling is the spec's stated safe working load, NOT the load this design happens to
  // request. A ceiling derived from the design it constrains could never be violated, which
  // would make the anchor decorative — and that is exactly the concept drift anchors exist to
  // stop. The design's own 25 kg sits under the 35 kg ceiling, so there is no violation here.
  const limit = anchors.find((a) => a.anchorId === 'anchor-load-001').value;
  assert.equal(limit, 35, 'the ceiling must be the stated safe working load, independent of the request');
  assert.ok(result.cutList.spec.loadPerShelfKg <= limit, 'this design should sit under the ceiling');
  const attempt = attemptAnchorChange(anchors, 'anchor-load-001', 50);
  assert.equal(attempt.accepted, false);
  assert.equal(attempt.blocking, true);
  assert.match(attempt.message, new RegExp(`locked at ${limit} kg`));
  assert.match(attempt.recommendation, /Unlock/);
  // Unlocking first is the only path, and then it is allowed.
  const freed = unlockAnchor(anchors, 'anchor-load-001');
  assert.equal(attemptAnchorChange(freed, 'anchor-load-001', 50).accepted, true);
});

test('SB-060: violating a locked anchor forces BLOCKED even when the score band says otherwise', () => {
  const { result } = design({ overrides: { thicknessMm: 18 } });
  let anchors = defaultAnchors({ spec: { ...result.cutList.spec, wallMounted: true }, cutList: result.cutList, cost: result.cost, room: wallScan });
  anchors = lockAnchor(anchors, 'anchor-load-001');
  // Raise the design load above the locked 35 kg ceiling.
  const { sbm } = manifest({ overrides: { thicknessMm: 18, loadPerShelfKg: 60 }, anchors });
  assert.equal(sbm.reality.status, 'BLOCKED', 'a locked anchor violation must block');
  assert.ok(sbm.reality.blockers.length > 0, 'the block must carry an explanation');
  const ceiling = anchors.find((a) => a.anchorId === 'anchor-load-001').value;
  assert.match(sbm.reality.blockers.join(' '), new RegExp(`${ceiling} kg`));
  assert.ok(sbm.audit.anchorViolations.some((v) => v.locked), 'the violation must be recorded in the audit trail');
});

test('SB-060: an unlocked violation advises without blocking, so first drafts can iterate', () => {
  const { sbm } = manifest({ overrides: { thicknessMm: 21, loadPerShelfKg: 60 } });
  assert.ok(sbm.reality.warnings.some((w) => /Maximum Shelf Load/.test(w)), 'the advisory must be raised');
  assert.equal(sbm.reality.blockers.length, 0, 'an unlocked anchor must not block the build');
});

// ---------------------------------------------------------------------------
// Sprint 8 — Physical validation feedback
// ---------------------------------------------------------------------------
test('SB-071: measured results feed back into the manifest audit field', () => {
  const measured = {
    measuredAt: new Date().toISOString(),
    actualImmediateSagMm: 1.7,
    actualLongTermSagMm: 3.2,
    measuredAfterDays: 30,
    actualThicknessMm: 17.6
  };
  const { project, result, assembly, anchors } = manifest({ overrides: { thicknessMm: 18 } });
  const sbm = buildSBM({ project, result: { ...result, assembly }, roomScan: wallScan, overrides: { thicknessMm: 18 }, physicalValidation: measured, anchors });
  assert.deepEqual(sbm.audit.physicalValidation, measured, 'the measurement must land in the audit field');
  const v = validateDef(sbm, 'sbmV02', loadSchemas());
  assert.equal(v.valid, true, 'a manifest carrying physical validation must still validate');
});

// ---------------------------------------------------------------------------
// Export gate: the spec requires schema + reality + anchor validation before export
// ---------------------------------------------------------------------------
test('export is gated: a manifest blocked by a locked anchor fails validation', () => {
  const first = manifest({ overrides: { thicknessMm: 18, loadPerShelfKg: 60 } });
  const locked = lockAnchor(first.anchors, 'anchor-load-001');
  const { result, sbm } = manifest({ overrides: { thicknessMm: 18, loadPerShelfKg: 60 }, anchors: locked });
  const report = validateSBM(sbm, { cutList: result.cutList, cost: result.cost, spec: result.cutList.spec, room: wallScan });
  assert.equal(sbm.reality.status, 'BLOCKED', 'the locked anchor must force BLOCKED');
  assert.equal(report.schemaValid, true, 'the manifest is well-formed...');
  assert.equal(report.realityValid, false, '...but reality validation must fail');
  assert.equal(report.anchorsValid, false, 'the anchor gate must fail too');
  assert.equal(report.allPassed, false, 'export must be refused');
});

test('cleanup: no stray test artifacts', () => {
  if (existsSync(TMP)) rmSync(TMP, { recursive: true, force: true });
  assert.equal(existsSync(TMP), false);
});
