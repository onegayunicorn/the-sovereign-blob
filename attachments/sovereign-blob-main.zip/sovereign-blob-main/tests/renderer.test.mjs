import test from 'node:test';
import assert from 'node:assert/strict';

import { planViewport, drawPlan, hexToRgb, PALETTE } from '../src/blob/renderer.js';
import { buildCutList, DEFAULT_SPEC } from '../src/engine/cutlist.js';
import { rectilinearPlan } from '../src/blob/shapes.js';

/**
 * The renderer is exercised against a recording stub of CanvasRenderingContext2D.
 * That catches the failure modes that actually matter here — NaN coordinates, missing
 * API calls, a viewport that puts geometry off-canvas — without a browser. What it
 * cannot catch is anything about pixels, so the visual layout still needs one human
 * look in a real browser before shipping.
 */
function stubCtx() {
  const calls = [];
  const record = (name) => (...args) => {
    calls.push({ name, args });
  };
  return {
    calls,
    clearRect: record('clearRect'),
    fillRect: record('fillRect'),
    strokeRect: record('strokeRect'),
    beginPath: record('beginPath'),
    moveTo: record('moveTo'),
    lineTo: record('lineTo'),
    stroke: record('stroke'),
    fillText: record('fillText'),
    save: record('save'),
    restore: record('restore'),
    translate: record('translate'),
    rotate: record('rotate'),
    set fillStyle(v) { calls.push({ name: 'fillStyle', args: [v] }); },
    set strokeStyle(v) { calls.push({ name: 'strokeStyle', args: [v] }); },
    set lineWidth(v) { calls.push({ name: 'lineWidth', args: [v] }); },
    set font(v) { calls.push({ name: 'font', args: [v] }); },
    set globalAlpha(v) { calls.push({ name: 'globalAlpha', args: [v] }); }
  };
}

test('hex colours convert for the field shading', () => {
  assert.deepEqual(hexToRgb('#00FFCC'), [0, 255, 204]);
  assert.deepEqual(hexToRgb(PALETTE.fail), [255, 59, 48]);
});

test('the plan viewport letterboxes without distorting the design', () => {
  const vp = planViewport({ widthMm: 900, heightMm: 1800 }, 720, 320, 28);
  // limited by height: (320 - 56) / 1800
  assert.ok(Math.abs(vp.scale - 264 / 1800) < 1e-9);
  const [x0, y0] = vp.toPx(0, 0);
  const [x1, y1] = vp.toPx(900, 1800);
  assert.ok(x0 > 0 && x1 < 720, 'geometry must sit inside the canvas horizontally');
  assert.ok(y0 >= 27 && y1 <= 293, 'geometry must sit inside the canvas vertically');
  // aspect ratio preserved
  const drawnAspect = (x1 - x0) / (y1 - y0);
  assert.ok(Math.abs(drawnAspect - 900 / 1800) < 1e-9);
});

test('drawPlan renders every part and never emits a NaN coordinate', () => {
  const cutList = buildCutList({ ...DEFAULT_SPEC, thicknessMm: 18 });
  const plan = rectilinearPlan(cutList);
  const ctx = stubCtx();
  drawPlan(ctx, plan, { width: 720, height: 320, colour: PALETTE.secondary });

  const names = ctx.calls.map((c) => c.name);
  assert.ok(names.includes('clearRect'), 'must clear the previous frame');
  assert.ok(names.filter((n) => n === 'fillRect').length >= plan.rects.length, 'one fill per part');
  assert.ok(names.filter((n) => n === 'strokeRect').length >= plan.rects.length + 1, 'outline plus parts');

  for (const call of ctx.calls) {
    for (const a of call.args) {
      if (typeof a === 'number') {
        assert.ok(Number.isFinite(a), `${call.name} received a non-finite number: ${a}`);
      }
    }
  }
  // dimensions are labelled
  assert.ok(ctx.calls.some((c) => c.name === 'fillText' && String(c.args[0]).includes('900 mm')));
  assert.ok(ctx.calls.some((c) => c.name === 'fillText' && String(c.args[0]).includes('1800 mm')));
});

test('a plan with a zero-dimension does not produce invalid geometry', () => {
  const ctx = stubCtx();
  drawPlan(
    ctx,
    { kind: 'plan', units: 'mm', widthMm: 900, heightMm: 1800, rects: [{ id: 'x', x: 0, y: 0, w: 0, h: 0, kind: 'shelf' }] },
    { width: 400, height: 400, colour: PALETTE.primary }
  );
  for (const call of ctx.calls) {
    for (const a of call.args) {
      if (typeof a === 'number') assert.ok(Number.isFinite(a));
    }
  }
});
