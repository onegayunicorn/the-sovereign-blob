import test from 'node:test';
import assert from 'node:assert/strict';

import { runPipeline } from '../src/pipeline.js';
import { loadRegions, resolveRegion, regionSheet } from '../src/engine/regions.js';
import { buildCutList } from '../src/engine/cutlist.js';
import { buildCncQuoteRequest } from '../src/vendor/vendors.js';
import { toDXF } from '../src/export/index.js';

test('the default region is unchanged, so adding profiles did not move existing numbers', () => {
  assert.equal(loadRegions().default, 'cn-bulk');
  const r = runPipeline('bookshelf 900 wide 1800 tall');
  assert.equal(r.cost.region, null, 'no region means legacy behaviour');
  assert.equal(r.cost.currency, 'USD');
  assert.equal(r.cost.tax, null);
});

test('an unknown region fails loudly instead of silently falling back', () => {
  assert.throws(() => resolveRegion('au-goldcoast-typo'), /unknown region/);
});

test('the AU local profile switches sheet, currency and price source together', () => {
  const region = resolveRegion('au-qld-local');
  assert.equal(region.supplyMode, 'local-fabrication');
  assert.equal(region.currency, 'AUD');
  assert.deepEqual(regionSheet(region), { lengthMm: 2400, widthMm: 1200 });

  const r = runPipeline('bookshelf 900 wide 1800 tall', { region: 'au-qld-local' });
  assert.equal(r.cost.currency, 'AUD');
  assert.equal(r.cost.region.id, 'au-qld-local');
  assert.ok(r.cost.tax, 'AU profile must apply GST rather than quoting a GST-free price');
  assert.equal(r.cost.tax.rate, 0.1);
  // Tax must be added to the total but must not be counted as a purchased line.
  const lineSum = r.cost.lines.reduce((s, l) => s + l.lineTotal, 0);
  assert.ok(Math.abs(r.cost.total - (lineSum + r.cost.tax.amount)) < 0.01);
  assert.equal(
    r.cost.lines.some((l) => l.role === 'tax'),
    false,
    'GST must not appear as a line item or it inflates pricedLines'
  );
});

test('every placed part fits inside the sheet it is nested on', () => {
  for (const region of ['cn-bulk', 'au-qld-local']) {
    const prof = resolveRegion(region);
    const sheet = regionSheet(prof);
    const cl = buildCutList({}, { sheet });
    const all = [...cl.nesting.carcass.sheets.flatMap((s) => s.parts), ...cl.nesting.back.sheets.flatMap((s) => s.parts)];
    assert.ok(all.length > 0, `${region}: expected placed parts`);
    for (const p of all) {
      assert.ok(Number.isFinite(p.x) && Number.isFinite(p.y), `${region}: non-finite part position`);
      assert.ok(p.x >= 0 && p.y >= 0, `${region}: negative part position`);
      // Packer convention, checked against an actual placed-part dump rather than assumed:
      // x runs along the sheet LENGTH axis carrying the part's length in `w`; y runs along
      // the WIDTH axis carrying the part's depth in `h`. The first version of this test had
      // the axes swapped and so reported correct geometry as a failure.
      assert.ok(
        p.x + p.w <= sheet.lengthMm + 0.01,
        `${region}: part overruns sheet length (${p.x} + ${p.w} > ${sheet.lengthMm})`
      );
      assert.ok(
        p.y + p.h <= sheet.widthMm + 0.01,
        `${region}: part overruns sheet width (${p.y} + ${p.h} > ${sheet.widthMm})`
      );
    }
  }
});

test('the AU profile still fits the design, so switching supply mode did not break nesting', () => {
  const r = runPipeline('bookshelf 900 wide 1800 tall', { region: 'au-qld-local' });
  assert.equal(r.cutList.nesting.carcass.unplaced.length, 0, 'no part may be left unplaced');
  assert.ok(r.cutList.nesting.carcassSheetCount >= 1);
  // 1800 mm sides must still fit a 2400 mm sheet, or the AU switch is unusable.
  assert.ok(r.cutList.nesting.carcassSheetCount <= 2, 'expected the same sheet count as the bulk profile');
});

test('a Mode A job lists only bureaux on the same continent', () => {
  const cl = buildCutList({});
  const au = buildCncQuoteRequest(cl, { regionId: 'au-qld-local' });
  assert.ok(au.services.length >= 3, `expected local bureaux, got ${au.services.length}`);
  for (const s of au.services) {
    assert.equal(s.region, 'au-qld-local', `${s.name} is not a Gold Coast / Brisbane target`);
  }
  const any = buildCncQuoteRequest(cl, {});
  assert.ok(any.services.length > au.services.length, 'unfiltered call should list everything');
});

test('DXF coordinates are finite and non-negative for both profiles', () => {
  for (const region of ['cn-bulk', 'au-qld-local']) {
    const r = runPipeline('bookshelf 900 wide 1800 tall', { region });
    const dxf = toDXF(r.cutList);
    assert.match(dxf, /\$INSUNITS/);
    assert.match(dxf, /EOF/);
    const xs = [...dxf.matchAll(/\n10\n(-?[\d.]+)/g)].map((m) => Number(m[1]));
    const ys = [...dxf.matchAll(/\n20\n(-?[\d.]+)/g)].map((m) => Number(m[1]));
    assert.ok(xs.length > 20 && ys.length > 20, `${region}: expected many coordinates`);
    for (const v of [...xs, ...ys]) {
      assert.ok(Number.isFinite(v), `${region}: non-finite coordinate`);
      assert.ok(v >= 0, `${region}: negative coordinate ${v}`);
    }
  }
});
