import test from 'node:test';
import assert from 'node:assert/strict';

import { fieldAt, isInside, contour, surfaceBounds, centroid, describeSurface, DEFAULT_THRESHOLD } from '../src/blob/field.js';
import { amorphous, bookshelfShape, morph, rectilinearPlan, elevations } from '../src/blob/shapes.js';
import { buildCutList, DEFAULT_SPEC } from '../src/engine/cutlist.js';

test('the field falls off with distance and is finite everywhere', () => {
  const nodes = [{ x: 0.5, y: 0.5, r: 0.2, w: 1 }];
  assert.ok(fieldAt(nodes, 0.5, 0.5) > fieldAt(nodes, 0.8, 0.5));
  const atNode = fieldAt(nodes, 0.5, 0.5);
  assert.ok(Number.isFinite(atNode), 'must not be Infinity exactly at a node');
  assert.equal(isInside(nodes, 0.5, 0.5), true);
  assert.equal(isInside(nodes, 0.99, 0.99), false);
});

test('a single node produces a closed contour of roughly the right size', () => {
  const nodes = [{ x: 0.5, y: 0.5, r: 0.25, w: 1 }];
  const lines = contour(nodes, { res: 128 });
  assert.ok(lines.length >= 1);
  const b = surfaceBounds(nodes, { res: 128 });
  assert.equal(b.empty, false);
  // F = r^2/d^2 = threshold  ->  d = r/sqrt(threshold) = 0.25, so diameter ~0.5
  assert.ok(Math.abs(b.w - 0.5) < 0.03, `expected width ~0.5, got ${b.w}`);
  assert.ok(Math.abs(b.h - 0.5) < 0.03);
  const c = centroid(nodes, { res: 96 });
  assert.ok(Math.abs(c.x - 0.5) < 0.01);
});

test('the amorphous seed is deterministic and reproducible', () => {
  const a = describeSurface(amorphous(7).nodes, { res: 48 });
  const b = describeSurface(amorphous(7).nodes, { res: 48 });
  assert.deepEqual(a, b);
  const other = describeSurface(amorphous(8).nodes, { res: 48 });
  assert.notDeepEqual(a.bounds.hits, other.bounds.hits);
});

test('morph is continuous: t=0 is the start shape, t=1 is the target shape', () => {
  const start = amorphous(3);
  const target = bookshelfShape({ widthMm: 900, heightMm: 1800, shelves: 5 });
  const at0 = describeSurface(morph(start, target, 0).nodes, { res: 64 });
  const at1 = describeSurface(morph(start, target, 1).nodes, { res: 64 });
  const startSurf = describeSurface(start.nodes, { res: 64 });
  const targetSurf = describeSurface(target.nodes, { res: 64 });
  assert.ok(Math.abs(at0.bounds.w - startSurf.bounds.w) < 1e-6);
  assert.ok(Math.abs(at1.bounds.w - targetSurf.bounds.w) < 1e-6);
});

test('halfway through the morph the surface is a blend, not a jump', () => {
  const start = amorphous(11);
  const target = bookshelfShape({ widthMm: 900, heightMm: 1800, shelves: 5 });
  const half = surfaceBounds(morph(start, target, 0.5).nodes, { res: 64 });
  const s = surfaceBounds(start.nodes, { res: 64 });
  const t = surfaceBounds(target.nodes, { res: 64 });
  assert.ok(half.hits > Math.min(s.hits, t.hits) * 0.5);
  assert.ok(half.hits < Math.max(s.hits, t.hits) * 1.5);
});

test('a tall bookshelf shape is taller than it is wide', () => {
  const surf = surfaceBounds(bookshelfShape({ widthMm: 600, heightMm: 1800, shelves: 6 }).nodes, { res: 96 });
  assert.ok(surf.h > surf.w, `expected a portrait shape, got ${surf.w} x ${surf.h}`);
});

test('the settled plan uses exact cut-list geometry, not an approximation', () => {
  const cl = buildCutList({ ...DEFAULT_SPEC, widthMm: 900, heightMm: 1800, depthMm: 300, shelves: 5, thicknessMm: 18 });
  const plan = rectilinearPlan(cl);
  assert.equal(plan.units, 'mm');
  assert.equal(plan.widthMm, 900);
  assert.equal(plan.heightMm, 1800);
  const sides = plan.rects.filter((r) => r.kind === 'side');
  assert.equal(sides.length, 2);
  assert.equal(sides[0].w, 18);
  assert.equal(sides[0].h, 1800);
  const shelves = plan.rects.filter((r) => r.kind === 'shelf');
  assert.equal(shelves.length, 5);
  shelves.forEach((s) => {
    assert.equal(s.w, 900 - 36, 'shelf must sit between the sides');
    assert.ok(s.x >= 0 && s.x + s.w <= 900);
    assert.ok(s.y >= 0 && s.y + s.h <= 1800, `shelf at y=${s.y} must stay inside the unit`);
  });
  // no two shelves at the same height
  const ys = new Set(shelves.map((s) => s.y));
  assert.equal(ys.size, shelves.length);
});

test('elevation clear bays are consistent with the shelf positions', () => {
  const cl = buildCutList({ ...DEFAULT_SPEC, thicknessMm: 18 });
  const e = elevations(cl);
  assert.equal(e.front.shelfYs.length, 5);
  assert.equal(e.clearBaysMm.length, 4);
  assert.ok(e.clearBaysMm.every((b) => b > 0), 'clear bays must be positive');
  // clearBayMm is derived in normaliseSpec; the elevation must agree with it to 1 mm
  assert.ok(Math.abs(e.clearBaysMm[0] - cl.clearBayMm) <= 1, `elevation ${e.clearBaysMm[0]} vs spec ${cl.clearBayMm}`);
  assert.ok(e.clearBaysMm.every((b) => b === e.clearBaysMm[0]), 'equal bays in a uniform layout');
});

test('the surface report is a complete description of the blob state', () => {
  const report = describeSurface(bookshelfShape({}).nodes, { res: 48 });
  assert.ok(report.polylines >= 1);
  assert.ok(report.perimeter > 0);
  assert.equal(report.threshold, DEFAULT_THRESHOLD);
  assert.equal(report.bounds.empty, false);
});
