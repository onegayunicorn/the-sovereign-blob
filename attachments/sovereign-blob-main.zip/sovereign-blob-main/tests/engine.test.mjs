import test from 'node:test';
import assert from 'node:assert/strict';

import { buildCutList, normaliseSpec, DEFAULT_SPEC } from '../src/engine/cutlist.js';
import { shelfCheck, secondMomentOfArea, tipOverCheck } from '../src/engine/sag.js';
import { selectJoinery, JOINERY } from '../src/engine/joinery.js';
import { resolveMaterial, alternativesFor, MATERIALS } from '../src/engine/materials.js';
import { packSheets, auditLayout } from '../src/engine/nesting.js';
import { buildAssemblySequence } from '../src/engine/assembly.js';
import { costBuild } from '../src/engine/cost.js';

test('second moment of area matches the closed-form value', () => {
  // I = b*h^3/12 for a 300 mm deep, 18 mm thick shelf
  assert.equal(secondMomentOfArea(300, 18), 145800);
  assert.equal(secondMomentOfArea(300, 25), 390625);
});

test('the default 900 mm bookshelf fails the sag check at 18 mm and passes at 21 mm', () => {
  const eighteen = buildCutList({ ...DEFAULT_SPEC, thicknessMm: 18 });
  const twentyOne = buildCutList({ ...DEFAULT_SPEC, thicknessMm: 21 });

  assert.equal(eighteen.spanMm, 864, 'span must be width minus two side thicknesses');
  assert.equal(eighteen.checks.shelfDeflection.pass, false);
  assert.ok(eighteen.checks.shelfDeflection.utilisation > 1.2, 'should be clearly over');

  assert.equal(twentyOne.checks.shelfDeflection.pass, true);
  assert.ok(twentyOne.checks.shelfDeflection.longTermMm < eighteen.checks.shelfDeflection.longTermMm);

  // And the failure must carry a usable remedy, not just a warning.
  assert.ok(eighteen.remedy.thickerPasses);
  assert.ok(eighteen.remedy.midRailAtHalfSpanPasses);
  // Halving the span must reduce deflection by roughly a factor of 16 (L^4 law).
  const ratio = eighteen.checks.shelfDeflection.longTermMm / eighteen.remedy.midRailDeflectionMm;
  assert.ok(ratio > 7 && ratio < 9, `expected ~8x (L^4 with the extra self-mass), got ${ratio}`);
});

test('with a fixed payload, deflection scales as the cube of span', () => {
  // delta = 5wL^4/(384EI), and w = load/L, so a fixed total load gives delta ~ L^3.
  // (A fixed load PER METRE would give L^4.) This distinction is the whole reason the
  // model takes kilograms per shelf rather than a line load: a shelf holds 25 kg
  // whatever its span, so longer shelves get disproportionately worse.
  const base = { loadKg: 25, material: MATERIALS['birch-plywood'], thicknessMm: 18, depthMm: 300 };
  const a = shelfCheck({ ...base, spanMm: 500, selfMassKg: 0 });
  const b = shelfCheck({ ...base, spanMm: 1000, selfMassKg: 0 });
  const ratio = b.immediateMm / a.immediateMm;
  assert.ok(Math.abs(ratio - 8) < 0.05, `expected ~8x for double span at fixed load, got ${ratio}`);
});

test('a tall deep unit needs wall anchoring, a low bench does not', () => {
  const tall = tipOverCheck({ massKg: 35, depthMm: 300, heightMm: 1800 });
  const low = tipOverCheck({ massKg: 35, depthMm: 600, heightMm: 450 });
  assert.equal(tall.anchoredRequired, true);
  assert.equal(low.anchoredRequired, false);
});

test('joinery selection respects material chemistry, and substitutes with a reason', () => {
  const mdf = resolveMaterial('mdf');
  const auto = selectJoinery({ material: mdf, thicknessMm: 18 });
  assert.equal(auto.id, 'confirmat', 'MDF must not get edge screws');

  const requested = selectJoinery({ material: mdf, thicknessMm: 18, requested: 'pocket-screw' });
  assert.equal(requested.substituted, true);
  assert.notEqual(requested.id, 'pocket-screw');
  assert.match(requested.selectedBecause, /MDF|not recommended|needs/);

  const thinPly = selectJoinery({ material: resolveMaterial('birch-plywood'), thicknessMm: 12, requested: 'pocket-screw' });
  assert.equal(thinPly.substituted, true, 'pocket screws need >= 15 mm stock');
});

test('cut list parts are consistent with the spec', () => {
  const cl = buildCutList({ ...DEFAULT_SPEC, widthMm: 900, heightMm: 1800, depthMm: 300, shelves: 5, thicknessMm: 18 });
  const sides = cl.parts.filter((p) => p.id.startsWith('side-'));
  const shelves = cl.parts.find((p) => p.id === 'shelf');
  assert.equal(sides.length, 2);
  assert.equal(sides[0].lengthMm, 1800);
  assert.equal(sides[0].widthMm, 300);
  assert.equal(shelves.qty, 5);
  assert.equal(shelves.lengthMm, 900 - 2 * 18);
  assert.ok(cl.totalMassKg > 20 && cl.totalMassKg < 60, `mass ${cl.totalMassKg} kg should be plausible for this unit`);
  assert.equal(cl.edgeBandingMm, 2 * 1800 + 5 * 864 + 864 * 2);
});

test('normaliseSpec snaps thickness to an available one and clamps shelf count', () => {
  const s = normaliseSpec({ material: 'birch-plywood', thicknessMm: 19, shelves: 1 });
  assert.equal(s.thicknessMm, 18, '19 mm is not stocked, 18 mm is the nearest');
  assert.equal(s.shelves, 2, 'at least two horizontals are needed to close a box');
});

test('the nest packer never overlaps parts and places them all', () => {
  const cl = buildCutList({ ...DEFAULT_SPEC, thicknessMm: 21 }); // 21 mm so the sag check passes
  const audit = auditLayout(cl.nesting.carcass.sheets);
  assert.equal(audit.ok, true, audit.problems.join('; '));
  assert.equal(cl.nesting.carcass.unplaced.length, 0);
  const placedCount = cl.nesting.carcass.sheets.reduce((s, x) => s + x.parts.length, 0);
  const expectedCount = cl.parts.filter((p) => !p.separateSheet).reduce((s, p) => s + p.qty, 0);
  assert.equal(placedCount, expectedCount, 'every carcass part must be on a sheet exactly once');
});

test('grain-sensitive parts are never rotated off-grain', () => {
  const cl = buildCutList({ ...DEFAULT_SPEC, thicknessMm: 21 });
  const rotated = cl.nesting.carcass.sheets.flatMap((s) => s.parts).filter((p) => p.rotated);
  assert.equal(rotated.length, 0, 'plywood carcass parts must keep grain along their length');
});

test('a part wider than the sheet cannot be placed at all', () => {
  const nest = packSheets(
    [{ id: 'monolith', label: 'overwide panel', lengthMm: 3000, widthMm: 300, thicknessMm: 18, qty: 1, grainSensitive: true }],
    { lengthMm: 2440, widthMm: 1220 }
  );
  assert.equal(nest.unplaced.length, 1);
});

test('assembly sequence is ordered, reasoned and ends with the load test', () => {
  const cl = buildCutList({ ...DEFAULT_SPEC, thicknessMm: 21 });
  const seq = buildAssemblySequence(cl);
  assert.ok(seq.stepCount >= 10);
  seq.steps.forEach((s, i) => assert.equal(s.step, i + 1, 'steps must be numbered in order'));
  seq.steps.forEach((s) => assert.ok(s.reason && s.reason.length > 20, `step ${s.step} has no reason`));
  assert.match(seq.steps.at(-1).title, /Load test/);
  assert.ok(seq.steps.some((s) => /square/i.test(s.title) || /square/i.test(s.detail)), 'squaring must appear before finishing');
});

test('cost engine totals only verified lines and flags bulk tiers and unpriced lines', () => {
  const cl = buildCutList({ ...DEFAULT_SPEC, thicknessMm: 18 });
  const cost = costBuild(cl);
  const summed = Math.round(cost.lines.reduce((s, l) => s + l.lineTotal, 0) * 100) / 100;
  assert.equal(summed, cost.total, 'the reported total must equal the sum of its lines');
  assert.ok(cost.unpriced.some((u) => /back-panel|back panel/i.test(u.label)), 'the unsourced back panel must be surfaced, not guessed');
  const ply = cost.lines.find((l) => l.key.startsWith('sheet-18mm'));
  assert.equal(ply.basisMismatch, true, 'a MOQ-400 tier price cannot be used for a one-off build');
  assert.ok(ply.url.startsWith('https://'), 'every priced line must carry the listing URL it came from');
  assert.equal(cost.lines.every((l) => typeof l.asOf === 'string'), true, 'every line must be dated');
});

test('material alternatives are ranked without inventing cost figures', () => {
  const alts = alternativesFor('birch-plywood');
  assert.ok(alts.length >= 4);
  for (const a of alts) {
    assert.equal(typeof a.stiffnessVsPrimary, 'number');
    assert.equal('cost' in a, false, 'this module must not claim costs');
  }
  const steel = alts.find((a) => a.id === 'steel-mild');
  assert.ok(steel.stiffnessVsPrimary > 10, 'steel is far stiffer than plywood');
  assert.ok(steel.massVsPrimary > 10, 'and far heavier');
});

test('the same design always produces the same result', () => {
  const a = JSON.stringify(buildCutList({ ...DEFAULT_SPEC }));
  const b = JSON.stringify(buildCutList({ ...DEFAULT_SPEC }));
  assert.equal(a, b, 'the engine must be deterministic');
});
