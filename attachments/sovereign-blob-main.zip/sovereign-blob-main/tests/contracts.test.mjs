import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

import { loadSchemas, validate, validateDef, resolveRef, formatErrors } from '../contracts/validate.mjs';
import { statusForScore, stateForStatus, colourForScore, colourForState, stateTable, auditBands } from '../src/proto/state.js';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const doc = loadSchemas();

// ---------------------------------------------------------------------------
// The validator itself. A validator that accepts everything is worse than no validator,
// because it launders bad data as validated.
// ---------------------------------------------------------------------------
test('the validator rejects what it should reject', () => {
  assert.equal(validate({ a: 1 }, { type: 'object', required: ['b'] }).valid, false, 'missing required');
  assert.equal(validate('x', { type: 'number' }).valid, false, 'wrong type');
  assert.equal(validate(5, { type: 'number', minimum: 10 }).valid, false, 'below minimum');
  assert.equal(validate(5, { type: 'integer', minimum: 1, maximum: 4 }).valid, false, 'above maximum');
  assert.equal(validate([], { type: 'array', minItems: 1 }).valid, false, 'empty array');
  assert.equal(validate('z', { enum: ['a', 'b'] }).valid, false, 'bad enum');
  assert.equal(validate(1, { const: 2 }).valid, false, 'bad const');
  assert.equal(validate({ b: 'x' }, { type: 'object', required: ['b'], properties: { b: { type: 'number' } } }).valid, false, 'nested type');
});

test('the validator accepts what it should accept', () => {
  assert.equal(validate({ b: 1 }, { type: 'object', required: ['b'] }).valid, true);
  assert.equal(validate(11, { type: 'number', minimum: 10 }).valid, true);
  assert.equal(validate(10, { type: 'integer', minimum: 10, maximum: 10 }).valid, true);
  assert.equal(validate(1.5, { type: 'number' }).valid, true, 'integers satisfy number');
  assert.equal(validate('b', { enum: ['a', 'b'] }).valid, true);
});

test('an unsupported schema keyword fails instead of passing vacuously', () => {
  const result = validate({ a: 1 }, { type: 'object', oneOf: [{ type: 'object' }] });
  assert.equal(result.valid, false);
  assert.match(formatErrors(result), /unsupported keyword "oneOf"/);
});

test('$ref resolution works and unknown refs fail loudly', () => {
  const resolved = resolveRef(doc, '#/defs/material');
  assert.equal(resolved.type, 'object');
  assert.throws(() => resolveRef(doc, '#/defs/nope'), /unresolvable ref/);
});

test('every schema definition in the contract file is internally consistent', () => {
  for (const [name, schema] of Object.entries(doc.defs)) {
    assert.ok(schema.type || schema.$ref, `${name} declares no type`);
    if (schema.required) {
      for (const key of schema.required) {
        assert.ok(
          schema.properties && key in schema.properties,
          `${name} requires "${key}" but does not declare it in properties — a required field with no shape is unvalidated`
        );
      }
    }
    // Every $ref in the file must resolve.
    const text = JSON.stringify(schema);
    for (const m of text.matchAll(/"\\\$ref":"([^"]+)"/g)) resolveRef(doc, m[1]);
  }
});

test('the spec examples from section 15 validate against their schemas', () => {
  assert.equal(validateDef({ goal: 'bookshelf', location: 'wall', priority: 'storage', budget: 500 }, 'intentModel').valid, true);
  assert.equal(validateDef({ score: 72, status: 'READY', confidence: 0.91, warnings: [] }, 'realityResult').valid, true);
  assert.equal(
    validateDef({ anchorId: 'anchor-load-001', type: 'physical', name: 'Maximum Shelf Load', value: 35, unit: 'kg', locked: true }, 'realityAnchor').valid,
    true,
    'the spec uses `type` here and `anchorType` in section 10 — both must validate'
  );
  assert.equal(validateDef({ materialId: 'mat-birch-21', name: 'Birch Plywood', thickness: 21, density: 680, elasticModulus: 10300 }, 'material').valid, true);
  assert.equal(validateDef({ roomWidth: 3200, roomHeight: 2400, wallWidth: 1800, wallHeight: 2400, confidence: 0.83 }, 'roomModel').valid, true);
});

test('out-of-range values are rejected by the schema, not just by convention', () => {
  assert.equal(validateDef({ score: 101, status: 'READY', confidence: 0.9, warnings: [] }, 'realityResult').valid, false, 'score > 100');
  assert.equal(validateDef({ score: 50, status: 'MAYBE', confidence: 0.9, warnings: [] }, 'realityResult').valid, false, 'status outside the enum');
  assert.equal(validateDef({ score: 50, status: 'READY', confidence: 1.4, warnings: [] }, 'realityResult').valid, false, 'confidence > 1');
  assert.equal(validateDef({ roomWidth: 1, roomHeight: 1, wallWidth: 1, wallHeight: 1, confidence: 0.83, depth: -5 }, 'roomModel').valid, false, 'negative depth');
  assert.equal(validateDef({ goal: 'bookshelf', budget: -1 }, 'intentModel').valid, false, 'negative budget');
});

// ---------------------------------------------------------------------------
// ProtoMatter state and colour. AC SB-002.
// ---------------------------------------------------------------------------
test('SB-002: the state colours are exactly the five the spec names', () => {
  const t = stateTable();
  assert.deepEqual(
    Object.values(t).map((s) => `${s.label}=${s.colourName}`),
    ['Idle=Blue', 'Forming=Cyan', 'Validating=Amber', 'Ready=Green', 'Blocked=Red']
  );
});

test('SB-002: the Kotlin enum and the JS config cannot drift apart', () => {
  const kt = readFileSync(join(ROOT, 'android', 'contracts', 'Models.kt'), 'utf8');
  for (const [state, s] of Object.entries(stateTable())) {
    assert.ok(kt.includes(state), `Models.kt is missing state ${state}`);
    assert.ok(
      kt.includes(s.hex),
      `Models.kt does not carry ${state}'s colour ${s.hex} — the two renderers would show different colours`
    );
    assert.ok(kt.includes(s.colourName), `Models.kt is missing colour name ${s.colourName} for ${state}`);
  }
});

test('spec section 9: the score bands are exactly 0-49 / 50-74 / 75-100 and they tile', () => {
  assert.equal(statusForScore(0), 'BLOCKED');
  assert.equal(statusForScore(49), 'BLOCKED');
  assert.equal(statusForScore(50), 'CAUTION');
  assert.equal(statusForScore(74), 'CAUTION');
  assert.equal(statusForScore(75), 'READY');
  assert.equal(statusForScore(100), 'READY');
  const audit = auditBands();
  assert.equal(audit.ok, true, `bands do not tile: ${audit.problems.join('; ')}`);
});

test('state and colour follow the score, including the CAUTION -> Validating mapping', () => {
  assert.equal(stateForStatus('CAUTION'), 'VALIDATING');
  assert.equal(colourForScore(20).colourName, 'Red');
  assert.equal(colourForScore(60).colourName, 'Amber');
  assert.equal(colourForScore(90).colourName, 'Green');
  assert.equal(colourForScore(60).state, 'VALIDATING');
  assert.throws(() => colourForState('NOPE'), /unknown ProtoMatter state/);
});
