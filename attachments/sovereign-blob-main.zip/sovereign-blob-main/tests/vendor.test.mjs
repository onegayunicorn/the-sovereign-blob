import test from 'node:test';
import assert from 'node:assert/strict';

import { procurementRoute, loadPriceBook } from '../src/vendor/vendors.js';
import { buildCutList } from '../src/engine/cutlist.js';

/**
 * Fix 1 — procurementRoute input validation.
 *
 * The defect was found by the simulation harness passing the design object where an item key
 * belongs, and receiving "Cannot read properties of undefined (reading '#<Object>')". An error
 * that names a symptom and points nowhere near the mistake costs whoever hits it real time.
 *
 * NOTE ON THE FIX SPEC: the blueprint asked for a guard on `{designId, region, thickness}`.
 * That is a different API — this function resolves ONE price-book key. A guard for an argument
 * it never accepts would reject every correct call, so the guard matches the real signature and
 * the test asserts that the correct call still works.
 */

test('a non-string item key is refused with a message that names the mistake', () => {
  const err = (() => {
    try {
      procurementRoute({ spec: {}, widthMm: 900 });
      return null;
    } catch (e) {
      return e;
    }
  })();
  assert.ok(err, 'passing an object must throw rather than silently returning route "unknown"');
  assert.ok(err instanceof TypeError);
  assert.match(err.message, /expects a price-book item key \(string\), received object/);
  assert.match(err.message, /resolves ONE line of the BOM, not a whole design/, 'the message must say what to do instead');
  assert.equal(/"#<Object>"|reading '#/.test(err.message), false, 'the unreadable original error must be gone');
});

test('null, undefined and empty-string keys are refused too', () => {
  for (const bad of [null, undefined, '', 42, ['a']]) {
    assert.throws(() => procurementRoute(bad), TypeError, `expected a TypeError for ${JSON.stringify(bad)}`);
  }
});

test('a malformed price book is refused rather than producing a nonsense route', () => {
  assert.throws(() => procurementRoute('sheet-18mm-birch-plywood-2440x1220', {}), /price book with an `items` map/);
  assert.throws(() => procurementRoute('sheet-18mm-birch-plywood-2440x1220', null), /price book with an `items` map/);
});

test('the correct call still works — the guard must not reject valid use', () => {
  const route = procurementRoute('sheet-18mm-birch-plywood-2440x1220');
  assert.equal(typeof route, 'object');
  assert.equal(route.itemKey, 'sheet-18mm-birch-plywood-2440x1220');
  assert.ok(['bulk-marketplace-rfq', 'retail-purchase', 'quote-request', 'unsourced', 'unknown'].includes(route.route));
  assert.ok(route.action, 'every route must carry an action, or it is trivia');

  const book = loadPriceBook();
  const retail = Object.entries(book.items).find(([, v]) => v.basis === 'retail-*' || v.basis === 'retail');
  if (retail) {
    const r = procurementRoute(retail[0], book);
    assert.equal(typeof r.route, 'string');
  }
});

test('a key that is not in the book reports unknown rather than throwing', () => {
  const route = procurementRoute('a-key-that-does-not-exist');
  assert.equal(route.route, 'unknown');
  assert.match(route.reason, /not in the price book/);
});

test('the guard does not break the pipeline path that uses this route', () => {
  const cl = buildCutList({});
  const priced = cl.cost === undefined; // cutlist has no cost; sanity that we are on the right object
  assert.equal(priced, true);
  const route = procurementRoute(cl.material.id ? 'sheet-18mm-birch-plywood-2440x1220' : 'sheet-18mm-birch-plywood-2440x1220');
  assert.ok(route.route);
});
