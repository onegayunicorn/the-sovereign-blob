import test from 'node:test';
import assert from 'node:assert/strict';

import { runPipeline, dreamState, specFromIntent } from '../src/pipeline.js';
import { toCutListCSV, toNestedSVG, toDXF, toPackageJSON } from '../src/export/index.js';
import { parseTelemetry, summariseWindow } from '../src/sensors/telemetry.js';
import { validateRoom, assessCaptureConditions, accessCheck } from '../src/sensors/room.js';
import { buildSheetGoodsRfq, buildCncQuoteRequest, reachabilityReport, procurementRoute } from '../src/vendor/vendors.js';
import { scoreReality } from '../src/reality/engine.js';
import { buildCutList, DEFAULT_SPEC } from '../src/engine/cutlist.js';
import { costBuild } from '../src/engine/cost.js';

test('the full pipeline runs from one sentence and reports every stage', () => {
  const r = runPipeline('build me a bookshelf 1800 tall, 900 wide, shelves 300 deep, under $80');
  assert.equal(r.stages.length, 6);
  assert.deepEqual(r.stages.map((s) => s.stage), ['intent', 'form', 'geometry', 'material', 'economics', 'output']);
  r.stages.forEach((s) => {
    assert.ok(s.score >= 0 && s.score <= 100, `${s.stage} score out of range`);
    assert.match(s.colour, /^#[0-9A-F]{6}$/i);
    assert.ok(s.note.length > 10, `${s.stage} has no explanation`);
  });
  assert.ok(r.reality.score >= 0 && r.reality.score <= 100);
  assert.equal(['green', 'amber', 'red'].includes(r.reality.band), true);
  assert.ok(r.assembly.stepCount > 5);
  assert.equal(r.plan.widthMm, r.cutList.spec.widthMm);
});

test('the blob colour always agrees with the Reality Score band', () => {
  const r = runPipeline('bookshelf 900 wide 1800 tall');
  const expected = r.reality.score >= 80 ? '#00FFCC' : r.reality.score >= 60 ? '#FFB020' : '#FF3B30';
  assert.equal(r.blob.colour, expected);
  assert.equal(r.reality.colour, expected);
});

test('a failing design is reported as failing rather than being quietly fixed', () => {
  const r = runPipeline('bookshelf 1400 wide 2000 tall 300 deep');
  const def = r.cutList.checks.shelfDeflection;
  assert.equal(def.pass, false, 'a 1364 mm span in 18 mm ply must fail');
  assert.equal(r.reality.status !== 'PASS', true);
  assert.ok(r.reality.issues.some((i) => /sag/i.test(i)));
  assert.ok(r.reality.mitigations.length >= 1, 'a failure must come with a way out');
});

test('spec overrides from the UI beat the parser defaults', () => {
  const r = runPipeline('build me a bookshelf', { specOverrides: { thicknessMm: 21, shelves: 7 } });
  assert.equal(r.cutList.spec.thicknessMm, 21);
  assert.equal(r.cutList.spec.shelves, 7);
  assert.equal(r.cutList.checks.shelfDeflection.pass, true);
});

test('room fit and access checks gate the design', () => {
  const room = {
    widthMm: 1200,
    heightMm: 2400,
    depthMm: 2000,
    doorWidthMm: 760,
    doorHeightMm: 1980,
    skirtingHeightMm: 90,
    obstructions: [{ label: 'radiator', xMm: 200, yMm: 0, wMm: 600, dMm: 120 }],
    source: 'manual',
    confidence: 0.9
  };
  const r = runPipeline('bookshelf 900 wide 1800 tall', { room });
  assert.equal(r.roomCheck.scanned, true);
  // 1800 mm + 20 mm allowance clears a 1980 mm door, so the assembled route is fine...
  assert.equal(r.roomCheck.checks.access.assembled.pass, true);
  // ...but the radiator sits inside the proposed footprint, which is a real blocker
  assert.ok(r.roomCheck.issues.some((i) => /obstruction|radiator/i.test(i)));
  assert.ok(r.roomCheck.notes.some((n) => /skirting/i.test(n)));

  // A unit that genuinely will not fit through the door must be caught, both routes.
  const tooTall = accessCheck({ doorWidthMm: 760, doorHeightMm: 1980 }, { widthMm: 900, depthMm: 300, heightMm: 2050 }, {});
  assert.equal(tooTall.assembled.pass, false);
  assert.match(tooTall.issues[0], /will not pass/);

  const widePanel = accessCheck(
    { doorWidthMm: 760, doorHeightMm: 1980 },
    { widthMm: 900, depthMm: 300, heightMm: 900 },
    { parts: [{ label: 'back panel', lengthMm: 900, widthMm: 900 }] }
  );
  assert.equal(widePanel.parts.pass, false, 'a 900 x 900 panel cannot pass a 760 mm opening');
});

test('capture condition advice fires on a tilted phone and a dark room', () => {
  const bad = assessCaptureConditions({ tiltDeg: 7, lux: 12, gyroStable: false });
  assert.equal(bad.ok, false);
  assert.equal(bad.advice.length, 3);
  const good = assessCaptureConditions({ tiltDeg: 1, lux: 400, gyroStable: true });
  assert.equal(good.ok, true);
});

test('Dream State explores real variants and ranks them by recomputed score', () => {
  const dream = dreamState('bookshelf 900 wide 1800 tall', { maxVariants: 8 });
  assert.ok(dream.explored > 3);
  assert.ok(dream.best.length >= 1);
  for (const b of dream.best) {
    assert.equal(typeof b.score, 'number');
    assert.ok(b.score <= 100);
  }
  const scores = dream.best.map((b) => b.score);
  assert.deepEqual(scores, [...scores].sort((a, b) => b - a), 'best must be sorted descending');
});

test('CSV export is a valid, self-describing cut list', () => {
  const r = runPipeline('bookshelf 900 wide 1800 tall');
  const csv = toCutListCSV(r.cutList, { generatedAt: '2026-09-28T00:00:00.000Z' });
  const lines = csv.split('\n').filter(Boolean);
  // No unresolved placeholders may ever reach a workshop.
  assert.equal(/REQUEST_TIME|TBD|TODO|undefined/.test(csv), false, 'no placeholders in the cut list');
  assert.match(csv, /# generated: 2026-09-28T00:00:00.000Z/);
  // Grain direction must be reported per part.
  const shelfRow = lines.find((l) => l.startsWith('Shelf / horizontal panel'));
  assert.equal(shelfRow.split(',')[6], 'length', 'grain must run along the span of a shelf');
  assert.ok(lines.filter((l) => l.startsWith('#')).length >= 4, 'must carry metadata comments');
  const header = lines.find((l) => l.startsWith('part,'));
  const cols = header.split(',');
  assert.deepEqual(cols.slice(0, 5), ['part', 'qty', 'length_mm', 'width_mm', 'thickness_mm']);
  const dataRows = lines.slice(lines.indexOf(header) + 1);
  assert.ok(dataRows.length >= 3);
  dataRows.forEach((row) => {
    const cells = row.match(/("([^"]|"")*"|[^,]*)/g).filter((c) => c !== '');
    assert.ok(cells.length >= cols.length - 1, `row has too few cells: ${row}`);
  });
});

test('DXF export is R12 with millimetre units and one rectangle per part', () => {
  const r = runPipeline('bookshelf 900 wide 1800 tall');
  const dxf = toDXF(r.cutList);
  assert.match(dxf, /^0\nSECTION\n2\nHEADER/);
  assert.match(dxf, /\$INSUNITS/);
  assert.match(dxf, /\n0\nENDSEC\n0\nSECTION\n2\nENTITIES/);
  assert.match(dxf, /0\nEOF\n$/);
  const lineEntities = (dxf.match(/\nLINE\n/g) || []).length;
  const rects =
    r.cutList.nesting.carcass.sheets.length +
    r.cutList.nesting.carcass.sheets.reduce((s, x) => s + x.parts.length, 0) +
    r.cutList.nesting.back.sheets.length +
    r.cutList.nesting.back.sheets.reduce((s, x) => s + x.parts.length, 0);
  assert.equal(lineEntities, rects * 4, 'each rectangle is four LINE entities');
  assert.equal(/NaN|Infinity/.test(dxf), false, 'DXF must contain no invalid numbers');
});

test('SVG export labels every placed part', () => {
  const r = runPipeline('bookshelf 900 wide 1800 tall');
  const svg = toNestedSVG(r.cutList);
  assert.match(svg, /^<svg /);
  assert.match(svg, /<\/svg>$/);
  const placed = r.cutList.nesting.carcass.sheets.reduce((s, x) => s + x.parts.length, 0);
  assert.equal((svg.match(/data-part=/g) || []).length, placed);
  assert.match(svg, /front elevation/);
});

test('the package JSON is self-contained and records its provenance', () => {
  const r = runPipeline('bookshelf 900 wide 1800 tall');
  const json = JSON.parse(toPackageJSON(r, { generatedAt: '2026-09-28T00:00:00.000Z' }));
  assert.equal(json.format, 'sovereign-blob/package@1');
  assert.equal(json.units, 'mm');
  assert.equal(json.generatedAt, '2026-09-28T00:00:00.000Z');
  assert.ok(json.parts.length);
  assert.ok(json.cost.asOf);
  assert.match(json.provenance.note, /not a structural certificate/i);
  assert.equal(json.provenance.materialDataVerified, false);
});

test('telemetry decoding derives orientation and refuses out-of-range data', () => {
  const good = parseTelemetry(
    { deviceId: 'node-01', ts: 1_700_000_000_000, tempC: 21.5, humidityPct: 48, pressureHpa: 1010, lux: 350, ax: 0, ay: 0, az: 1, gx: 2, gy: 1, gz: 0, batteryV: 3.9, rssiDbm: -60 },
    { now: 1_700_000_005_000 }
  );
  assert.equal(good.ok, true);
  assert.equal(good.derived.tiltDeg, 0);
  assert.equal(good.ageSeconds, 5);

  const stale = parseTelemetry({ deviceId: 'n', ts: 1, tempC: 20 }, { now: 1_000_000 });
  assert.ok(stale.warnings.some((w) => /stopped|old/i.test(w)));

  const broken = parseTelemetry({ deviceId: 'n', ts: 1, humidityPct: 500 });
  assert.equal(broken.ok, false);
  assert.ok(broken.errors.some((e) => /plausible range/.test(e)));

  const notJson = parseTelemetry('{oops');
  assert.equal(notJson.ok, false);

  const summary = summariseWindow([good, good]);
  assert.equal(summary.count, 2);
  assert.equal(summary.tempC.mean, 21.5);
});

test('RFQ and CNC payloads carry the real supplier URLs, never invented ones', () => {
  const r = runPipeline('bookshelf 900 wide 1800 tall');
  const rfq = buildSheetGoodsRfq(r.cutList, { destinationCountry: 'Singapore' });
  assert.ok(rfq.body.includes('E-Modulus') || rfq.body.includes('datasheet'));
  assert.ok(rfq.attachments.includes('nested-layout.dxf'));
  assert.equal(rfq.supplierListingUrl, null, 'no supplier chosen yet, so no URL is claimed');

  const cnc = r.vendor.cnc;
  assert.equal(cnc.services.length >= 3, true);
  cnc.services.forEach((s) => assert.match(s.url, /^https:\/\//));
  assert.ok(cnc.body.includes('nested-layout.dxf'));
});

test('procurement routing tells you the mechanism, not just a link', () => {
  const bulk = procurementRoute('sheet-18mm-birch-plywood-2440x1220');
  assert.equal(bulk.route, 'bulk-marketplace-rfq');
  const retail = procurementRoute('pocket-screws-32mm-500ct');
  assert.equal(retail.route, 'retail-purchase');
  const quote = procurementRoute('cut-to-size-cnc-service');
  assert.equal(quote.route, 'quote-request');
  const missing = procurementRoute('confirmat-screws-7x50');
  assert.equal(missing.route, 'unsourced');
  assert.match(missing.action, /source/);
});

test('the reachability report separates verified from unverified', () => {
  const rep = reachabilityReport();
  assert.ok(rep.counts.live >= 1);
  assert.ok(rep.counts.formOnly >= 5);
  rep.live.forEach((s) => assert.equal(s.verified, true));
  assert.match(rep.rule, /unverified rather than assumed/i);
});

test('reality scoring is a pure function of the computed checks', () => {
  const cl = buildCutList({ ...DEFAULT_SPEC, thicknessMm: 21 });
  const cost = costBuild(cl);
  const a = scoreReality({ spec: cl.spec, cutList: cl, cost });
  const b = scoreReality({ spec: cl.spec, cutList: cl, cost });
  assert.deepEqual(a, b);
  const worse = buildCutList({ ...DEFAULT_SPEC, thicknessMm: 15, widthMm: 1400 });
  const worseCost = costBuild(worse);
  const c = scoreReality({ spec: worse.spec, cutList: worse, cost: worseCost });
  assert.ok(c.score < a.score, 'a weaker design must score lower');
  Object.values(a.dimensions).forEach((v) => assert.ok(v >= 0 && v <= 100));
});
