import test from 'node:test';
import assert from 'node:assert/strict';

import { parseIntent, applyModifications } from '../src/intent/core.js';
import { specFromIntent } from '../src/pipeline.js';

test('the canonical utterance recovers every stated dimension', () => {
  const intent = parseIntent('Build me a bookshelf, 1800 tall and 900 wide, shelves 300 deep');
  assert.equal(intent.kind, 'bookshelf');
  assert.equal(intent.slots.heightMm.value, 1800);
  assert.equal(intent.slots.widthMm.value, 900);
  assert.equal(intent.slots.depthMm.value, 300);
  assert.equal(intent.slots.heightMm.source, 'user');
  assert.equal(intent.slots.widthMm.source, 'user');
  assert.ok(intent.confidence > 0.2);
});

test('imperial units are converted, not ignored', () => {
  const intent = parseIntent('a bookshelf 6 ft tall and 3 feet wide');
  assert.equal(intent.slots.heightMm.value, Math.round(6 * 304.8));
  assert.equal(intent.slots.widthMm.value, Math.round(3 * 304.8));
  assert.equal(intent.slots.heightMm.source, 'user');
});

test('defaulted slots are labelled as defaults and produce open questions', () => {
  const intent = parseIntent('build me a bookshelf');
  assert.equal(intent.slots.widthMm.source, 'default');
  assert.ok(intent.openQuestions.length >= 5);
  assert.ok(intent.openQuestions.every((q) => q.question.endsWith('.') || q.question.endsWith('?')));
  assert.ok(intent.confidence < 0.35, 'guessing almost everything must not look like confidence');
  // The default must be a real number, never null, so downstream stages always have input
  assert.equal(typeof intent.slots.widthMm.value, 'number');
});

test('priority profile is derived from constraint phrases', () => {
  const cheap = parseIntent('cheap bookshelf for a small apartment, keep the kids safe');
  assert.equal(cheap.constraints.cost.active, true);
  assert.equal(cheap.constraints.space.active, true);
  assert.equal(cheap.constraints.safety.active, true);
  assert.ok(cheap.priorities.cost > cheap.priorities.aesthetics);
  assert.equal(cheap.slots.anchored.value, true, 'a safety phrase must switch anchoring on');
});

test('a stated budget is captured, an unstated one is null rather than invented', () => {
  const withBudget = parseIntent('bookshelf under $80');
  assert.equal(withBudget.slots.budget.value, 80);
  assert.equal(withBudget.slots.budget.source, 'user');

  const vague = parseIntent('bookshelf as cheap as possible');
  assert.equal(vague.slots.budget.value, null);
  assert.equal(vague.constraints.cost.active, true, 'the intent is still captured even without a number');
});

test('modifications are deltas, and applying them changes only the named slot', () => {
  const intent = parseIntent('make it taller and sturdier');
  assert.ok(intent.modifications.length >= 1);
  const before = { widthMm: 900, heightMm: 1800, thicknessMm: 18 };
  const { spec, applied } = applyModifications(before, intent.modifications);
  assert.ok(spec.heightMm > before.heightMm);
  assert.equal(spec.widthMm, before.widthMm);
  assert.ok(applied.length >= 1);
});

test('a cost-reduction instruction changes the design, not just the wording', () => {
  const intent = parseIntent('make it cheaper');
  const { spec } = applyModifications({ joinery: 'pocket-screw', backThicknessMm: 6 }, intent.modifications);
  assert.equal(spec.joinery, 'dowel');
  assert.equal(spec.backThicknessMm, 3);
});

test('an unrecognised object still resolves to a usable spec instead of failing', () => {
  const intent = parseIntent('something for the hallway');
  assert.equal(intent.kind, 'unknown');
  assert.ok(intent.confidence < 0.3);
  const spec = specFromIntent(intent);
  assert.ok(spec.widthMm > 0 && spec.heightMm > 0 && spec.depthMm > 0);
});

test('describing a dimension is not an instruction to change it', () => {
  // Regression: "300 deep" used to match the "deeper" pattern and silently add 50 mm.
  const described = parseIntent('build me a bookshelf, 1800 tall and 900 wide, shelves 300 deep');
  assert.deepEqual(described.modifications, [], 'a stated depth must not become a modification');
  const spec = specFromIntent(described);
  assert.equal(spec.depthMm, 300, 'stated depth must survive unchanged into the spec');
  assert.equal(spec.heightMm, 1800);
  assert.equal(spec.widthMm, 900);

  // "a lower shelf" names a shelf position; it must not shrink the unit.
  const positional = parseIntent('bookshelf with a lower shelf for games');
  assert.deepEqual(positional.modifications, []);
  assert.equal(specFromIntent(positional).heightMm, 1800);

  // But a genuine comparative still works.
  const real = parseIntent('make it deeper');
  assert.equal(real.modifications.length, 1);
  assert.equal(real.modifications[0].slot, 'depthMm');
});

test('the intent graph is rendered as a readable tree', () => {
  const intent = parseIntent('bookshelf, maximised storage, 2000 tall');
  const lines = intent.graph.split('\n');
  assert.match(lines[0], /BOOKSHELF/);
  assert.ok(lines.length >= 5);
  assert.ok(lines.slice(1).every((l) => /^[├└]─/.test(l)), 'every graph line must be a tree branch');
});
