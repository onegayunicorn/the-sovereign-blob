# android/ — module interface contracts

Kotlin declarations for the six modules in Alpha spec v1.1 section 13, plus the data models
from section 15.

## Read this before treating any of it as working code

**Status: the app module COMPILES and produces an installable debug APK.** Verified end to end
in this repository: Kotlin compiler 2.4.20, Gradle 9.8.0, Android SDK platform 36 / build-tools
36.0.0, AGP 9.4.1, JDK 17 toolchain — `gradle assembleDebug` → `BUILD SUCCESSFUL`, producing
`android/app/build/outputs/apk/debug/app-debug.apk` (~10.7 MB).

That is a compile result, not a usability claim. Nothing here has been **run on a device or
emulator**, so there is no frame-rate measurement, no camera throughput figure, and no
on-device speech result. Those remain unverified.

Four build failures were needed to get there, each a different real constraint rather than
flailing: AGP 9 forbids the `kotlin.android` plugin (built-in Kotlin supersedes it); the
standalone Compose plugin re-applies that same forbidden plugin, so `android.builtInKotlin=false`
plus `android.newDsl=false` is required; the system Java is a **JRE without `javac`**, which AGP
reports as a missing `JAVA_COMPILER` capability; and Gradle's toolchain auto-detection then
hands AGP that same compiler-less JVM unless the search path is pinned. All four are recorded
in `gradle.properties` next to the settings that fix them.

What *is* real and verified is the **data contract**. Every type here is defined in
[`../contracts/schemas.json`](../contracts/schemas.json), and
`tests/contracts.test.mjs` validates the JavaScript reference implementation against those
same schemas. So a Kotlin implementation that emits these shapes will interoperate with the
engine in `src/` without a translation layer, and a shape change that breaks the contract
fails a test rather than failing on a device.

## Files

| File | Contents |
|---|---|
| `contracts/Modules.kt` | `ProtoMatterEngine`, `IntentEngine`, `RealityEngine`, `RoomScanEngine`, `SBMEngine`, `ExportEngine` — signatures as specified |
| `contracts/Models.kt` | `ProtoMatterState`, `GeometrySnapshot`, `IntentModel`, `RealityResult`, `SagResult`, `RealityAnchor`, `RoomModel`, `SBM` and the rest |

## What the interfaces deliberately encode

- **`ProtoMatterEngine` takes no dependency on the Intent or Reality engines.** Layer 1 must
  survive with no AI and no network, so it cannot be coupled to the layers above it.
- **`IntentEngine.updateIntent` must not discard constraints.** Constraint preservation is
  what stops concept drift; a locked anchor dropped during a modification is exactly the
  failure mode Reality Anchors exist to prevent.
- **`RealityEngine` is synchronous and network-free.** It is the layer that decides whether a
  design is physically possible, so it cannot require a service to answer.
- **`RoomScanEngine` returns `confidence` on every call.** Alpha has no AR modelling, so
  every dimension is an estimate, and an estimate presented as a measurement is the failure
  this signature is shaped to prevent.
- **Units are in the field names** (`widthMm`, `massKg`). A structural check that mixes
  millimetres and kilograms returns a plausible number and produces a shelf that sags.

## Sprint 1 & 5 UI tasks — honest status

| Spec task | Status |
|---|---|
| Create Compose screen | Not started. Android UI, no toolchain here. |
| Integrate OpenGL ES renderer | Not started. The metaball field and marching-squares contour it would draw exist and are tested in `src/blob/`; the GL binding does not. |
| Create particle engine | Partially portable: the field math is in `src/blob/field.js` and is renderer-agnostic. |
| Add animation loop | Not started. |
| Add state colour mapping | **Done**, in `config/proto-states.json`, mirrored in `Models.kt`, checked by test. |
| CameraX wall capture | Not started. The consumer side (bounds checks, confidence handling, fit constraints) exists in `src/sensors/room.js` and is tested against a scan payload. |
