// Root build file. Plugin versions are declared once here and applied per module.
//
// AGP 9.x is paired with Gradle 9.x deliberately: AGP 8.x requires Gradle 8.x and would fail
// on the Gradle 9.8 toolchain this repository installs.
//
// NOTE ON KOTLIN: since AGP 9.0, Kotlin support is BUILT IN, and applying
// `org.jetbrains.kotlin.android` is a hard build failure ("no longer required for Kotlin
// support since AGP 9.0"). That was discovered by running the build, not by reading docs. Only
// the Compose compiler plugin is still applied alongside AGP.
// Compose is enabled through AGP's own `buildFeatures { compose = true }` under built-in
// Kotlin. The standalone `org.jetbrains.kotlin.plugin.compose` plugin pulls in the
// `org.jetbrains.kotlin.android` plugin transitively, which AGP 9 rejects outright — so it is
// NOT declared here. Per the AGP 9 release notes, KGP is a runtime dependency (2.2.10 default)
// and must not be declared either.
plugins {
    id("com.android.application") version "9.4.1" apply false
    id("org.jetbrains.kotlin.android") version "2.4.20" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.4.20" apply false
}
