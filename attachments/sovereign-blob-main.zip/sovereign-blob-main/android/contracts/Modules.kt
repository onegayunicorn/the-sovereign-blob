package dev.sovereignblob.contracts

/**
 * Android module interfaces — Alpha spec v1.1, section 13.
 *
 * These signatures are reproduced from the specification and are treated as the contract.
 * They are declared here as interfaces only: no implementation ships in this repository,
 * because the implementations live in the Android app.
 *
 * VERIFICATION STATUS: COMPILED. kotlinc 2.4.20 compiles these two files into 32 classes, and
 * the app module builds into a debug APK (Gradle 9.8.0, AGP 9.4.1, JDK 17, SDK 36). The data
 * contract they reference is validated in contracts/schemas.json by tests/contracts.test.mjs,
 * and the structural maths is cross-checked against the JavaScript engine by
 * tests/parity.test.mjs. NOT verified: behaviour on a device — no emulator or handset was used.
 */

/**
 * Layer 1. The fluid substrate. Deliberately AI-independent: the spec requires that this
 * layer must survive with no AI available, so it must not depend on the Intent or Reality
 * engines to render.
 */
interface ProtoMatterEngine {
    fun initialise()
    fun updateState(state: ProtoMatterState)
    fun morph(target: MorphTarget)
    fun render()
    fun getCurrentGeometry(): GeometrySnapshot
}

/**
 * Layer 2. Extracts and preserves intent. `updateIntent` must not discard previously
 * recorded constraints — constraint preservation across modifications is the whole point
 * of this layer, and losing an anchor here is what causes concept drift downstream.
 */
interface IntentEngine {
    fun parseSpeech(transcript: String): IntentModel
    fun getCurrentIntent(): IntentModel
    fun updateIntent(intent: IntentModel)
}

/**
 * Layer 3. Physics, manufacturability, cost, safety. Must be callable with no network and
 * no AI: it is the layer that decides whether a design is physically possible.
 *
 * `validateAnchors` must return a violation for any locked anchor that the current design
 * breaks. A locked anchor is never silently overridden — the result is a BLOCKED status
 * plus an explanation (AC SB-060).
 */
interface RealityEngine {
    fun evaluate(input: RealityInput): RealityResult
    fun calculateSag(geometry: GeometrySnapshot, material: MaterialSpec): SagResult
    fun validateAnchors(anchors: List<RealityAnchor>): ValidationResult
}

/**
 * Layer 4. Observation of the environment. All methods are suspend: they are camera and
 * sensor bound and must not block the render loop.
 *
 * Alpha scope is explicitly wall width, wall height and floor reference only — no AR
 * modelling (spec section 8). `confidence` is mandatory on every return, because an
 * unmeasured estimate presented as a measurement is the failure mode this module must
 * avoid.
 */
interface RoomScanEngine {
    suspend fun scanRoom(): RoomModel
    suspend fun detectWall(): WallModel
    suspend fun estimateDimensions(): Dimensions
}

/**
 * Layer 5 boundary. The manifest is the universal internal language; every export derives
 * from it. `validate` performs schema, reality and anchor validation, and all three must
 * pass before export is permitted.
 *
 * `load` must round-trip losslessly with `save` (AC SB-031).
 */
interface SBMEngine {
    fun create(project: ProjectData): SBM
    fun validate(sbm: SBM): ValidationReport
    fun save(sbm: SBM)
    fun load(id: String): SBM
}

/**
 * Export layer. PDF proves usefulness to humans; DXF proves it to machines. Both derive
 * from the SBM, never from UI state, so an export cannot contain something the manifest
 * does not.
 */
interface ExportEngine {
    suspend fun exportPDF(sbm: SBM): java.io.File
    suspend fun exportDXF(sbm: SBM): java.io.File
    suspend fun exportReplay(sbm: SBM): java.io.File
}
