package dev.sovereignblob.contracts

/**
 * Data models for the Alpha spec v1.1. Field names and units match contracts/schemas.json
 * exactly — that file is the source of truth, and tests/contracts.test.mjs asserts the
 * JavaScript implementation produces these same shapes.
 *
 * Units are always suffixed in the field name (Mm, Kg) so a millimetre value cannot be
 * passed where a kilogram is expected. This is not style: a mixed-unit bug in a structural
 * check produces a shelf that passes validation and then sags.
 *
 * VERIFICATION STATUS: COMPILED. kotlinc 2.4.20 builds this file and Modules.kt into 32
 * classes, and the app module builds into a debug APK. The behavioural verification is the
 * parity harness: tools/parity/ParityMain.kt runs the reality checks and tests/parity.test.mjs
 * asserts they match the JavaScript engine value for value.
 */

/** ProtoMatter visual state. Colour is defined in config/proto-states.json and mirrored
 *  from there, so no two renderers can disagree about what "Amber" means. */
enum class ProtoMatterState(val label: String, val colourName: String, val hex: String) {
    IDLE("Idle", "Blue", "#1E5BFF"),
    FORMING("Forming", "Cyan", "#00E5FF"),
    VALIDATING("Validating", "Amber", "#FFB020"),
    READY("Ready", "Green", "#00FFCC"),
    BLOCKED("Blocked", "Red", "#FF3B30");

    companion object {
        /** Spec section 9 bands. BLOCKED 0-49, CAUTION 50-74, READY 75-100. */
        fun fromScore(score: Int): ProtoMatterState = when {
            score < 50 -> BLOCKED
            score < 75 -> VALIDATING
            else -> READY
        }
    }
}

data class MorphTarget(
    val objectType: String,
    val progress: Float,
    val geometry: GeometrySnapshot? = null
)

data class GeometrySnapshot(
    val objectType: String,
    val widthMm: Double,
    val heightMm: Double,
    val depthMm: Double,
    val thicknessMm: Double,
    val shelves: Int = 0,
    val spanMm: Double = 0.0,
    val parts: List<Component> = emptyList()
)

data class Component(
    val componentId: String,
    val type: String,
    val width: Double,
    val height: Double,
    val thickness: Double,
    val quantity: Int,
    val grainDirection: String? = null,
    val edgesBanded: List<String> = emptyList()
)

data class MaterialSpec(
    val materialId: String,
    val name: String,
    val thickness: Double,
    val density: Double,
    val elasticModulus: Double,
    val sheetCost: Double? = null,
    val sheetsRequired: Int = 0,
    val provenanceVerified: Boolean = false
)

data class IntentModel(
    val goal: String,
    val location: String? = null,
    val priority: String? = null,
    val budget: Double? = null,
    val constraints: Map<String, String> = emptyMap(),
    val transcript: String? = null,
    val confidence: Double? = null
)

data class RealityInput(
    val geometry: GeometrySnapshot,
    val material: MaterialSpec,
    val anchors: List<RealityAnchor> = emptyList(),
    val room: RoomModel? = null
)

data class RealityResult(
    val score: Int,
    val status: Status,
    val confidence: Double,
    val warnings: List<String> = emptyList(),
    val blockers: List<String> = emptyList(),
    val recommendations: List<String> = emptyList(),
    val checks: Map<String, String> = emptyMap()
) {
    /** 0-49 BLOCKED, 50-74 CAUTION, 75-100 READY. */
    enum class Status { BLOCKED, CAUTION, READY }
}

data class SagResult(
    val immediateMm: Double,
    val longTermMm: Double,
    val limitMm: Double,
    val passes: Boolean,
    val utilisation: Double
)

/**
 * Anchor types. The spec uses `anchorType` in section 10 and `type` in the SBM example;
 * both are accepted on input and `anchorType` is always emitted. Recorded in
 * docs/SPEC-DEVIATIONS.md.
 */
data class RealityAnchor(
    val anchorId: String,
    val anchorType: String,
    val name: String,
    val value: Double,
    val unit: String,
    val locked: Boolean,
    val rationale: String? = null
)

data class ValidationResult(
    val valid: Boolean,
    val violations: List<AnchorViolation> = emptyList()
)

data class AnchorViolation(
    val anchorId: String,
    val name: String,
    val expected: String,
    val actual: String,
    val message: String
)

data class RoomModel(
    val roomWidth: Double,
    val roomHeight: Double,
    val wallWidth: Double,
    val wallHeight: Double,
    val confidence: Double,
    val depth: Double = 0.0,
    val source: String? = null
)

data class WallModel(
    val widthMm: Double,
    val heightMm: Double,
    val confidence: Double,
    val floorReferenceMm: Double? = null
)

data class Dimensions(val widthMm: Double, val heightMm: Double, val depthMm: Double)

data class ProjectData(
    val id: String,
    val name: String,
    val created: String,
    val version: Int = 1,
    val objectType: String = "bookshelf",
    val region: String? = null
)

data class ValidationReport(
    val schemaValid: Boolean,
    val realityValid: Boolean,
    val anchorsValid: Boolean,
    val errors: List<String> = emptyList()
) {
    val allPassed: Boolean get() = schemaValid && realityValid && anchorsValid
}

/** The manifest. Every export derives from this. Structure per spec section 11. */
data class SBM(
    val sbmVersion: String = "0.2",
    val project: ProjectData,
    val intent: IntentModel,
    val spatial: RoomModel,
    val anchors: List<RealityAnchor>,
    val reality: RealityResult,
    val materials: List<MaterialSpec>,
    val components: List<Component>,
    val assembly: List<AssemblyStep>,
    val costing: Costing,
    val fabrication: Fabrication,
    val exports: Exports,
    val audit: Audit
)

data class AssemblyStep(
    val step: Int,
    val description: String,
    val components: List<String>,
    val reason: String? = null
)

data class Costing(
    val materialCost: Double,
    val fabricationCost: Double?,
    val hardwareCost: Double,
    val totalCost: Double,
    val currency: String,
    val budgetStatus: String
)

data class Fabrication(
    val dxfReady: Boolean,
    val cutList: List<Map<String, Any>>,
    val toolsRequired: List<String>,
    val sheetLayout: String
)

data class Exports(
    val pdf: String?,
    val dxf: String?,
    val replay: String?,
    val sbm: String?
)

data class Audit(
    val voiceInput: String?,
    val intentChanges: List<Map<String, Any>>,
    val realityDecisions: List<Map<String, Any>>,
    val anchorViolations: List<Map<String, Any>>,
    val physicalValidation: Map<String, Any>?
)

data class RealityDecision(
    val timestamp: String,
    val decision: String,
    val reason: String,
    val trigger: String
)
