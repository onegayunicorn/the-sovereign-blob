package dev.sovereignblob.reality

import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.round

/**
 * Device-side structural checks.
 *
 * Layer 3 must answer with no network and no AI (spec section 2), so the sag verdict is
 * computed on-device rather than fetched from the bridge. This is a deliberate second
 * implementation of the same equations as `src/engine/sag.js`, and that duplication is only
 * safe because there is a parity test: `tools/parity/ParityMain.kt` runs these functions and
 * `tests/parity.test.mjs` asserts they agree with the JavaScript engine to within rounding.
 * Without that test, two implementations of a physical law is two ways to be wrong.
 *
 * Model: simply-supported beam, uniformly distributed load.
 *   delta = 5 * w * L^4 / (384 * E * I),  I = depth * thickness^3 / 12,  w = load * g / L
 * Because w carries a 1/L, a fixed payload gives delta proportional to L^3, not L^4.
 */
object RealityChecks {

    const val GRAVITY = 9.81

    /** Long-term deflection multiplier for a sustained load on wood. */
    const val CREEP_FACTOR = 2.0

    data class SagResult(
        val immediateMm: Double,
        val longTermMm: Double,
        val limitMm: Double,
        val utilisation: Double,
        val passes: Boolean
    )

    fun secondMomentOfArea(depthMm: Double, thicknessMm: Double): Double =
        depthMm * thicknessMm.pow(3) / 12.0

    /** Rounding matches the JS engine (3 decimals) so parity is exact, not approximate. */
    private fun round3(v: Double) = round(v * 1000.0) / 1000.0

    fun shelfDeflection(
        spanMm: Double,
        thicknessMm: Double,
        depthMm: Double,
        elasticModulusMpa: Double,
        loadKg: Double,
        selfMassKg: Double,
        creepFactor: Double = CREEP_FACTOR,
        spanDivisor: Double = 360.0
    ): SagResult {
        require(spanMm > 0) { "span must be positive" }
        require(thicknessMm > 0) { "thickness must be positive" }

        val i = secondMomentOfArea(depthMm, thicknessMm)
        val w = (loadKg + selfMassKg) * GRAVITY / spanMm
        val immediate = 5.0 * w * spanMm.pow(4) / (384.0 * elasticModulusMpa * i)
        val longTerm = immediate * creepFactor
        val limit = spanMm / spanDivisor
        return SagResult(
            immediateMm = round3(immediate),
            longTermMm = round3(longTerm),
            limitMm = round3(limit),
            utilisation = round3(longTerm / limit),
            passes = longTerm <= limit
        )
    }

    /**
     * Minimum stocked thickness that passes. The engine snaps to stocked sizes rather than
     * inventing a value, because "25.4 mm would work" is not something anyone can buy.
     */
    fun minimumPassingThickness(
        stocked: List<Double>,
        spanMm: Double,
        depthMm: Double,
        elasticModulusMpa: Double,
        loadKg: Double,
        selfMassKg: (Double) -> Double
    ): Double? = stocked.sorted().firstOrNull { t ->
        shelfDeflection(spanMm, t, depthMm, elasticModulusMpa, loadKg, selfMassKg(t)).passes
    }

    /**
     * Tip-over margin: the horizontal force needed to tip a unit divided by the force that
     * actually acts on it. Below 1.0 the unit can be pulled over, and above ~0.5 it needs a
     * wall fixing. Returns null when the geometry cannot tip (deeper than it is tall).
     */
    fun tipOverMargin(widthMm: Double, heightMm: Double, depthMm: Double, massKg: Double, loadKg: Double): Double? {
        if (depthMm >= heightMm) return null
        val own = massKg * GRAVITY
        val applied = loadKg * GRAVITY
        val restoring = own * (depthMm / 2.0)
        val overturning = applied * (depthMm / 3.0) + own * (heightMm / 6.0)
        if (overturning <= 0.0) return null
        return round3(resting(overturning, restoring))
    }

    private fun resting(overturning: Double, restoring: Double) = restoring / overturning

    /** Shelf span between two side panels of thickness t. */
    fun clearSpan(widthMm: Double, thicknessMm: Double): Double = widthMm - 2.0 * thicknessMm

    /** Compare a measured deflection against a prediction; used by the calibration feedback. */
    fun predictionErrorPercent(predictedMm: Double, measuredMm: Double): Double {
        require(predictedMm != 0.0) { "prediction must be non-zero" }
        return round3(abs(measuredMm - predictedMm) / predictedMm * 100.0)
    }
}
