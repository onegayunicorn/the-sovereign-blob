package dev.sovereignblob.app

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * ProtoMatter renderer.
 *
 * The metaball field is evaluated IN THE FRAGMENT SHADER, not on the CPU. That is the whole
 * trick: the field is a sum over nodes of w*r^2/d^2, so one full-screen quad with a loop of up
 * to 64 nodes draws the blob at device resolution for the cost of one pass. Evaluating it in
 * Kotlin and uploading a bitmap would be the same picture at a fraction of the frame rate.
 *
 * Node positions arrive in normalised 0..1 space from the shared shape programs, so the same
 * numbers that produce the contour in `src/blob/field.js` produce the surface here. There is
 * one geometry definition, expressed twice.
 *
 * This file is written against GLES 2.0 for reach: every device the app targets supports it,
 * and the shader has no features beyond the spec.
 */
class ProtoMatterView(context: Context) : GLSurfaceView(context) {

    private val renderer = FieldRenderer()

    init {
        setEGLContextClientVersion(2)
        setRenderer(renderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    fun setField(nodes: FloatArray, nodeCount: Int, threshold: Float, colour: FloatArray, progress: Float) {
        renderer.nodes = nodes
        renderer.nodeCount = nodeCount
        renderer.threshold = threshold
        renderer.colour = colour
        renderer.progress = progress
        requestRender()
    }

    /** Return to the idle breathing state (spec: "Idle = Blue"). */
    fun setIdle() {
        renderer.progress = 0f
        renderer.nodeCount = 0
        renderer.colour = floatArrayOf(0.118f, 0.357f, 1.0f) // #1E5BFF
        requestRender()
    }

    private class FieldRenderer : Renderer {
        @Volatile var nodes: FloatArray = FloatArray(MAX_NODES * 3)
        @Volatile var nodeCount: Int = 0
        @Volatile var threshold: Float = 1.0f
        @Volatile var colour: FloatArray = floatArrayOf(0.118f, 0.357f, 1.0f)
        @Volatile var progress: Float = 0f

        private var program = 0
        private var quad: FloatBuffer? = null

        override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
            program = buildProgram(VERTEX_SHADER, FRAGMENT_SHADER)
            quad = ByteBuffer.allocateDirect(QUAD.size * 4)
                .order(ByteOrder.nativeOrder())
                .asFloatBuffer()
                .apply { put(QUAD); position(0) }
            GLES20.glClearColor(0.039f, 0.039f, 0.063f, 1f) // #0A0A10
        }

        override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
            GLES20.glViewport(0, 0, width, height)
        }

        override fun onDrawFrame(gl: GL10?) {
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            GLES20.glUseProgram(program)

            val positionSlot = GLES20.glGetAttribLocation(program, "aPosition")
            GLES20.glEnableVertexAttribArray(positionSlot)
            GLES20.glVertexAttribPointer(positionSlot, 2, GLES20.GL_FLOAT, false, 0, quad)

            GLES20.glUniform3fv(GLES20.glGetUniformLocation(program, "uNodes"), MAX_NODES, nodes, 0)
            GLES20.glUniform1i(GLES20.glGetUniformLocation(program, "uNodeCount"), nodeCount)
            GLES20.glUniform1f(GLES20.glGetUniformLocation(program, "uThreshold"), threshold)
            GLES20.glUniform1f(GLES20.glGetUniformLocation(program, "uProgress"), progress)
            GLES20.glUniform3fv(GLES20.glGetUniformLocation(program, "uColour"), 1, colour, 0)

            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GLES20.glDisableVertexAttribArray(positionSlot)
        }

        private fun buildProgram(vertexSource: String, fragmentSource: String): Int {
            val vertex = compile(GLES20.GL_VERTEX_SHADER, vertexSource)
            val fragment = compile(GLES20.GL_FRAGMENT_SHADER, fragmentSource)
            val id = GLES20.glCreateProgram()
            GLES20.glAttachShader(id, vertex)
            GLES20.glAttachShader(id, fragment)
            GLES20.glLinkProgram(id)
            // A link failure would otherwise render nothing and say nothing.
            val status = IntArray(1)
            GLES20.glGetProgramiv(id, GLES20.GL_LINK_STATUS, status, 0)
            check(status[0] == GLES20.GL_TRUE) {
                "program link failed: " + GLES20.glGetProgramInfoLog(id)
            }
            return id
        }

        private fun compile(type: Int, source: String): Int {
            val shader = GLES20.glCreateShader(type)
            GLES20.glShaderSource(shader, source)
            GLES20.glCompileShader(shader)
            val status = IntArray(1)
            GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, status, 0)
            check(status[0] == GLES20.GL_TRUE) {
                "shader compile failed: " + GLES20.glGetShaderInfoLog(shader)
            }
            return shader
        }

        companion object {
            const val MAX_NODES = 64

            private val QUAD = floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)

            private const val VERTEX_SHADER = """
                attribute vec2 aPosition;
                varying vec2 vUv;
                void main() {
                    vUv = aPosition * 0.5 + 0.5;
                    // Aspect handling is deliberately left to the caller's node layout: the
                    // shape programs already carry the design's aspect ratio, and a square-blob
                    // distortion here would double-correct it.
                    gl_Position = vec4(aPosition, 0.0, 1.0);
                }
            """

            private const val FRAGMENT_SHADER = """
                precision mediump float;
                varying vec2 vUv;
                uniform vec3 uNodes[$MAX_NODES];   // xy = position, z = radius
                uniform int uNodeCount;
                uniform float uThreshold;
                uniform float uProgress;
                uniform vec3 uColour;

                void main() {
                    // Idle: no nodes yet, so breathe a single centred mass.
                    if (uNodeCount == 0) {
                        vec2 d = (vUv - 0.5) * vec2(1.0, 0.6);
                        float f = 0.045 / max(dot(d, d), 1e-5);
                        float edge = smoothstep(uThreshold - 0.35, uThreshold + 0.35, f);
                        gl_FragColor = vec4(uColour * edge, edge * 0.9);
                        return;
                    }

                    float field = 0.0;
                    for (int i = 0; i < $MAX_NODES; i++) {
                        if (i >= uNodeCount) break;
                        vec3 n = uNodes[i];
                        vec2 d = vUv - n.xy;
                        field += (n.z * n.z) / max(dot(d, d), 1e-5);
                    }

                    // Amorphous forms wobble; a settled plan must not. Wobble is zero at
                    // progress 1, which is what makes the settled surface match the geometry
                    // that actually gets cut.
                    float wobble = sin(vUv.x * 37.0 + vUv.y * 29.0) * 0.08 * (1.0 - uProgress);
                    field += wobble * 0.12;

                    float inside = step(uThreshold, field);
                    float edge = smoothstep(uThreshold - 0.25, uThreshold + 0.25, field);
                    vec3 base = uColour * (0.45 + 0.55 * edge);
                    gl_FragColor = vec4(base, inside * 0.95 + edge * 0.05);
                }
            """
        }
    }
}
