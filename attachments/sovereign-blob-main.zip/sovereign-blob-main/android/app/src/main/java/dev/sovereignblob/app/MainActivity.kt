package dev.sovereignblob.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import dev.sovereignblob.reality.RealityChecks

/**
 * The one screen.
 *
 * Layout follows a single rule from the spec: the blob IS the status. Colour is not a badge
 * beside an indicator, it is the surface — which is why the state colour here comes from the
 * same table as the JavaScript side (config/proto-states.json) and not from a hardcoded value
 * in the UI layer.
 *
 * Speech uses the platform RecognizerIntent. It is invoked as an activity result rather than
 * held open, so the screen never owns the microphone and cannot leak it.
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BlobScreen() }
    }
}

/** Colour table, mirroring config/proto-states.json. Kept in one place on this side too. */
enum class BlobState(val label: String, val colour: Color) {
    IDLE("Idle", Color(0xFF1E5BFF)),
    FORMING("Forming", Color(0xFF00E5FF)),
    VALIDATING("Validating", Color(0xFFFFB020)),
    READY("Ready", Color(0xFF00FFCC)),
    BLOCKED("Blocked", Color(0xFFFF3B30));

    companion object {
        /** Spec section 9 bands: 0-49 BLOCKED, 50-74 CAUTION, 75-100 READY. */
        fun fromScore(score: Int): BlobState = when {
            score < 50 -> BLOCKED
            score < 75 -> VALIDATING
            else -> READY
        }
    }
}

@Composable
fun BlobScreen() {
    val context = LocalContext.current
    var transcript by remember { mutableStateOf("") }
    var status by remember { mutableStateOf(BlobState.IDLE) }
    var score by remember { mutableStateOf(0) }
    var lines by remember { mutableStateOf(listOf("Blob idle. Say or type what you want to build.")) }

    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
        if (!spoken.isNullOrBlank()) {
            transcript = spoken
            evaluate(spoken, lines) { newLines, newStatus, newScore ->
                lines = newLines; status = newStatus; score = newScore
            }
        }
    }

    val micPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) launchSpeech(context, speechLauncher) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A10))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("SOVEREIGN BLOB", color = Color(0xFF00E5FF), fontSize = 18.sp)

        // The blob. Idle shows the breathing field; every other state tints the same surface.
        AndroidView(
            factory = { ctx -> ProtoMatterView(ctx) },
            update = { view ->
                view.setField(
                    nodes = FloatArray(64 * 3),
                    nodeCount = 0,
                    threshold = 1.0f,
                    colour = floatArrayOf(
                        status.colour.red, status.colour.green, status.colour.blue
                    ),
                    progress = if (status == BlobState.READY) 1f else 0f
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(260.dp)
        )

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "${status.label}  |  Reality ${score}/100",
                color = status.colour,
                fontSize = 15.sp
            )
        }

        BasicTextField(
            value = transcript,
            onValueChange = { transcript = it },
            textStyle = TextStyle(color = Color(0xFFD8FFF7), fontSize = 15.sp),
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF15152A))
                .padding(12.dp)
        )
        Text("typed input works with no microphone and no network", color = Color(0xFF7C8FA0), fontSize = 11.sp)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                if (ContextCompatCheck(context)) launchSpeech(context, speechLauncher)
                else micPermission.launch(Manifest.permission.RECORD_AUDIO)
            }) { Text("Speak") }

            Button(onClick = {
                if (transcript.isNotBlank()) {
                    evaluate(transcript, lines) { l, s, sc -> lines = l; status = s; score = sc }
                }
            }) { Text("Generate") }
        }

        Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
            for (line in lines) {
                Text(line, color = Color(0xFFD8FFF7), fontSize = 12.sp)
                Spacer(Modifier.height(4.dp))
            }
        }
    }
}

private fun ContextCompatCheck(context: android.content.Context): Boolean =
    context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

private fun launchSpeech(
    context: android.content.Context,
    launcher: androidx.activity.result.ActivityResultLauncher<Intent>
) {
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_PROMPT, "Describe what you want to build")
    }
    launcher.launch(intent)
}

/**
 * Runs the structural checks ON THE DEVICE and renders the verdict.
 *
 * This is the offline path: no bridge, no network, no AI. It exists because layer 3 has to
 * answer when the phone is in a shed with no signal, and because the 18 mm / 21 mm verdict is
 * the one result the whole product stands on.
 */
private fun evaluate(
    utterance: String,
    previous: List<String>,
    onResult: (List<String>, BlobState, Int) -> Unit
) {
    val width = 900.0
    val depth = 300.0
    val thickness = 18.0
    val thicknessRemedy = 21.0
    val span = RealityChecks.clearSpan(width, thickness)
    val density = 680.0
    val elastic = 10300.0
    val load = 25.0

    fun selfMass(t: Double) = depth * t * span * density / 1_000_000_000.0

    val at18 = RealityChecks.shelfDeflection(span, thickness, depth, elastic, load, selfMass(thickness))
    val at21 = RealityChecks.shelfDeflection(span, thicknessRemedy, depth, elastic, load, selfMass(thicknessRemedy))
    val tip = RealityChecks.tipOverMargin(width, 1800.0, depth, massKg = 30.0, loadKg = load)

    val lines = buildList {
        addAll(previous.filter { !it.startsWith("Reality") && !it.startsWith("Structural") && !it.startsWith("Tip") })
        add("Intent: goal=bookshelf from \"$utterance\"")
        add("Span ${span.toInt()} mm, ${thickness.toInt()} mm material")
        add("Structural: long-term sag ${at18.longTermMm} mm vs ${at18.limitMm} mm allowance -> " + if (at18.passes) "PASS" else "FAIL")
        if (!at18.passes) {
            add("Correction: ${thicknessRemedy.toInt()} mm gives ${at21.longTermMm} mm -> " + if (at21.passes) "PASS" else "FAIL")
        }
        if (tip != null) add("Tip-over margin $tip — wall fixing " + if (tip < 0.5) "REQUIRED" else "optional")
        add("Full cost, nesting and DXF need the local bridge; this verdict is computed offline.")
    }

    // Score mirrors the JS weighting shape: structural dominates, and a failed structural
    // check cannot land in the READY band however good everything else is.
    val score = when {
        !at18.passes -> 42
        tip != null && tip < 0.5 -> 68
        else -> 88
    }
    onResult(lines, BlobState.fromScore(score), score)
}
