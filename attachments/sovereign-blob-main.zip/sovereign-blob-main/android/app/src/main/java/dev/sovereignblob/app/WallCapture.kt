package dev.sovereignblob.app

import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * CameraX wall capture (AC SB-040).
 *
 * THE HONEST PART, FIRST
 * A single RGB camera cannot measure distance. There is no depth in a monocular image without
 * either a known reference length in frame or a motion/depth sensor, so this file does NOT
 * claim to produce wall dimensions from an image. What it produces is:
 *
 *   - a luma/edge-based estimate of WHERE the wall plane is in frame, with a confidence
 *   - a scale requiring an explicit reference, or an error if none is available
 *
 * Two scale strategies are provided. `ReferenceObjectScale` is real: the operator marks two
 * points whose real distance is known. `ArDepthScale` is a declared interface with no
 * implementation, and it throws with a message saying so, because a stub that returns a
 * plausible number is how a 2400 mm wall becomes a 1900 mm wall and a shelf gets cut wrong.
 *
 * The consequence for the product: the wall scan is an ASSISTED measurement, and the SBM
 * records `source = "camera-assisted"` with the confidence attached so nothing downstream can
 * mistake it for a survey.
 */
object WallCapture {

    /** Result of looking at a frame. Pixel-space only — no millimetres. */
    data class WallEstimate(
        val leftFraction: Float,
        val topFraction: Float,
        val rightFraction: Float,
        val bottomFraction: Float,
        val confidence: Float
    )

    /**
     * Estimates the largest low-variance region, which on a wall shot is the wall itself.
     * Coarse on purpose: it is an aid for framing, not a measurement. The 16x16 grid keeps it
     * fast enough to run on every frame without starving the preview.
     */
    class WallAnalyzer(private val onEstimate: (WallEstimate) -> Unit) : ImageAnalysis.Analyzer {
        override fun analyze(image: ImageProxy) {
            try {
                val luma = image.planes[0].buffer
                val width = image.width
                val height = image.height
                val rowStride = image.planes[0].rowStride
                val grid = 16

                var minGlobal = 255
                var maxGlobal = 0
                val cells = FloatArray(grid * grid)
                for (gy in 0 until grid) {
                    for (gx in 0 until grid) {
                        val x = (gx + 0.5f) / grid * (width - 1)
                        val y = (gy + 0.5f) / grid * (height - 1)
                        val index = (y.toInt() * rowStride) + x.toInt()
                        if (index >= luma.limit()) continue
                        val v = luma.get(index).toInt() and 0xFF
                        cells[gy * grid + gx] = v.toFloat()
                        if (v < minGlobal) minGlobal = v
                        if (v > maxGlobal) maxGlobal = v
                    }
                }

                // A frame with almost no contrast carries no plane information, so it reports
                // zero confidence instead of guessing an edge.
                val spread = (maxGlobal - minGlobal).toFloat()
                if (spread < 18f) {
                    onEstimate(WallEstimate(0f, 0f, 1f, 1f, 0f))
                    return
                }

                val centre = cells[grid * grid / 2 + grid / 2]
                var left = grid - 1
                var right = 0
                var top = grid - 1
                var bottom = 0
                var covered = 0
                for (gy in 0 until grid) {
                    for (gx in 0 until grid) {
                        if (abs(cells[gy * grid + gx] - centre) < spread * 0.22f) {
                            covered++
                            if (gx < left) left = gx
                            if (gx > right) right = gx
                            if (gy < top) top = gy
                            if (gy > bottom) bottom = gy
                        }
                    }
                }

                // Confidence: how much of the frame is that plane, tempered by how much
                // structure is inside it. A wall filling the frame with visible skirting scores
                // lower than a blank wall, which is correct — the skirting is a real datum that
                // should be measured, not smoothed over.
                val areaFraction = covered.toFloat() / (grid * grid)
                val confidence = (areaFraction * 0.9f + (spread / 255f) * 0.1f).coerceIn(0f, 1f)

                onEstimate(
                    WallEstimate(
                        leftFraction = left.toFloat() / grid,
                        topFraction = top.toFloat() / grid,
                        rightFraction = (right + 1).toFloat() / grid,
                        bottomFraction = (bottom + 1).toFloat() / grid,
                        confidence = confidence
                    )
                )
            } finally {
                image.close()
            }
        }
    }

    /** Turns a pixel-space estimate into millimetres. Requires a real scale source. */
    interface MetricScale {
        val source: String
        /** @return millimetres per normalised viewport unit, or throws if it cannot know. */
        fun millimetresPerUnit(): Float
    }

    /**
     * Real scale from a known reference in frame. The operator marks two points and supplies
     * the true distance; everything else follows.
     */
    class ReferenceObjectScale(
        private val markedSpanFraction: Float,
        private val trueMm: Float
    ) : MetricScale {
        override val source = "reference-object"

        override fun millimetresPerUnit(): Float {
            require(markedSpanFraction > 0.01f) {
                "reference span is too small to scale from; mark two points further apart"
            }
            return trueMm / markedSpanFraction
        }
    }

    /**
     * Depth-based scale. NOT IMPLEMENTED. Kept as a declared type so the app can ask for it and
     * be told no, rather than silently falling back to a guess.
     */
    class ArDepthScale : MetricScale {
        override val source = "arcore-depth"

        override fun millimetresPerUnit(): Float = throw UnsupportedOperationException(
            "ARCore depth is not wired up. A depth sensor or an AR session is required for metric " +
                "measurement; without one the app uses ReferenceObjectScale or typed dimensions. " +
                "Returning an estimated scale here would silently mis-size every cut."
        )
    }

    const val PERMISSION_RATIONALE =
        "Camera access measures the wall you want to build against. Without it you can still type " +
            "the dimensions, and the design is marked as unmeasured rather than assumed."

    /** Binds Preview + ImageAnalysis. Returns the executor so the caller can shut it down. */
    fun bind(
        lifecycleOwner: LifecycleOwner,
        context: android.content.Context,
        previewView: PreviewView,
        onEstimate: (WallEstimate) -> Unit,
        onError: (Throwable) -> Unit
    ): java.util.concurrent.ExecutorService {
        val executor = Executors.newSingleThreadExecutor()
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            try {
                val provider = future.get()
                // CameraX exposes this as a setter method, not a property — the property-style
                // assignment fails to compile with "Unresolved reference 'surfaceProvider'".
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(executor, WallAnalyzer(onEstimate))
                provider.unbindAll()
                provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (t: Throwable) {
                // No camera is not a fatal state: the app falls back to typed dimensions.
                onError(t)
            }
        }, ContextCompat.getMainExecutor(context))
        return executor
    }
}
