# Beta extension plan

Four axes: **object types**, **sensor integrations**, **supplier connectors**, and the wider
**ProtoMatter ecosystem**. For each, what already extends without a code change, what does not,
and what the interface has to be.

The distinction matters more than the list. An extension point that has never had a second
implementation is a guess. The ones marked **proven** below have one.

---

## 1. Object types — partially proven

**Proven:** supply mode. `config/regions.json` holds profiles that pin sheet size, currency and
price source; adding one is a config edit, and `tests/region.test.mjs` asserts the sheet-bounds
invariant for both profiles. Objective sizes also snap to stocked thicknesses rather than
accepting any number (`src/engine/materials.js`).

**Not yet possible:** a new object type. `src/engine/cutlist.js` knows how to break down a
case-goods bookshelf and nothing else. The intent parser recognises other nouns but produces
the same geometry.

**Required interface — to add, config-first:**

```jsonc
// config/object-types.json  (does not exist yet)
{
  "id": "bench",
  "label": "Low bench",
  "params": { "widthMm": {}, "heightMm": {}, "depthMm": {}, "thicknessMm": {} },
  "generator": "panel-case",     // a key into a generator registry
  "supports": ["sag", "tip-over", "nesting"],
  "defaults": { "widthMm": 1200, "heightMm": 450, "depthMm": 350 }
}
```

and a generator registry with the same shape as the existing breakdown:

```js
// src/engine/generators/index.js
export const generators = {
  'panel-case': (spec) => ({ parts: [...], checks: {...}, joinery: {...} })
};
```

**Then:** the intent parser resolves `objectType` → registry entry → generator, and nothing in
the pipeline changes. The honest cost: a second generator is real engineering work, and the
sag check must be re-derived per topology (a bench top spanning its legs is a different beam
case from a shelf in a case). Do not assume the current check transfers.

**Order:** add `bench` first, because it is a two-support beam and will expose where the
structural model is genuinely bookshelf-specific.

---

## 2. Sensor integrations — contract proven, capture absent

**Proven:** the telemetry path. `config/environment.json` holds threshold bands; the ESP32 node
posts JSON; `src/sensors/telemetry.js` validates ranges, derives orientation and vibration, and
reports staleness rather than trusting timestamps. Firmware exists for BME280, BH1750 and
MPU-6050 (`firmware/esp32-sensor-node/`). Unknown or out-of-range values are rejected instead
of clamped silently (`tests/pipeline.test.mjs`).

**Not yet possible:** adding a sensor without editing the decoder. `NUMERIC_RANGES` in
telemetry.js is a hardcoded table, and `parseTelemetry` knows each field by name.

**Required interface:**

```jsonc
// config/sensors.json  (does not exist yet)
{
  "bme280": {
    "address": "0x76", "bus": "i2c",
    "fields": {
      "tempC":       { "unit": "C",   "range": [-40, 85] },
      "humidityPct": { "unit": "%RH", "range": [0, 100] },
      "pressureHpa": { "unit": "hPa", "range": [300, 1100] }
    },
    "advisories": ["material-stability", "finish-cure"]
  }
}
```

The decoder becomes range-driven from this file, and an unknown sensor fails loudly instead of
being ignored. Camera and IMU (ARCore / CameraX) belong on the same registry but need a native
producer, not just a decoder — see SPEC-DEVIATIONS.md §6: there is no `camera/` implementation.

**Explicit non-goal for Beta:** do not convert relative humidity into equilibrium moisture
content without a species sorption table. The current code deliberately does not, and says so
in the source; estimating it from two numbers would produce a confident wrong answer.

---

## 3. Supplier connectors — partially proven

**Proven:** the adapter shape. `src/vendor/vendors.js` resolves suppliers from
`vendor/price-book.json`, generates a sheet-goods RFQ and a CNC job payload, and
`config/services.json` records each service's **verified** status, with `region` fields so a
Mode A job cannot advertise a bureau on another continent (asserted in `tests/region.test.mjs`).
A real quote request went out over the mail connector; records are committed.

**Not yet possible:** automated quoting. Every cut-to-size route in the registry is
`form-only` or requires credentials. Worse, one plywood price is a **bulk tier at MOQ 400**
against a 2-sheet build, and a **classifieds listing** supplies the local price — the weakest
number in the chain, flagged as such rather than smoothed over.

**Required interface:**

```js
// src/vendor/adapters/<name>.js
export default {
  id: 'eb-cabinetry',
  kind: 'email-rfq',              // 'email-rfq' | 'http-api' | 'form-export'
  region: 'au-qld-local',
  capabilities: ['cut-to-size', 'edge-banding'],
  async quote(bom) { /* → { quoteRef, unitPrice, leadTimeDays, ... } */ },
  async submit(rfq) { /* → { submittedAt, channel } */ },
  termsOfUse: 'form-only — a human must submit; do not automate against the form'
};
```

**Two rules for this axis:**
1. **Never fabricate a price.** The current engine emits `unpriced[]` and lowers confidence
   instead. A connector that returns an invented number is worse than no connector, because it
   propagates into every design that follows.
2. **Respect form-only.** A connector may prepare a submission payload; it must not post to a
   form without the operator's consent. The five destinations in `output/quote-requests/` are
   form-only for exactly this reason.

---

## 4. ProtoMatter ecosystem — proven at the data layer only

**Proven and data-driven:** the state/colour table (`config/proto-states.json`, mirrored in
Kotlin and checked by test), the material library, the region profiles, and the shape programs
in `src/blob/shapes.js`, which already interpolate between an amorphous cloud and a shaped
program with a progress value.

**Not yet possible:** a third-party shape or renderer. There is no published shape-program
format, and `morph()` requires matching node counts.

**The leverage here is the SBM, not the renderer.** The spec's own IP position is that "people
speak SBM" — so the ecosystem play is a frozen, versioned schema that other tools can read and
write, with the manifest as the interchange point. Concretely, in order:

1. **Freeze SBM 0.2 and publish it** with the six schemas in `contracts/schemas.json`. They are
   already machine-readable and zero-dependency validatable, which is what makes this cheap now.
2. **Publish a shape-program format** so a ProtoMatter object is portable: node list, weights,
   threshold, and the settled rectilinear plan.
3. **Only then** a plugin API for renderers. A renderer API before a data format is a locked-in
   choice made blind.

**Sovereign Knowledge Graph (Layer 6):** no implementation, and one prerequisite. The feedback
loop exists (`bin/validate-build.mjs` turns a measured sag into a calibrated elastic modulus)
but has never run on a real measurement. A knowledge graph built on zero measurements would be
a graph of assumptions. Build the first shelf first.
