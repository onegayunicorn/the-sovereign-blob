# Alpha sprint status

Every acceptance criterion in the spec's sprint backlog, against what actually exists. The
test column names the assertion that proves it, so "done" is checkable rather than asserted.
Anything needing an Android device or a physical build is marked as such and not claimed.

Run everything: `npm test`

| ID | Criterion | Status | Evidence |
|---|---|---|---|
| **SB-001** | Blob appears < 2 s, animates, 60 fps on device | **SOURCE COMPILES / fps NOT MEASURED** | The OpenGL ES 2 renderer exists (`ProtoMatterView.kt`, metaball field evaluated in the fragment shader) and the app module builds into a debug APK. **No device or emulator was used**, so the 2-second launch and 60 fps criteria are unmeasured. The field math it draws is separately tested in `tests/blob.test.mjs`. |
| **SB-002** | Idle=Blue, Forming=Cyan, Validating=Amber, Ready=Green, Blocked=Red | **DONE** | `config/proto-states.json`; `tests/contracts.test.mjs` → "the state colours are exactly the five the spec names" and "the Kotlin enum and the JS config cannot drift apart" |
| **SB-010** | Tap Speak → mic → transcript → stored in Intent Engine | **PARTIAL** | Capture path exists in `src/app.js` using the browser Speech API, with typed input as a fallback. On-device Android `SpeechRecognizer` is not wired, and browser speech is **not** guaranteed on-device (Chrome typically sends audio to a server), so no local-speech claim is made. |
| **SB-011** | "Build a bookshelf here" → goal + location, persisted | **DONE** | `tests/alpha.test.mjs` → "SB-011: …yields the goal, a location, and it persists" and "the intent survives a modification" |
| **SB-020** | Reality Score returned 0–100, visible | **DONE** | Same file, "SB-020"; surfaced in SBM `reality.score` and in the UI |
| **SB-021** | 18 mm FAIL, 21 mm PASS | **DONE** | `tests/alpha.test.mjs` → "SB-021" (at the default 864 mm span; see SPEC-DEVIATIONS.md §1 for why not at 1758 mm) |
| **SB-022** | Blocked designs explain failure + recommended correction | **DONE** | `tests/alpha.test.mjs` → "SB-022", which asserts the explanation contains real measurements, not adjectives |
| **SB-030** | New project creates SBM, schema validates, stored locally | **DONE** | `tests/alpha.test.mjs` → "SB-030"; schema is `contracts/schemas.json`, validator is zero-dependency |
| **SB-031** | Projects reopen, state restored, no data loss | **DONE** | `tests/alpha.test.mjs` → "SB-031" (file round-trip, deep-equal); live round-trip verified over HTTP via `GET /api/project/:id` |
| **SB-040** | Wall captured, W/H estimated, confidence score | **CAPTURE CODE COMPILES / NO DEVICE RUN** | `WallCapture.kt` implements a CameraX `ImageAnalysis` analyzer producing a pixel-space plane estimate plus a confidence score, and it compiles into the APK. **It has never run against a real camera.** Two honest limits are baked into the types: a single RGB camera cannot produce metric dimensions, so `ReferenceObjectScale` requires a known reference length and `ArDepthScale` **throws** rather than returning a plausible guess. Confidence semantics are tested on the consumer side (`tests/alpha.test.mjs` → "SB-040"). |
| **SB-041** | Shelf fits wall bounds, constraints applied | **DONE** | `tests/alpha.test.mjs` → "SB-041" tests both gates separately: the anchor enforces wall width, `validateRoom` enforces the room envelope |
| **SB-050** | PDF with cut list, materials, assembly steps | **DONE** | `tests/alpha.test.mjs` → two tests, including a structural re-read of the produced bytes proving every xref offset resolves |
| **SB-051** | DXF generated, geometry validates, importable | **PARTIAL** | Generated and validated (`tests/alpha.test.mjs` → "SB-051": mm units, finite non-negative coordinates, every LINE complete). "Importable into CAD software" is **not** proven here — that needs an actual CAD import, which has not been done. |
| **SB-052** | Replay: timeline, voice history, Reality corrections | **DONE** | `tests/alpha.test.mjs` → "SB-052", which asserts the *rejected* step is present. A replay that omits the rejection is a sales document. |
| **SB-060** | Locked anchor cannot change; violation → BLOCKED | **DONE** | Three tests: the refusal, the forced BLOCKED overriding the score band, and the unlocked-advisory case |
| **SB-070** | DXF used, shelf built, assembly completed | **NOT DONE** | Requires a physical build. The quote request to a Gold Coast bureau was sent 2026-09-28 (`output/quote-requests/sent-email-*.txt`); no reply yet, no cut panels. |
| **SB-071** | Measured results recorded, SBM updated, validation complete | **MECHANISM DONE / NOT EXERCISED** | `tests/alpha.test.mjs` → "SB-071" proves measurement lands in `audit.physicalValidation` and the manifest still validates. `bin/validate-build.mjs` derives a calibrated elastic modulus from a real measurement (verified against a synthetic record). **No real measurement exists yet** because no shelf has been built. |

## Definition of Done — honest tally

| DoD item | State |
|---|---|
| User scans wall | Capture absent — consumer side ready |
| User says "Build a bookshelf here" | Done |
| ProtoMatter forms the object | Field + morph + settled plan done and tested; on-screen rendering not verified in this environment |
| Reality Engine evaluates | Done |
| 18 mm → BLOCKED with explanation | Done |
| 21 mm → READY | **72/100 → CAUTION, not READY.** Structural check passes; the score is held down by information gaps, not structure. See SPEC-DEVIATIONS.md §2. |
| SBM generated and validates | Done |
| PDF build packet | Done |
| DXF importable | Generated and validated; CAD import unproven |
| Conversation Replay | Done |
| Shelf physically fabricated | Not done |
| Measurements fed back into audit | Mechanism done, unexercised |

**The loop is closed in software from intent to export.** The last two items are the physical
ones, and they are the ones the whole project exists to reach — so they are the two that are
not claimed.
