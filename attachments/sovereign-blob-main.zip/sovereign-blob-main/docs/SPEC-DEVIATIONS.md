# Where the implementation disagrees with the spec

Alpha spec v1.1 is the source of truth for behaviour. This file records the places where it
contradicts itself or the physics, and what was implemented instead. Each entry is a decision
someone can reverse; none of them were resolved silently.

---

## 1. The example sag numbers are not physically possible at the example geometry

**Spec says** (section 11, `audit.realityDecisions`): at a **1758 mm** shelf span, 18 mm
"predicted sag 6.2 mm", and 21 mm "predicted sag 1.4 mm — within tolerance", and section 18
requires 21 mm to reach READY.

**The engine computes** for that geometry (1800 mm wall, 21 mm, 35 kg per shelf):

| Thickness | Span | Immediate | Long-term | Allowance (span/360) | Verdict |
|---|---|---|---|---|---|
| 18 mm | 1764 mm | 19.4 mm | **38.7 mm** | 4.9 mm | FAIL (790%) |
| 21 mm | 1758 mm | 12.4 mm | **24.8 mm** | 4.9 mm | FAIL (507%) |
| 25 mm | 1750 mm | 7.5 mm | **14.9 mm** | 4.9 mm | FAIL (308%) |

Going from 18 mm to 21 mm changes the second moment of area by (21/18)³ = 1.59, so a 6.2 mm
sag cannot become 1.4 mm — that would need a 4.4× stiffness change, i.e. about 42 mm of
plywood. The example numbers are consistent with a span in the ~900 mm range, not 1758 mm.

**What was implemented:** the calculation, not the claim. At the geometry in the spec's own
example, no stocked thickness passes, and the manifest says FAIL with the numbers.
`fitToWall` is therefore **off by default** — spanning an 1800 mm wall needs intermediate
supports, which the generator does not yet add. Defaulting it on would emit wall-to-wall
designs that the manifest immediately marks FAIL, teaching users to distrust the FAIL.

**Unresolved:** the remedy search only considers *one* mid-rail. For a 1758 mm span the
required support count is roughly 3 bays (spans ≈ 590 mm). Extending the remedy to search
support count is the next piece of real work.

---

## 2. Score band versus the status in every example

**Spec section 9:** 0–49 BLOCKED, 50–74 CAUTION, 75–100 READY.
**Spec sections 11 and 14:** score **72** with status **READY** — twice.

72 is CAUTION under the stated rule.

**What was implemented:** section 9's bands, because it is the section that states a rule and
it is the only one that can be applied consistently. The bands live in
`config/proto-states.json` and a test asserts they tile 0–100 with no gap. Consequence worth
knowing: the 21 mm design scores **72** and renders as **CAUTION (amber)**, not READY (green).
It is not inflated to reach green, and the reason it is not green is in the manifest as
`reality.confidenceBasis`: the material modulus is a handbook value and two cost lines have no
verified price. The structural check itself passes.

---

## 3. `anchorType` vs `type`

**Spec section 10** uses `anchorType`. **Spec section 11's SBM example** uses `type`, and that
example is the one given in full.

**What was implemented:** both accepted on input, both written on output, and neither is
required by the schema so the spec's example validates exactly as written. The requirement
that at least one is present is enforced in `src/reality/anchors.js` where anchors are actually
consumed, which fails loudly on an anchor with neither.

---

## 4. The Maximum Load anchor value

**Spec section 10** shows anchor C at **35 kg**. **Spec section 7's Intent example** and this
project's default design use **25 kg per shelf**.

**What was implemented:** the anchor holds the stated **35 kg safe working load**, deliberately
*not* the load the current design requests. An earlier version derived the ceiling from
`spec.loadPerShelfKg`, which a test caught: it made the anchor impossible to violate, since the
design could never exceed a ceiling computed from itself. A constraint derived from the thing
it constrains is decoration. `spec.maxLoadKg` overrides it.

---

## 5. SB-011 location value

**Spec section 7** shows `location: "wall"` for "Build a bookshelf here".
**SB-011 in the sprint backlog** shows `location: "current_view"` for the same input.

**What was implemented:** a deictic ("here", "this wall", "this spot") yields `current_view`;
an explicit mention of a wall without a deictic yields `wall`; neither yields `unspecified`.
The test accepts either of the spec's two values. `here` is a user pointing at a place, so the
pointer wins.

---

## 6. Section 4's repository structure is not used

The spec proposes `app/`, `proto/`, `reality/`, `sbm/`, `exports/`, `camera/`, `sensors/`,
`tests/`, `docs/`.

**What exists instead:** `src/` (working implementation, already under test), `contracts/`
(schemas), `android/` (Kotlin interface contracts), `bridge/`, `bin/`, `config/`, `vendor/`,
`docs/`. Restructuring `src/` to match would be churn across ~40 files and every import, for a
layout benefit that only matters once the Android app module exists. The mapping is:

| Spec path | Actual path |
|---|---|
| `proto/` | `src/blob/` + `src/proto/` |
| `intent/` | `src/intent/` |
| `society`/`reality/` | `src/reality/` + `src/engine/` |
| `sbm/` | `src/sbm/` + `contracts/` |
| `exports/` | `src/exports/` + `src/export/` |
| `sensors/` | `src/sensors/` + `firmware/` |
| `camera/` | **absent** — no AR wall capture is implemented |

---

## 7. Layers documented as AI-independent

Spec section 2 requires layers 1–4 to survive with no AI. **No AI is used anywhere in this
implementation**, so the requirement holds trivially: the engine is deterministic rules and
hand calculations. Layer 5 (AI Forge) is not implemented at all. There is no placeholder
module pretending otherwise.
