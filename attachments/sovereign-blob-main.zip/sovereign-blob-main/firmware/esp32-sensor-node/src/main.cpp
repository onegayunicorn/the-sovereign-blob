/**
 * Sovereign Blob — ESP32 sensor node
 *
 * Emits one JSON object per interval to the local bridge. That is the whole job: the
 * node is a sensor front end, and it deliberately holds no design logic so that two
 * people with two different nodes cannot disagree about what a design is.
 *
 *   { deviceId, ts, tempC, humidityPct, pressureHpa, lux,
 *     ax, ay, az, gx, gy, gz, batteryV, rssiDbm, fw }
 *
 * Sensors:
 *   BME280   temperature / humidity / pressure   (I2C 0x76 or 0x77)
 *   BH1750   ambient light                       (I2C 0x23)
 *   MPU-6050 accelerometer + gyroscope           (I2C 0x68)
 *
 * The MPU-6050 is driven by raw register reads rather than a library: it is a handful
 * of registers, and it removes a dependency that is a common source of build breakage.
 *
 * NOT VERIFIED ON HARDWARE. This code has been written and reviewed, not flashed. The
 * register addresses and scales are from the MPU-6050 datasheet, but you should expect
 * to confirm the WHO_AM_I value and the I2C addresses on your own boards.
 */

#include <Arduino.h>
#include <Wire.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <Adafruit_BME280.h>
#include <BH1750.h>
#include <ArduinoJson.h>

#include "secrets.h"

#ifndef BLOB_FW_VERSION
#define BLOB_FW_VERSION "0.1.0"
#endif

// ---- MPU-6050 registers ----------------------------------------------------
static const uint8_t MPU_ADDR = 0x68;
static const uint8_t REG_PWR_MGMT_1 = 0x6B;
static const uint8_t REG_WHO_AM_I = 0x75;
static const uint8_t REG_ACCEL_XOUT_H = 0x3B;
static const uint8_t REG_GYRO_CONFIG = 0x1B;
static const uint8_t REG_ACCEL_CONFIG = 0x1C;
static const float ACCEL_SCALE = 16384.0f; // +/- 2 g  -> LSB per g
static const float GYRO_SCALE = 131.0f;    // +/- 250 deg/s -> LSB per deg/s

Adafruit_BME280 bme;
BH1750 lightMeter;
bool bmeOk = false;
bool luxOk = false;
bool imuOk = false;

// Small ring buffer so a dropped Wi-Fi link does not lose the record of what the
// room was doing while it was down.
static const uint8_t RING = 8;
struct Reading {
  char json[512];
  uint32_t at;
};
Reading ring[RING];
uint8_t ringHead = 0;
uint8_t ringCount = 0;

uint32_t lastSample = 0;

// ---------------------------------------------------------------------------
static void scanI2C() {
  Serial.println(F("[i2c] scanning bus..."));
  for (uint8_t addr = 1; addr < 127; addr++) {
    Wire.beginTransmission(addr);
    if (Wire.endTransmission() == 0) {
      Serial.printf("[i2c] device at 0x%02X\n", addr);
    }
  }
}

static bool imuInit() {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(REG_WHO_AM_I);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((uint8_t)MPU_ADDR, (uint8_t)1) != 1) return false;
  const uint8_t who = Wire.read();
  // 0x68 for MPU-6050 and most clones; 0x70-0x73 for some MPU-6500/9250 variants.
  Serial.printf("[imu] WHO_AM_I = 0x%02X\n", who);
  if (who != 0x68 && who != 0x70 && who != 0x71 && who != 0x73 && who != 0x98) return false;

  Wire.beginTransmission(MPU_ADDR);
  Wire.write(REG_PWR_MGMT_1);
  Wire.write(0x00); // wake, use internal oscillator
  if (Wire.endTransmission() != 0) return false;
  delay(50);

  Wire.beginTransmission(MPU_ADDR);
  Wire.write(REG_ACCEL_CONFIG);
  Wire.write(0x00); // +/- 2 g
  Wire.endTransmission();
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(REG_GYRO_CONFIG);
  Wire.write(0x00); // +/- 250 deg/s
  Wire.endTransmission();
  return true;
}

static bool imuRead(float &ax, float &ay, float &az, float &gx, float &gy, float &gz) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(REG_ACCEL_XOUT_H);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((uint8_t)MPU_ADDR, (uint8_t)14) != 14) return false;

  int16_t raw[7];
  for (uint8_t i = 0; i < 7; i++) {
    raw[i] = (int16_t)((Wire.read() << 8) | Wire.read());
  }
  ax = raw[0] / ACCEL_SCALE;
  ay = raw[1] / ACCEL_SCALE;
  az = raw[2] / ACCEL_SCALE;
  // raw[3] is the on-die temperature, deliberately unused: the BME280 measures room
  // temperature with far better isolation from self-heating.
  gx = raw[4] / GYRO_SCALE;
  gy = raw[5] / GYRO_SCALE;
  gz = raw[6] / GYRO_SCALE;
  return true;
}

static void connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.printf("[wifi] connecting to %s", WIFI_SSID);
  const uint32_t start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 20000) {
    delay(400);
    Serial.print('.');
  }
  Serial.println();
  if (WiFi.status() == WL_CONNECTED) {
    Serial.printf("[wifi] up, ip %s rssi %d dBm\n", WiFi.localIP().toString().c_str(), WiFi.RSSI());
  } else {
    Serial.println(F("[wifi] failed — will retry, readings stay buffered"));
  }
}

// ---------------------------------------------------------------------------
static size_t buildReading(char *out, size_t outLen) {
  JsonDocument doc; // ArduinoJson v7
  doc["deviceId"] = BLOB_DEVICE_ID;

  // The bridge stamps freshness from `ts`, so it must be real epoch milliseconds, not
  // millis(). If NTP has not synced we send millis() anyway and the bridge will report
  // the reading as stale — which is the correct outcome, and points you at NTP rather
  // than letting a wrong timestamp through silently.
  const time_t epoch = time(nullptr);
  const bool synced = epoch > 1700000000;
  doc["ts"] = synced ? (uint64_t)epoch * 1000ULL : (uint32_t)millis();
  doc["timeSynced"] = synced;
  doc["fw"] = BLOB_FW_VERSION;

  if (bmeOk) {
    doc["tempC"] = serialized(String(bme.readTemperature(), 2));
    doc["humidityPct"] = serialized(String(bme.readHumidity(), 1));
    doc["pressureHpa"] = serialized(String(bme.readPressure() / 100.0f, 1));
  }
  if (luxOk) {
    doc["lux"] = serialized(String(lightMeter.readLightLevel(), 0));
  }
  if (imuOk) {
    float ax, ay, az, gx, gy, gz;
    if (imuRead(ax, ay, az, gx, gy, gz)) {
      doc["ax"] = serialized(String(ax, 3));
      doc["ay"] = serialized(String(ay, 3));
      doc["az"] = serialized(String(az, 3));
      doc["gx"] = serialized(String(gx, 1));
      doc["gy"] = serialized(String(gy, 1));
      doc["gz"] = serialized(String(gz, 1));
    }
  }
  doc["rssiDbm"] = WiFi.RSSI();
  return serializeJson(doc, out, outLen);
}

static bool postReading(const char *json) {
  if (WiFi.status() != WL_CONNECTED) return false;
  HTTPClient http;
  char url[160];
  snprintf(url, sizeof(url), "http://%s:%d%s", BLOB_HOST, BLOB_PORT, BLOB_PATH);
  http.begin(url);
  http.setTimeout(4000);
  http.addHeader("Content-Type", "application/json");
  if (strlen(BLOB_NODE_TOKEN) > 0) http.addHeader("x-node-token", BLOB_NODE_TOKEN);
  const int code = http.POST((uint8_t *)json, strlen(json));
  const String body = http.getString();
  http.end();
  if (code >= 200 && code < 300) return true;
  Serial.printf("[post] HTTP %d %s\n", code, body.c_str());
  return false;
}

static void bufferReading(const char *json) {
  strncpy(ring[ringHead].json, json, sizeof(ring[ringHead].json) - 1);
  ring[ringHead].json[sizeof(ring[ringHead].json) - 1] = '\0';
  ring[ringHead].at = millis();
  ringHead = (ringHead + 1) % RING;
  if (ringCount < RING) ringCount++;
}

static void flushRing() {
  if (!ringCount || WiFi.status() != WL_CONNECTED) return;
  const uint8_t start = (uint8_t)((ringHead + RING - ringCount) % RING);
  uint8_t sent = 0;
  for (uint8_t i = 0; i < ringCount; i++) {
    const uint8_t idx = (start + i) % RING;
    if (postReading(ring[idx].json)) sent++;
  }
  Serial.printf("[post] flushed %u/%u buffered readings\n", sent, ringCount);
  if (sent == ringCount) ringCount = 0;
}

// ---------------------------------------------------------------------------

void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println();
  Serial.printf("\nSovereign Blob sensor node %s\n", BLOB_FW_VERSION);

  Wire.begin(I2C_SDA, I2C_SCL);
  delay(80);

  bmeOk = bme.begin(0x76) || bme.begin(0x77);
  if (!bmeOk) Serial.println(F("[bme280] not found at 0x76/0x77"));
  if (bmeOk) {
    bme.setSampling(Adafruit_BME280::MODE_FORCED,
                    Adafruit_BME280::SAMPLING_X1,
                    Adafruit_BME280::SAMPLING_X1,
                    Adafruit_BME280::SAMPLING_X1,
                    Adafruit_BME280::FILTER_OFF);
  }

  luxOk = lightMeter.begin(BH1750::CONTINUOUS_HIGH_RES_MODE);
  if (!luxOk) Serial.println(F("[bh1750] not found at 0x23"));

  imuOk = imuInit();
  if (!imuOk) Serial.println(F("[mpu6050] not found or unrecognised"));

  if (!bmeOk && !luxOk && !imuOk) {
    Serial.println(F("[i2c] no sensors detected — check wiring and pull-ups"));
    scanI2C();
  }

  connectWiFi();
  // Real timestamps matter: the bridge rejects stale readings, and the log is only
  // useful if it lines up with wall-clock time.
  configTime(0, 0, "pool.ntp.org", "time.nist.gov");
  Serial.print(F("[ntp] syncing"));
  for (uint8_t i = 0; i < 20 && time(nullptr) < 1700000000; i++) {
    delay(500);
    Serial.print('.');
  }
  Serial.printf(" %s\n", time(nullptr) > 1700000000 ? "ok" : "not synced (readings will look stale)");

  lastSample = 0;
}

void loop() {
  const uint32_t now = millis();
  if (now - lastSample < (uint32_t)SAMPLE_INTERVAL_S * 1000UL) {
    delay(50);
    return;
  }
  lastSample = now;

  char json[512];
  const size_t n = buildReading(json, sizeof(json));
  if (!n) {
    Serial.println(F("[build] empty reading"));
    return;
  }

  if (WiFi.status() != WL_CONNECTED) connectWiFi();

  if (postReading(json)) {
    // A successful live post is the moment to drain anything buffered.
    if (ringCount) flushRing();
  } else {
    bufferReading(json);
    Serial.printf("[post] failed, buffered (%u held)\n", ringCount);
  }

  Serial.println(json);
}
