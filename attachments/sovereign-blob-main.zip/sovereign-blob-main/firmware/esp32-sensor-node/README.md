# ESP32 sensor node

Posts one JSON reading every 5 seconds to the local bridge's `POST /api/telemetry`.

## What it measures, and what that is actually used for

| Sensor | Bus address | Reading | Used for |
|---|---|---|---|
| BME280 | I2C 0x76 / 0x77 | temperature, humidity, pressure | environment advisories: whether the room is inside the band where the chosen timber is dimensionally stable, and whether finishes will cure |
| BH1750 | I2C 0x23 | ambient light (lux) | finish advisory (gloss shows defects), and whether a camera-based surface scan has enough light |
| MPU-6050 | I2C 0x68 | acceleration, rotation rate | capture orientation check (is the phone flat to the wall) and a vibration warning that tells you a depth scan taken now will be noisy |

The node holds no design data. It cannot fail in a way that corrupts a design, which is
the point of keeping it dumb.

## Wiring

```
ESP32          BME280    BH1750    MPU-6050
GPIO21 (SDA) ── SDA  ──── SDA  ──── SDA
GPIO22 (SCL) ── SCL  ──── SCL  ──── SCL
3V3         ── VCC  ──── VCC  ──── VCC
GND         ── GND  ──── GND  ──── GND
```

All three parts are 3.3 V I2C with different addresses, so they share one bus with no
multiplexer. If your MPU-6050 breakout has an AD0 pin pulled high it moves to 0x69 and
the firmware will not find it at 0x68 — check the serial log, which prints the I2C scan.

## Build and flash

```bash
cd firmware/esp32-sensor-node
cp include/secrets.example.h include/secrets.h   # then edit it
pio run -t upload
pio device monitor -b 115200
```

Set `BLOB_HOST` to the machine running `npm start` in the project root. On the bridge,
set `BLOB_NODE_TOKEN` to the same value as in `secrets.h` once you bind the bridge to
anything other than `127.0.0.1`.

## Verify it is working

The bridge prints every accepted reading to `output/telemetry-history.jsonl`, and the
UI's Sensor panel updates live over SSE. From a shell:

```bash
node bin/blob.mjs --sensor '{"deviceId":"manual","ts":'$(date +%s000)',"tempC":21,"humidityPct":48,"lux":340}'
```

That path runs the same decoder the node's readings go through, so anything wrong with
the payload shape shows up without flashing hardware.

## Status

**Not flashed on hardware.** The register addresses, scales and library calls come from
the respective datasheets and library docs; the code has been written and reviewed but
not run on a board. Expect to confirm the WHO_AM_I value and the I2C addresses first —
`scanI2C()` and the startup log are there to make that a 30-second job rather than a
debugging session.

## Known limitations

- No deep sleep. At 5 s intervals an ESP32 draws tens of milliamps; for a battery build,
  raise `SAMPLE_INTERVAL_S`, enable modem sleep, or wake on a timer instead of looping.
- `batteryV` is in the payload contract but not populated — it needs a divider on an ADC
  pin wired to your specific power path.
- NTP sync failure is reported rather than worked around: an unsynced node sends
  `millis()` and the bridge marks every reading stale.
