// Copy this file to secrets.h and fill it in. secrets.h is gitignored.
//
// The bridge host is whatever machine runs `npm start`, with the port the bridge is
// listening on (default 8787). Nothing here leaves your local network.

#pragma once

#define WIFI_SSID       "your-wifi-ssid"
#define WIFI_PASSWORD   "your-wifi-password"

// IP or hostname of the machine running bridge/server.mjs
#define BLOB_HOST       "192.168.1.50"
#define BLOB_PORT       8787
#define BLOB_PATH       "/api/telemetry"

// Must match BLOB_NODE_TOKEN on the bridge, or be left empty if the bridge has no
// token set. A token is recommended as soon as you bind the bridge to anything other
// than 127.0.0.1.
#define BLOB_NODE_TOKEN ""

#define BLOB_DEVICE_ID  "blob-node-01"

// Seconds between readings. The bridge treats anything older than 60 s as stale.
#define SAMPLE_INTERVAL_S 5

// I2C pins (ESP32 default bus is 21/22; change for your board).
#define I2C_SDA 21
#define I2C_SCL 22
