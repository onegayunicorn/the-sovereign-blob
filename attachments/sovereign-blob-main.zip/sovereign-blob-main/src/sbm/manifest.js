/**
 * SBM v0.2 builder — the universal internal language (spec section 11).
 *
 * Every export derives from the manifest, never from UI state, so an export cannot contain
 * something the manifest does not. That is the property that makes "explainable" testable:
 * if the PDF says 21 mm, the manifest says 21 mm, and the structural check was run at 21 mm.
 *
 * Two things are computed rather than asserted:
 *   - `reality.status` comes from the spec's bands, EXCEPT that a violated LOCKED anchor
 *     forces BLOCKED (spec section 10). A locked anchor is a hard gate; a band is a score.
 *   - `reality.confidence` is derived from information completeness, itemised in
 *     `confidenceBasis`. It is not a feeling.
 */

import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { validateDef, loadSchemas } from '../../contracts/validate.mjs';
import { statusForScore, stateForStatus, colourForState } from '../proto/state.js';
import { defaultAnchors, validateAnchors } from '../reality/anchors.js';

const ENGINE_VERSION = '0.3.0-alpha';

const slug = (s) =>
  String(s || 'project')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '') || 'project';

const round = (n, d = 2) => Math.round(n * 10 ** d) / 10 ** d;

/**
 * A part is either a vertical member (sides, back) or a horizontal one (shelves, rails).
 * The spec's component examples use width = horizontal extent and height = vertical extent,
 * so the mapping flips between the two. Getting this backwards would produce a manifest
 * whose "300 x 1800" side panel is a shelf, and a workshop cuts the wrong thing.
 */
function toComponent(part) {
  const vertical = /^(side|back)/.test(part.id);
  return {
    componentId: `comp-${part.id}`,
    type: 'panel',
    width: vertical ? part.widthMm : part.lengthMm,
    height: vertical ? part.lengthMm : part.widthMm,
    thickness: part.thicknessMm,
    quantity: part.qty,
    grainDirection: part.grainSensitive ? 'along-length' : 'any',
    edgesBanded: part.edgesBanded ?? []
  };
}

function buildConfidence({ cutList, cost, roomScan, intent }) {
  const basis = [];
  let c = 0.95;
  const dock = (amount, why) => {
    c -= amount;
    basis.push(`-${amount}: ${why}`);
  };
  if (!cutList.material.verified) dock(0.15, 'elastic modulus is a handbook value, not a supplier datasheet');
  if (cost.unpriced.length) dock(0.1, `${cost.unpriced.length} cost line(s) have no verified price`);
  if (cost.confidence?.anyBulkTierPriced) dock(0.1, 'a material line is priced at a bulk tier this build cannot buy at');
  if (!roomScan) dock(0.1, 'no wall scan: spatial values are the spoken dimensions, not measurements');
  const defaulted = Object.values(intent.slots ?? {}).filter((s) => s.source === 'default').length;
  if (defaulted) dock(Math.min(0.15, defaulted * 0.03), `${defaulted} intent slot(s) came from defaults, not from the user`);
  return { confidence: round(Math.max(0.2, c), 2), confidenceBasis: basis };
}

function buildChecks({ cutList, cost, spec }) {
  const def = cutList.checks.shelfDeflection;
  const structural = def.pass && cutList.checks.racking.pass ? 'PASS' : 'FAIL';

  const tip = cutList.checks.tipOver;
  const physical = tip.anchoredRequired && !spec.anchored ? 'FAIL' : 'PASS';

  let economic = 'UNKNOWN';
  if (spec.budget && cost.total) economic = cost.total <= spec.budget ? 'PASS' : 'FAIL';
  else if (!cost.unpriced.length && !cost.confidence?.anyBulkTierPriced) economic = 'PASS';

  const unplaced = cutList.nesting.carcass.unplaced?.length ?? 0;
  const yieldPct = cutList.nesting.carcass.overallUtilisation ?? 0;
  const manufacturing = unplaced > 0 ? 'FAIL' : yieldPct < 0.3 ? 'CAUTION' : 'PASS';

  return { structural, physical, economic, manufacturing };
}

function buildRealityDecisions({ cutList, cost, spec, overrides }) {
  const out = [];
  const at = new Date().toISOString();
  const def = cutList.checks.shelfDeflection;

  if (overrides?.thicknessMm && Number(overrides.thicknessMm) !== 18) {
    out.push({
      timestamp: at,
      decision: `Material thickness set to ${spec.thicknessMm} mm`,
      reason: `Requested override. At ${spec.thicknessMm} mm the predicted long-term sag is ${def.longTermMm} mm against a ${def.limitMm} mm allowance (${Math.round(def.utilisation * 100)}% of limit) — ${def.pass ? 'within tolerance' : 'still failing'}.`,
      trigger: 'Reality Engine — structural check'
    });
  } else {
    out.push({
      timestamp: at,
      decision: `Thickness ${spec.thicknessMm} mm ${def.pass ? 'accepted' : 'rejected'}`,
      reason: `Predicted long-term sag ${def.longTermMm} mm over a ${cutList.spanMm} mm span carrying ${spec.loadPerShelfKg} kg per shelf, against a ${def.limitMm} mm allowance (${Math.round(def.utilisation * 100)}% of limit).`,
      trigger: 'Reality Engine — structural check'
    });
  }

  if (cutList.remedy && !def.pass) {
    const r = cutList.remedy;
    const options = [
      r.thickerPasses ? `${r.thickerSheetMm} mm stock (${r.thickerDeflectionMm} mm)` : null,
      r.midRailAtHalfSpanPasses ? `a mid-rail at half span (${r.midRailDeflectionMm} mm)` : null,
      r.deeperShelfPasses ? `a ${r.deeperShelfMm} mm deep shelf (${r.deeperShelfDeflectionMm} mm)` : null
    ].filter(Boolean);
    if (options.length) {
      out.push({
        timestamp: at,
        decision: 'Correction recommended',
        reason: `Options that pass: ${options.join('; ')}.`,
        trigger: 'Reality Engine — remedy search'
      });
    }
  }

  if (cost.unpriced?.length) {
    out.push({
      timestamp: at,
      decision: `${cost.unpriced.length} cost line(s) left unpriced`,
      reason: `No verified price exists for: ${cost.unpriced.map((u) => u.label).join(', ')}. Recorded as unknown rather than estimated, so the total is a lower bound.`,
      trigger: 'Economic Engine — price book lookup'
    });
  }

  return out;
}

/**
 * Build the manifest.
 *
 * @param {object} args
 * @param {object} args.project   { id, name, created, version }
 * @param {object} args.result    a runPipeline result
 * @param {object} [args.roomScan] RoomModel from a wall scan, if one was performed
 * @param {object} [args.overrides] spec overrides that were applied
 * @param {object} [args.physicalValidation] measured results from a built object
 */
export function buildSBM({ project, result, roomScan = null, overrides = {}, physicalValidation = null, anchors = null, variants = null }) {
  const cutList = result.cutList;
  const cost = result.cost;
  const spec = cutList.spec;
  const intent = result.intent;

  const anchorSet = anchors
    ? anchors
    : defaultAnchors({ spec: { ...spec, wallMounted: true }, cutList, cost, room: roomScan });

  const anchorResult = validateAnchors(anchorSet, { spec, cutList, cost, room: roomScan });
  const checks = buildChecks({ cutList, cost, spec });

  // Score and status. A band is a score; a locked anchor is a gate.
  const bandStatus = statusForScore(result.reality.score);
  const status = anchorResult.blocking.length ? 'BLOCKED' : bandStatus;

  const { confidence, confidenceBasis } = buildConfidence({ cutList, cost, roomScan, intent });

  const warnings = [];
  const blockers = [];
  for (const v of anchorResult.violations) {
    const line = `${v.name}: ${v.message} → ${v.recommendation}`;
    if (v.blocking) blockers.push(line);
    else warnings.push(line);
  }
  if (checks.economic === 'UNKNOWN') warnings.push('Cost is not fully known: at least one line has no verified price, so the total is a lower bound.');
  if (!cutList.material.verified) warnings.push('Elastic modulus is a typical published value, not a supplier datasheet. The structural verdict is an estimate until it is replaced.');

  const recommendations = [];

  // Anchoring first, because it is a safety gate rather than a design preference, and because
  // it is what moves this design out of CAUTION. The numbers come from the design's own checks.
  const tip = cutList.checks.tipOver;
  if (tip.anchoredRequired && !spec.anchored) {
    recommendations.push(
      `Wall anchoring is REQUIRED: tip-over margin ${tip.margin} is below 1.0, so the unit can be pulled over. ` +
        (tip.rearDropMm > 0
          ? `The ${tip.rearDropMm} mm rear drop (${tip.tiltDeg} deg lean, centre of mass ${tip.comShiftMm} mm rearward) lifts the margin from ${tip.marginWithoutRearDrop} to ${tip.margin} — real, but nowhere near enough on its own. Fix it to the wall.`
          : 'Fix it to the wall.')
    );
  }

  // The Dream State's best variant, when one was computed. Only ever reported when the caller
  // supplied it, so the manifest never states a variant score it did not actually compute.
  if (variants?.recommended) {
    const rec = variants.recommended;
    const change = Object.entries(rec.change ?? {})
      .map(([k, v]) => `${k}=${v}`)
      .join(', ');
    recommendations.push(
      `RECOMMENDED: ${change || 'no change'} — score ${rec.score} (${rec.band}) against this design's ${Math.round(result.reality.score)} (${bandStatus}), out of ${variants.explored} variants explored and checked.`
    );
  }

  if (!cutList.checks.shelfDeflection.pass && cutList.remedy) {
    const r = cutList.remedy;
    if (r.thickerPasses) recommendations.push(`${r.thickerSheetMm} mm material passes at ${r.thickerDeflectionMm} mm`);
    if (r.midRailAtHalfSpanPasses) recommendations.push(`a mid-rail at half span passes at ${r.midRailDeflectionMm} mm`);
  }
  if (checks.economic === 'UNKNOWN') recommendations.push('Obtain a real fabricator quote to turn the economic check from UNKNOWN into PASS or FAIL.');

  const spatial = roomScan
    ? {
        roomWidth: roomScan.roomWidthMm ?? roomScan.wallWidthMm ?? spec.widthMm,
        roomHeight: roomScan.roomHeightMm ?? roomScan.wallHeightMm ?? spec.heightMm,
        wallWidth: roomScan.wallWidthMm ?? spec.widthMm,
        wallHeight: roomScan.wallHeightMm ?? spec.heightMm,
        depth: roomScan.depthMm ?? spec.depthMm,
        confidence: roomScan.confidence ?? 0.5,
        source: roomScan.source ?? 'wall-scan',
        obstructions: roomScan.obstructions ?? []
      }
    : {
        roomWidth: spec.widthMm,
        roomHeight: spec.heightMm,
        wallWidth: spec.widthMm,
        wallHeight: spec.heightMm,
        depth: spec.depthMm,
        confidence: 0.0,
        source: 'assumed-from-intent',
        obstructions: []
      };

  const materialLines = cost.lines.filter((l) => l.role === 'material');
  const hardwareLines = cost.lines.filter((l) => l.role !== 'material');
  const carcassSheetLine = materialLines.find((l) => /sheet/.test(l.key ?? ''));

  const assembly = result.assembly?.steps?.length
    ? result.assembly.steps
    : // buildAssemblySequence is not stored on the pipeline result by every caller
      [];

  const tools = [...new Set(assembly.flatMap((s) => s.tools ?? []))].sort();

  const fileBase = slug(project.name);
  const children = cutList.parts.map(toComponent);

  const sbm = {
    sbmVersion: '0.2',
    project: {
      id: project.id,
      name: project.name,
      created: project.created ?? new Date().toISOString(),
      version: project.version ?? 1,
      objectType: intent.kind,
      region: cost.region?.id ?? null
    },
    intent: {
      goal: intent.kind,
      location: spec.anchored ? 'wall' : 'floor',
      priority: Object.entries(intent.priorities ?? {}).sort((a, b) => b[1] - a[1])[0]?.[0] ?? 'storage',
      budget: spec.budget ?? null,
      constraints: intent.constraints ?? {},
      transcript: result.utterance,
      confidence: round(intent.confidence ?? 0.5, 2)
    },
    spatial,
    anchors: anchorSet.map((a) => ({ ...a })),
    reality: {
      score: Math.round(result.reality.score),
      status,
      confidence,
      warnings,
      blockers,
      recommendations,
      checks,
      dimensions: Object.entries(result.reality.dimensions ?? {}).map(([name, value]) => ({ name, value })),
      bandStatus,
      state: stateForStatus(status),
      colour: colourForState(stateForStatus(status)),
      confidenceBasis
    },
    materials: [
      {
        materialId: `mat-${cutList.material.id}-${spec.thicknessMm}`,
        name: cutList.material.label,
        thickness: spec.thicknessMm,
        density: cutList.material.densityKgM3,
        elasticModulus: cutList.material.E,
        sheetCost: carcassSheetLine?.unitPrice ?? null,
        sheetsRequired: cutList.nesting.carcassSheetCount,
        provenanceVerified: Boolean(cutList.material.verified)
      }
    ],
    components: children,
    assembly: assembly.map((s) => ({
      step: s.step,
      description: s.title ? `${s.title} — ${s.detail}` : s.detail,
      components: s.step === 1 ? children.map((c) => c.componentId) : ['carcass'],
      reason: s.reason ?? null,
      tools: s.tools ?? []
    })),
    costing: {
      materialCost: round(materialLines.reduce((a, l) => a + l.lineTotal, 0)),
      fabricationCost: null,
      hardwareCost: round(hardwareLines.reduce((a, l) => a + l.lineTotal, 0)),
      totalCost: round(cost.total),
      currency: cost.currency,
      budgetStatus: !spec.budget ? 'UNKNOWN' : cost.total <= spec.budget ? 'WITHIN' : 'OVER',
      tax: cost.tax ?? null,
      unpricedLines: (cost.unpriced ?? []).map((u) => u.label)
    },
    fabrication: {
      dxfReady: true,
      cutList: children.map((c) => ({
        label: cutList.parts.find((p) => `comp-${p.id}` === c.componentId)?.label ?? c.componentId,
        qty: c.quantity,
        width: c.width,
        height: c.height,
        thickness: c.thickness
      })),
      toolsRequired: tools,
      // The rear drop is a machining instruction, so it travels with the fabrication data
      // rather than living only in prose the builder has to remember.
      rearDrop: {
        mm: tip.rearDropMm ?? 0,
        tiltDeg: tip.tiltDeg ?? 0,
        comShiftMm: tip.comShiftMm ?? 0,
        tipOverMarginWithout: tip.marginWithoutRearDrop ?? null,
        tipOverMarginWith: tip.margin ?? null,
        instruction:
          tip.rearDropMm > 0
            ? `Relieve the bottom rear corner of each side panel by ${tip.rearDropMm} mm so the unit leans back ${tip.tiltDeg} deg into the wall.`
            : 'No rear drop specified; the unit stands square.'
      },
      sheetLayout: `${cutList.nesting.carcassSheetCount} sheet(s) ${spec.thicknessMm} mm (${cutList.nesting.carcass.sheet.lengthMm}x${cutList.nesting.carcass.sheet.widthMm})${cutList.nesting.backSheetCount ? ` + ${cutList.nesting.backSheetCount} sheet 6 mm` : ''}`,
      sheetMm: cutList.nesting.carcass.sheet
    },
    exports: {
      pdf: `${fileBase}.pdf`,
      dxf: `${fileBase}.dxf`,
      replay: `${fileBase}-replay.json`,
      sbm: `${fileBase}.sbm.json`
    },
    audit: {
      voiceInput: result.utterance ?? null,
      intentChanges: Object.entries(intent.slots ?? {}).map(([slot, s]) => ({
        slot,
        value: s.value,
        source: s.source
      })),
      realityDecisions: buildRealityDecisions({ cutList, cost, spec, overrides }),
      anchorViolations: anchorResult.violations.map((v) => ({
        anchorId: v.anchorId,
        name: v.name,
        locked: v.locked,
        message: v.message,
        recommendation: v.recommendation
      })),
      physicalValidation: physicalValidation ?? null,
      engineVersion: ENGINE_VERSION
    }
  };

  return sbm;
}

/**
 * Validation before export: schema + reality + anchor, all three must pass (spec section 11).
 * Returns the report rather than throwing, because the caller needs to show the user which
 * of the three gates failed.
 */
export function validateSBM(sbm, { cutList, cost, spec, room } = {}) {
  const schema = validateDef(sbm, 'sbmV02', loadSchemas());
  const errors = schema.errors.map((e) => `${e.path}: ${e.message}`);

  const realityValid = sbm.reality.status !== 'BLOCKED';

  let anchorsValid = true;
  if (cutList && spec) {
    const anchorResult = validateAnchors(sbm.anchors ?? [], { spec, cutList, cost, room });
    anchorsValid = anchorResult.valid;
    for (const v of anchorResult.blocking) errors.push(`anchor ${v.anchorId}: ${v.message}`);
  }

  return {
    schemaValid: schema.valid,
    realityValid,
    anchorsValid,
    allPassed: schema.valid && realityValid && anchorsValid,
    errors
  };
}

export { ENGINE_VERSION };
