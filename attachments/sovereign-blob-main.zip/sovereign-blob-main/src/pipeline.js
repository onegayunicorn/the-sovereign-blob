/**
 * Pipeline — one continuous run from an utterance to a build package.
 *
 * runPipeline("build me a bookshelf 1800 tall 900 wide under $80")
 *
 *   intent  ->  form  ->  geometry  ->  material  ->  structure  ->  economics  ->  output
 *
 * Every stage appends a Reality Engine reading, so the score is not a single verdict at
 * the end but a trace of how the design got there. Stage colour is what the blob shows.
 */

import { parseIntent, applyModifications } from './intent/core.js';
import { buildCutList, DEFAULT_SPEC, normaliseSpec } from './engine/cutlist.js';
import { costBuild } from './engine/cost.js';
import { resolveRegion, regionSheet } from './engine/regions.js';
import { buildAssemblySequence } from './engine/assembly.js';
import { alternativesFor, resolveMaterial } from './engine/materials.js';
import { scoreReality, scoreFormStage, exploreVariants, BANDS } from './reality/engine.js';
import { validateRoom, accessCheck } from './sensors/room.js';
import { rectilinearPlan, elevations, amorphous, shapeForTemplate, morph } from './blob/shapes.js';
import { describeSurface } from './blob/field.js';
import { buildSheetGoodsRfq, buildCncQuoteRequest, procurementRoute } from './vendor/vendors.js';

/** Map parsed intent onto an engineering spec. */
export function specFromIntent(intent, overrides = {}) {
  const s = intent.slots;
  let spec = {
    ...DEFAULT_SPEC,
    kind: intent.kind,
    widthMm: s.widthMm.value,
    heightMm: s.heightMm.value,
    depthMm: s.depthMm.value,
    shelves: s.shelves.value,
    material: s.material.value,
    anchored: s.anchored.value,
    knockdown: s.knockdown.value,
    loadPerShelfKg: s.loadPerShelfKg.value,
    budget: s.budget.value ?? null,
    ...overrides
  };
  if (intent.modifications?.length) {
    const { spec: modified, applied } = applyModifications(spec, intent.modifications);
    spec = modified;
    spec.appliedModifications = applied;
  }
  return normaliseSpec(spec);
}

export function runPipeline(utterance, options = {}) {
  const stages = [];
  const stage = (name, score, colour, note, extra = {}) =>
    stages.push({ stage: name, score, band: score >= 80 ? 'green' : score >= 60 ? 'amber' : 'red', colour, note, ...extra });

  // ---- 0. Supply mode ------------------------------------------------------
  // A region profile pins the nesting sheet size AND the price source, so switching from
  // container-scale supply (Mode B) to local fabrication (Mode A) is configuration rather
  // than a fork. It is resolved first so nesting, cost and exports cannot disagree.
  const region = resolveRegion(options.region);
  const opts = region ? { ...options, region, sheet: options.sheet || regionSheet(region) } : options;

  // ---- 1. Intent -----------------------------------------------------------
  const intent = parseIntent(utterance, options);
  stage(
    'intent',
    Math.round(intent.confidence * 100),
    intent.confidence >= 0.6 ? BANDS.green.colour : intent.confidence >= 0.35 ? BANDS.amber.colour : BANDS.red.colour,
    `Parsed "${intent.kind}". ${Math.round(intent.confidence * 100)}% of slots came from you; the rest are defaults that are listed as open questions.`,
    { openQuestions: intent.openQuestions.length }
  );

  // ---- 2. Form -------------------------------------------------------------
  let spec = specFromIntent(intent, options.specOverrides || {});
  const roomCheck = options.room ? validateRoom(options.room, spec, { parts: null }) : null;
  const form = scoreFormStage({ spec, roomCheck });
  stage('form', form.score, form.colour, form.issues.length ? form.issues.join(' ') : 'Proportions and fit are plausible.', { issues: form.issues });

  // ---- 3. Geometry + structure --------------------------------------------
  let cutList = buildCutList(spec, opts);
  const def = cutList.checks.shelfDeflection;
  stage(
    'geometry',
    def.pass ? Math.round(100 - 25 * def.utilisation) : Math.max(0, Math.round(60 - 60 * (def.utilisation - 1))),
    def.pass ? BANDS.green.colour : BANDS.red.colour,
    `Shelf span ${cutList.spanMm} mm. Predicted long-term sag ${def.longTermMm} mm against a ${def.limitMm} mm allowance.`,
    { spanMm: cutList.spanMm, longTermMm: def.longTermMm, limitMm: def.limitMm }
  );

  // ---- 4. Material ---------------------------------------------------------
  const alternatives = alternativesFor(cutList.spec.material);
  const matChoice = {
    selected: cutList.material,
    why: cutList.material.verified
      ? 'Selected material matches the request and its stiffness data is verified.'
      : 'Default sheet material for furniture-grade case goods: stiff for its mass, takes fasteners well in the face, and widely available in 18 mm.',
    alternatives: alternatives.slice(0, 3),
    note: 'Alternatives are ranked by stiffness-to-mass ratio using typical published moduli; no cost claim is made here — cost comes from the vendor price book.'
  };
  stage('material', def.pass ? 90 : 70, def.pass ? BANDS.green.colour : BANDS.amber.colour, `${matChoice.selected.label}. ${matChoice.why}`);

  // ---- 5. Economics --------------------------------------------------------
  const cost = costBuild(cutList, opts);
  stage(
    'economics',
    cost.unpriced.length === 0 && !cost.confidence.anyBulkTierPriced ? 95 : cost.unpriced.length <= 1 ? 72 : 60,
    cost.unpriced.length === 0 ? BANDS.green.colour : BANDS.amber.colour,
    `Priced subtotal ${cost.total} ${cost.currency}${cost.unpriced.length ? `, ${cost.unpriced.length} line(s) have no verified price` : ''}. Price book as of ${cost.asOf}.`,
    { total: cost.total, currency: cost.currency, unpriced: cost.unpriced.length }
  );

  // ---- 6. Output -----------------------------------------------------------
  const reality = scoreReality({ spec: cutList.spec, cutList, cost });
  const assembly = buildAssemblySequence(cutList);
  const plan = rectilinearPlan(cutList);
  const elev = elevations(cutList);
  // Attach the settled plan to the cut list so exporters (SVG elevation, DXF, package)
  // can render the same geometry the UI shows, with no second source of truth.
  cutList.plan = plan;

  stage(
    'output',
    reality.score,
    reality.colour,
    reality.issues.length ? reality.issues.join(' ') : 'No blocking issues. Package is buildable as drawn.',
    { status: reality.status }
  );

  // ---- Blob surface state --------------------------------------------------
  const target = shapeForTemplate(intent.template, cutList.spec);
  const start = amorphous(hash(utterance) || 1);
  const blob = {
    start: describeSurface(start.nodes, { res: 72 }),
    target: describeSurface(target.nodes, { res: 72 }),
    mid: describeSurface(morph(start, target, 0.5).nodes, { res: 72 }),
    settled: plan,
    colour: reality.colour,
    band: reality.band
  };

  // ---- Vendor actions ------------------------------------------------------
  const sheetKey = `sheet-${cutList.spec.thicknessMm}mm-birch-plywood-2440x1220`;
  const rfq = buildSheetGoodsRfq(cutList, options);
  const cnc = buildCncQuoteRequest(cutList, options);
  const routes = [
    procurementRoute(sheetKey),
    procurementRoute('sheet-6mm-back-panel'),
    procurementRoute(cutList.joinery.id === 'pocket-screw' ? 'pocket-screws-32mm-500ct' : 'confirmat-screws-7x50'),
    procurementRoute('cut-to-size-cnc-service')
  ];

  return {
    utterance,
    intent,
    spec: cutList.spec,
    stages,
    form,
    roomCheck,
    cutList,
    cost,
    assembly,
    reality,
    materialDecision: matChoice,
    plan,
    elevations: elev,
    blob,
    vendor: { rfq, cnc, routes },
    alternatives,
    openQuestions: intent.openQuestions,
    files: {
      'cut-list.csv': null,
      'nested-layout.dxf': null,
      'nested-layout.svg': null,
      'package.json': null
    }
  };
}

/**
 * Dream State entry point: pause, then explore the neighbourhood of the current design.
 */
export function dreamState(utterance, options = {}) {
  const base = runPipeline(utterance, options);
  // Variants must be scored under the same supply mode as the base design, or the
  // Dream State would be comparing apples priced in two different currencies.
  const region = resolveRegion(options.region);
  const opts = region ? { ...options, region, sheet: options.sheet || regionSheet(region) } : options;
  return exploreVariants(
    (spec) => {
      const cutList = buildCutList(spec, opts);
      const cost = costBuild(cutList, opts);
      return { cutList, cost };
    },
    base.cutList.spec,
    (built) => scoreReality({ spec: built.cutList.spec, cutList: built.cutList, cost: built.cost }),
    options
  );
}

function hash(str) {
  let h = 2166136261;
  for (let i = 0; i < String(str).length; i++) {
    h ^= String(str).charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
