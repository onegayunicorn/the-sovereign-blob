/**
 * ProtoMatter state and colour.
 *
 * The spec's core claim is that the blob colour IS the reality score made visible, with no
 * separate indicator. That only holds if the colour and the status are derived from the
 * same number by the same function — so both come from config/proto-states.json, which is
 * also mirrored by the Kotlin enum. tests/contracts.test.mjs checks the Kotlin source text
 * against this file, so the two renderers cannot disagree.
 *
 * Scoring bands are spec section 9: 0-49 BLOCKED, 50-74 CAUTION, 75-100 READY.
 */

import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const CONFIG = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'config', 'proto-states.json');

let cache = null;
export function loadProtoStates(path = CONFIG) {
  if (path === CONFIG && cache) return cache;
  const doc = JSON.parse(readFileSync(path, 'utf8'));
  if (path === CONFIG) cache = doc;
  return doc;
}

/** Spec section 9. Returns BLOCKED | CAUTION | READY. */
export function statusForScore(score) {
  const bands = loadProtoStates().bands;
  const s = Math.max(0, Math.min(100, Math.round(score)));
  if (s <= bands.BLOCKED.max) return 'BLOCKED';
  if (s <= bands.CAUTION.max) return 'CAUTION';
  return 'READY';
}

/** Status -> ProtoMatter state. CAUTION is shown as Validating: the engine is still working
 *  the problem, which is exactly what an amber blob means. */
export function stateForStatus(status) {
  const map = { BLOCKED: 'BLOCKED', CAUTION: 'VALIDATING', READY: 'READY' };
  return map[status] ?? 'IDLE';
}

export function stateForScore(score) {
  return stateForStatus(statusForScore(score));
}

export function colourForState(state) {
  const s = loadProtoStates().states[state];
  if (!s) throw new Error(`unknown ProtoMatter state "${state}"`);
  return { state, name: s.label, colourName: s.colourName, hex: s.hex };
}

export function colourForScore(score) {
  return colourForState(stateForScore(score));
}

/** Full state table, for UI binding. */
export function stateTable() {
  return loadProtoStates().states;
}

/**
 * Boundary check: the bands must tile 0-100 with no gap and no overlap. A gap would mean a
 * score with no defined status, which in a UI means a blob with no colour.
 */
export function auditBands() {
  const b = loadProtoStates().bands;
  const spans = ['BLOCKED', 'CAUTION', 'READY'].map((k) => ({ k, ...b[k] }));
  const problems = [];
  if (spans[0].min !== 0) problems.push('lowest band does not start at 0');
  if (spans[spans.length - 1].max !== 100) problems.push('highest band does not end at 100');
  for (let i = 0; i < spans.length - 1; i++) {
    if (spans[i].max + 1 !== spans[i + 1].min) {
      problems.push(`gap or overlap between ${spans[i].k} and ${spans[i + 1].k}`);
    }
  }
  return { ok: problems.length === 0, problems, spans };
}
