/**
 * Sheet nesting — MaxRects packer (Best-Short-Side-Fit) with 90 degree rotation.
 *
 * Why a real packer instead of "area / 0.8": the sheet count drives the material
 * cost and the Reality Score, and naive area maths is wrong whenever a part is
 * longer than the sheet is wide. MaxRects is the standard free-rectangle heuristic;
 * it is deterministic, so the same design always produces the same sheet layout,
 * which is what you want in a cut list you are going to hand to a machine.
 *
 * The packer is NOT guillotine-constrained, so the layout may require a nested
 * cut path. That is fine for a CNC router or a laser; for a table saw, the exported
 * cut list should be re-sequenced by the operator. This is stated in the output.
 */

function overlaps(a, b) {
  return !(
    a.x + a.w <= b.x ||
    b.x + b.w <= a.x ||
    a.y + a.h <= b.y ||
    b.y + b.h <= a.y
  );
}

function splitFree(existing, used) {
  // MaxRects split: any free rect that intersects `used` is removed and replaced
  // by the (up to) four maximal sub-rectangles around the used area.
  const out = [];
  for (const f of existing) {
    if (!overlaps(f, used)) {
      out.push(f);
      continue;
    }
    if (used.x > f.x) out.push({ x: f.x, y: f.y, w: used.x - f.x, h: f.h });
    if (used.x + used.w < f.x + f.w) {
      out.push({ x: used.x + used.w, y: f.y, w: f.x + f.w - (used.x + used.w), h: f.h });
    }
    if (used.y > f.y) out.push({ x: f.x, y: f.y, w: f.w, h: used.y - f.y });
    if (used.y + used.h < f.y + f.h) {
      out.push({ x: f.x, y: used.y + used.h, w: f.w, h: f.y + f.h - (used.y + used.h) });
    }
  }
  // Prune rects fully contained in another (keeps the free list small and stable).
  const pruned = out.filter(
    (r, i) =>
      r.w > 0.001 &&
      r.h > 0.001 &&
      !out.some(
        (o, j) =>
          i !== j &&
          o.x <= r.x &&
          o.y <= r.y &&
          o.x + o.w >= r.x + r.w &&
          o.y + o.h >= r.y + r.h
      )
  );
  return pruned;
}

function tryFit(freeRects, w, h) {
  let best = null;
  for (const r of freeRects) {
    if (r.w + 0.001 >= w && r.h + 0.001 >= h) {
      const leftoverShort = Math.min(r.w - w, r.h - h);
      const leftoverLong = Math.max(r.w - w, r.h - h);
      const score = [leftoverShort, leftoverLong];
      if (
        !best ||
        score[0] < best.score[0] ||
        (score[0] === best.score[0] && score[1] < best.score[1])
      ) {
        best = { rect: r, w, h, score };
      }
    }
  }
  return best;
}

/**
 * Pack parts onto sheets.
 * @param {Array<{id:string,label:string,lengthMm:number,widthMm:number,qty:number,thicknessMm:number}>} parts
 * @param {{lengthMm:number,widthMm:number}} sheet
 * @param {{kerfMm?:number}} [options]
 */
export function packSheets(parts, sheet, options = {}) {
  const kerf = options.kerfMm ?? 0; // included in footprint when a saw is used
  const expanded = [];
  for (const p of parts) {
    const qty = p.qty ?? 1;
    for (let i = 0; i < qty; i++) {
      expanded.push({
        id: `${p.id}#${i + 1}`,
        label: p.label,
        thicknessMm: p.thicknessMm,
        w: p.lengthMm + kerf,
        h: p.widthMm + kerf,
        realLengthMm: p.lengthMm,
        realWidthMm: p.widthMm,
        grainSensitive: !!p.grainSensitive
      });
    }
  }
  // Largest area first is the classic BSSF input order.
  expanded.sort((a, b) => b.w * b.h - a.w * a.h);

  const sheets = [];
  const unplaced = [];

  for (const part of expanded) {
    let placed = false;
    for (const s of sheets) {
      const fit = attemptPlace(s, part);
      if (fit) {
        placed = true;
        break;
      }
    }
    if (!placed) {
      const s = { index: sheets.length + 1, freeRects: [{ x: 0, y: 0, w: sheet.lengthMm, h: sheet.widthMm }], placed: [] };
      sheets.push(s);
      if (!attemptPlace(s, part)) {
        unplaced.push(part);
      }
    }
  }

  const sheetArea = sheet.lengthMm * sheet.widthMm;
  const result = sheets.map((s) => {
    const usedArea = s.placed.reduce((sum, p) => sum + p.realLengthMm * p.realWidthMm, 0);
    return {
      index: s.index,
      parts: s.placed.map((p) => ({
        id: p.id,
        label: p.label,
        x: p.x,
        y: p.y,
        w: p.placedW,
        h: p.placedH,
        lengthMm: p.realLengthMm,
        widthMm: p.realWidthMm,
        rotated: p.rotated
      })),
      usedAreaMm2: Math.round(usedArea),
      utilisation: Number((usedArea / sheetArea).toFixed(3))
    };
  });

  const totalUsed = result.reduce((sum, s) => sum + s.usedAreaMm2, 0);
  return {
    sheet: { lengthMm: sheet.lengthMm, widthMm: sheet.widthMm },
    sheets: result,
    sheetCount: result.length,
    totalPartAreaMm2: totalUsed,
    overallUtilisation: Number((totalUsed / (sheetArea * Math.max(1, result.length))).toFixed(3)),
    unplaced
  };
}

function attemptPlace(sheetState, part) {
  const orientations = part.grainSensitive
    ? [[part.w, part.h]] // do not force a cross-grain rotation on grain-sensitive panels
    : [[part.w, part.h], [part.h, part.w]];
  let best = null;
  for (const [w, h] of orientations) {
    const fit = tryFit(sheetState.freeRects, w, h);
    if (fit && (!best || fit.score[0] < best.fit.score[0])) best = { fit, w, h };
  }
  if (!best) return false;
  const { rect } = best.fit;
  const placedRect = { x: rect.x, y: rect.y, w: best.w, h: best.h };
  sheetState.freeRects = splitFree(sheetState.freeRects, placedRect);
  sheetState.placed.push({
    ...part,
    x: rect.x,
    y: rect.y,
    placedW: best.w,
    placedH: best.h,
    rotated: best.w !== part.w
  });
  return true;
}

/**
 * Independent overlap audit — used by the test suite to prove the packer never
 * produces intersecting parts. Deliberately re-implemented rather than reusing
 * `overlaps` so a bug in one cannot hide a bug in the other.
 */
export function auditLayout(sheets) {
  const problems = [];
  for (const s of sheets) {
    for (let i = 0; i < s.parts.length; i++) {
      for (let j = i + 1; j < s.parts.length; j++) {
        const a = s.parts[i];
        const b = s.parts[j];
        const xs = a.x < b.x + b.w && b.x < a.x + a.w;
        const ys = a.y < b.y + b.h && b.y < a.y + a.h;
        if (xs && ys) problems.push(`sheet ${s.index}: ${a.id} overlaps ${b.id}`);
      }
    }
  }
  return { ok: problems.length === 0, problems };
}
