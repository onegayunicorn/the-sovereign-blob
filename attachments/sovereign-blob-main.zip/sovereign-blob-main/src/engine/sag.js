/**
 * Load / deflection checks — the "can this shelf physically hold books" gate.
 *
 * Model used (standard simply-supported beam, uniformly distributed load):
 *
 *   delta_immediate = 5 * w * L^4 / (384 * E * I)
 *
 *   w = load per unit length (N/mm) = (payload kg + board self mass kg) * 9.81 / L
 *   L = clear span between supports (mm)
 *   E = bending modulus of elasticity (N/mm^2)
 *   I = second moment of area (mm^4) = depth * thickness^3 / 12
 *
 * Long-term deflection applies a creep multiplier. Wood and wood-composites creep
 * under sustained load, so the design check uses the long-term figure. Default
 * K = 2.0, which is the conventional value for seasoned wood/composite members.
 *
 * Serviceability limit: span / 360 for loaded shelves (a common furniture criterion,
 * roughly the point where a shelf visibly bows). Override via options.ratioDivisor.
 *
 * This is a first-order hand-calculation, appropriate for domestic shelving. It is
 * NOT a structural engineering certificate.
 */

export const GRAVITY = 9.81;

export function secondMomentOfArea(depthMm, thicknessMm) {
  return (depthMm * Math.pow(thicknessMm, 3)) / 12;
}

export function lineLoadNPerMm(totalKg, spanMm) {
  return (totalKg * GRAVITY) / spanMm;
}

export function immediateDeflectionMm({ loadKg, spanMm, E, depthMm, thicknessMm }) {
  const I = secondMomentOfArea(depthMm, thicknessMm);
  const w = lineLoadNPerMm(loadKg, spanMm);
  return (5 * w * Math.pow(spanMm, 4)) / (384 * E * I);
}

/**
 * Full serviceability check for one shelf.
 * @returns {{immediateMm:number, longTermMm:number, limitMm:number, utilisation:number, pass:boolean, I:number, spanRatio:number}}
 */
export function shelfCheck({
  loadKg,
  selfMassKg = 0,
  spanMm,
  material,
  thicknessMm,
  depthMm,
  creepFactor = 2.0,
  ratioDivisor = 360
}) {
  const totalKg = loadKg + selfMassKg;
  const immediateMm = immediateDeflectionMm({
    loadKg: totalKg,
    spanMm,
    E: material.E,
    depthMm,
    thicknessMm
  });
  const longTermMm = immediateMm * creepFactor;
  const limitMm = spanMm / ratioDivisor;
  const utilisation = longTermMm / limitMm;
  return {
    immediateMm: round3(immediateMm),
    longTermMm: round3(longTermMm),
    limitMm: round3(limitMm),
    utilisation: round3(utilisation),
    pass: utilisation <= 1,
    I: Math.round(secondMomentOfArea(depthMm, thicknessMm)),
    spanRatio: Math.round(spanMm / (longTermMm || 1e-9)),
    totalLoadKg: round3(totalKg)
  };
}

/**
 * Minimum thickness (from the material's available thicknesses) that passes the check,
 * plus the deflection at that thickness. Returns null if no available thickness passes.
 */
export function minimumThickness({
  availableThicknessesMm,
  loadKg,
  selfMassPerMmThicknessKg,
  spanMm,
  material,
  depthMm,
  creepFactor = 2.0,
  ratioDivisor = 360
}) {
  const sorted = [...availableThicknessesMm].sort((a, b) => a - b);
  for (const t of sorted) {
    const selfMassKg = selfMassPerMmThicknessKg * t;
    const check = shelfCheck({
      loadKg,
      selfMassKg,
      spanMm,
      material,
      thicknessMm: t,
      depthMm,
      creepFactor,
      ratioDivisor
    });
    if (check.pass) return { thicknessMm: t, check };
  }
  return null;
}

/**
 * Tip-over / overturn check for a freestanding tall unit.
 * Overturning moment from a horizontal push at handle height vs restoring moment
 * from the unit's own mass about the front edge of the base.
 *
 * pushForceN defaults to 200 N, the conventional furniture tip-over test load for
 * domestic furniture. margin < 1 means it tips unanchored.
 */
export function tipOverCheck({
  massKg,
  depthMm,
  heightMm,
  pushForceN = 200,
  payloadMassKg = 0,
  payloadHeightMm = null,
  rearDropMm = 0
}) {
  const pushHeight = payloadHeightMm ?? heightMm * 0.9;

  // Rear supports cut short by rearDropMm lean the unit back by theta = atan(drop / depth).
  // The lean moves the centre of mass rearward, which LENGTHENS the restoring lever arm about
  // the front tipping edge — and that arm is what the margin is made of.
  //
  // The blueprint specified `tipOverMargin = baseMargin + height * sin(atan(drop/depth))`, which
  // adds millimetres to a dimensionless ratio: at h=1800 the "improvement" would be 12 added to
  // a margin of 0.166, i.e. 72x. Implemented instead as a shift of the centre of mass, so units
  // stay consistent and the benefit is real but modest.
  //
  // The centre of mass is taken at half the height (a uniform case), not the full height. Using
  // the full height - as the blueprint did - overstates the gain by roughly 2x.
  const tiltRad = rearDropMm > 0 ? Math.atan(rearDropMm / depthMm) : 0;
  const comHeightMm = heightMm / 2;
  const comShiftMm = rearDropMm > 0 ? comHeightMm * Math.sin(tiltRad) : 0;

  const overturningMoment = pushForceN * (pushHeight / 1000); // N*m
  const restoringMoment = (massKg + payloadMassKg) * GRAVITY * (depthMm / 1000 / 2 + comShiftMm / 1000); // N*m
  const margin = restoringMoment / overturningMoment;

  return {
    overturningMomentNm: round3(overturningMoment),
    restoringMomentNm: round3(restoringMoment),
    margin: round3(margin),
    // Reported so the manifest can show the geometry that produced the margin rather than
    // only the result.
    rearDropMm,
    tiltDeg: round3((tiltRad * 180) / Math.PI),
    comShiftMm: round3(comShiftMm),
    pass: margin >= 1,
    anchoredRequired: margin < 1
  };
}

/**
 * Racking (sideways shear) indicator for a panel-sided unit.
 * Empirical: a fixed back panel is by far the cheapest way to stop racking.
 */
export function rackingCheck({ hasBackPanel, hasBraces }) {
  if (hasBackPanel) return { pass: true, mechanism: 'fixed back panel acts as a shear diaphragm' };
  if (hasBraces) return { pass: true, mechanism: 'diagonal braces' };
  return {
    pass: false,
    mechanism: 'none',
    action: 'add a fixed back panel or diagonal braces; unsupported rectangular boxes rack under load'
  };
}

function round3(n) {
  return Math.round(n * 1000) / 1000;
}
