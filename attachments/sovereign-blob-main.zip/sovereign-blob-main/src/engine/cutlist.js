/**
 * Cut list — turns a dimensioned spec into manufacturable panels, then nests them.
 * Panel breakdown convention for a case-goods bookshelf:
 *   - sides run full height, shelves sit BETWEEN the sides (so span = width - 2t)
 *   - the back panel is a fixed shear diaphragm (this is what stops racking)
 *   - grain runs along each part's long dimension on grain-sensitive sheet goods
 */

import { resolveMaterial, boardMassKg, nearestThickness } from './materials.js';
import { packSheets } from './nesting.js';
import { selectJoinery, fastenerCountFor } from './joinery.js';
import { shelfCheck, tipOverCheck, rackingCheck } from './sag.js';

export const DEFAULT_SHEET = { lengthMm: 2440, widthMm: 1220 };
export const DEFAULT_SPEC = {
  kind: 'bookshelf',
  widthMm: 900,
  heightMm: 1800,
  depthMm: 300,
  shelves: 5,
  thicknessMm: 18,
  material: 'birch-plywood',
  backPanel: true,
  backThicknessMm: 6,
  plinth: true,
  plinthHeightMm: 80,
  anchored: false,
  loadPerShelfKg: 25,
  joinery: null,
  knockdown: false,
  // Rear supports cut short to induce a slight backward lean. See the tip-over physics in
  // sag.js: the lean moves the centre of mass toward the wall, lengthening the restoring arm.
  rearDropMm: 1.5
};

export function normaliseSpec(input = {}) {
  const spec = { ...DEFAULT_SPEC, ...input };
  const material = resolveMaterial(spec.material);
  spec.material = material.id;
  spec.thicknessMm = nearestThickness(material, spec.thicknessMm);
  spec.shelves = Math.max(2, Math.round(spec.shelves));
  // A shelf bay taller than 450 mm wastes storage; taller than 900 mm looks wrong.
  spec.bayClearMm = round1((spec.heightMm - spec.shelves * spec.thicknessMm) / Math.max(1, spec.shelves - 1));
  return spec;
}

export function buildCutList(specInput, options = {}) {
  const spec = normaliseSpec(specInput);
  const material = resolveMaterial(spec.material);
  const sheet = options.sheet || DEFAULT_SHEET;
  const t = spec.thicknessMm;
  const span = spec.widthMm - 2 * t; // clear span of each shelf
  const joinery = selectJoinery({ material, thicknessMm: t, requested: spec.joinery, knockdown: spec.knockdown });

  const parts = [];
  const push = (p) => parts.push({ grainSensitive: material.grainSensitive, ...p });

  // Sides: full height, grain vertical so the case looks consistent and the
  // outer face is the panel's strongest direction.
  push({
    id: 'side-L',
    label: 'Side panel, left',
    qty: 1,
    lengthMm: spec.heightMm,
    widthMm: spec.depthMm,
    thicknessMm: t,
    edgesBanded: ['front']
  });
  push({
    id: 'side-R',
    label: 'Side panel, right',
    qty: 1,
    lengthMm: spec.heightMm,
    widthMm: spec.depthMm,
    thicknessMm: t,
    edgesBanded: ['front']
  });

  // Horizontals (top, bottom and interior shelves) all identical: between the sides.
  push({
    id: 'shelf',
    label: `Shelf / horizontal panel (span ${span} mm)`,
    qty: spec.shelves,
    lengthMm: span,
    widthMm: spec.depthMm,
    thicknessMm: t,
    edgesBanded: ['front'],
    note: 'Grain must run along the span. Do not rotate this part on the sheet.'
  });

  if (spec.plinth) {
    push({
      id: 'plinth',
      label: `Front plinth rail (${spec.plinthHeightMm} mm)`,
      qty: 1,
      lengthMm: span,
      widthMm: spec.plinthHeightMm,
      thicknessMm: t,
      edgesBanded: ['top', 'bottom'],
      // A rail is a visible plywood part, so its grain must run along its length too.
      grainSensitive: true
    });
  }

  if (spec.backPanel) {
    push({
      id: 'back',
      label: `Back panel (${spec.backThicknessMm} mm)`,
      qty: 1,
      lengthMm: spec.heightMm,
      widthMm: spec.widthMm,
      thicknessMm: spec.backThicknessMm,
      material: 'birch-plywood',
      edgesBanded: [],
      grainSensitive: false,
      separateSheet: true
    });
  }

  // Nest the main carcass parts and the back panel separately: different thickness,
  // so they cannot share a sheet.
  const carcassParts = parts.filter((p) => !p.separateSheet);
  const backParts = parts.filter((p) => p.separateSheet);

  const carcassNest = packSheets(carcassParts, sheet, { kerfMm: options.kerfMm ?? 0 });
  const backNest = backParts.length
    ? packSheets(backParts, sheet, { kerfMm: options.kerfMm ?? 0 })
    : { sheets: [], sheetCount: 0, overallUtilisation: 0, totalPartAreaMm2: 0, unplaced: [] };

  // Load / physics checks per shelf.
  const shelfSelfMassKg = boardMassKg(material, t, spec.depthMm, span);
  const shelfSelfPerMm = boardMassKg(material, 1, spec.depthMm, span);
  const check = shelfCheck({
    loadKg: spec.loadPerShelfKg,
    selfMassKg: shelfSelfMassKg,
    spanMm: span,
    material,
    thicknessMm: t,
    depthMm: spec.depthMm,
    creepFactor: options.creepFactor ?? 2.0,
    ratioDivisor: options.ratioDivisor ?? 360
  });

  let remedy = null;
  if (!check.pass) {
    const thicker = shelfCheck({
      loadKg: spec.loadPerShelfKg,
      selfMassKg: boardMassKg(material, Math.min(...material.thicknessesMm.filter((x) => x > t)), spec.depthMm, span),
      spanMm: span,
      material,
      thicknessMm: Math.min(...material.thicknessesMm.filter((x) => x > t)),
      depthMm: spec.depthMm
    });
    const midRail = shelfCheck({
      loadKg: spec.loadPerShelfKg,
      selfMassKg: shelfSelfMassKg,
      spanMm: span / 2,
      material,
      thicknessMm: t,
      depthMm: spec.depthMm
    });
    const deep = shelfCheck({
      loadKg: spec.loadPerShelfKg,
      selfMassKg: boardMassKg(material, t, spec.depthMm + 50, span),
      spanMm: span,
      material,
      thicknessMm: t,
      depthMm: spec.depthMm + 50
    });
    remedy = {
      thickerSheetMm: boardMassKg(material, t, spec.depthMm, span) && Math.min(...material.thicknessesMm.filter((x) => x > t)),
      thickerPasses: thicker.pass,
      thickerDeflectionMm: thicker.longTermMm,
      midRailAtHalfSpanPasses: midRail.pass,
      midRailDeflectionMm: midRail.longTermMm,
      deeperShelfMm: spec.depthMm + 50,
      deeperShelfPasses: deep.pass,
      deeperShelfDeflectionMm: deep.longTermMm
    };
  }

  // Tip-over: a tall bookcase is a known child-safety hazard.
  const carcassMassKg = parts.reduce(
    (sum, p) => sum + boardMassKg(material, p.thicknessMm, p.widthMm, p.lengthMm) * p.qty,
    0
  );
  // Tip-over is computed twice: with the rear drop and without it. Reporting the delta means
  // the benefit of the lean is a measured number in the manifest rather than a claim in a
  // design note, and it keeps the "0 mm reproduces the old value" invariant visible.
  const tipArgs = { massKg: carcassMassKg, depthMm: spec.depthMm, heightMm: spec.heightMm, payloadMassKg: 0 };
  const tipNoDrop = tipOverCheck({ ...tipArgs, rearDropMm: 0 });
  const tip = tipOverCheck({ ...tipArgs, rearDropMm: spec.rearDropMm ?? 0 });
  tip.marginWithoutRearDrop = tipNoDrop.margin;
  tip.marginGain = Math.round((tip.margin - tipNoDrop.margin) * 1000) / 1000;
  const racking = rackingCheck({ hasBackPanel: spec.backPanel, hasBraces: false });

  // Fastener quantities.
  const fastenerLines = [];
  if (joinery.fastener) {
    const joints = [
      { label: 'shelf-to-side joints', lineLength: spec.depthMm, count: spec.shelves * 2 },
      { label: 'plinth-to-side joints', lineLength: spec.plinthHeightMm, count: spec.plinth ? 2 : 0 }
    ];
    for (const j of joints) {
      if (!j.count) continue;
      const per = fastenerCountFor(j.lineLength, joinery);
      if (per) fastenerLines.push({ label: j.label, per: per, count: per * j.count });
    }
  }

  const bandingMm =
    spec.heightMm * 2 + span * spec.shelves + (spec.plinth ? span * 2 : 0);

  const totalMassKg = carcassMassKg;

  return {
    spec,
    material: {
      id: material.id,
      label: material.label,
      E: material.E,
      densityKgM3: material.density,
      grainSensitive: material.grainSensitive,
      verified: material.verified
    },
    joinery,
    spanMm: span,
    clearBayMm: spec.bayClearMm,
    parts: parts.map((p) => ({
      ...p,
      massKg: round2(boardMassKg(resolveMaterial(p.material || spec.material), p.thicknessMm, p.widthMm, p.lengthMm) * p.qty)
    })),
    nesting: {
      carcass: carcassNest,
      back: backNest,
      sheetCount: carcassNest.sheetCount + backNest.sheetCount,
      carcassSheetCount: carcassNest.sheetCount,
      backSheetCount: backNest.sheetCount
    },
    checks: {
      shelfDeflection: check,
      shelfSelfMassKg: round2(shelfSelfMassKg),
      shelfSelfMassPerMmKg: shelfSelfPerMm,
      tipOver: tip,
      racking
    },
    remedy,
    fasteners: fastenerLines,
    edgeBandingMm: Math.round(bandingMm),
    totalMassKg: round2(totalMassKg),
    flags: buildFlags({ spec, material, check, tip, racking, nest: carcassNest, joinery })
  };
}

function buildFlags({ spec, material, check, tip, racking, nest, joinery }) {
  const flags = [];
  if (!material.verified) {
    flags.push({
      level: 'verify',
      code: 'unverified-material-data',
      message: `Elastic modulus for ${material.label} is a typical published value, not a supplier datasheet. Confirm E before trusting the deflection margin.`
    });
  }
  if (!check.pass) {
    flags.push({
      level: 'fail',
      code: 'shelf-sag',
      message: `A ${spec.widthMm} mm wide unit gives a ${Math.round(spec.widthMm - 2 * spec.thicknessMm)} mm shelf span. At ${spec.thicknessMm} mm ${material.label} with ${spec.loadPerShelfKg} kg per shelf, long-term sag is ${check.longTermMm} mm against a ${check.limitMm} mm limit (${Math.round(check.utilisation * 100)}% of allowance).`
    });
  }
  if (tip.anchoredRequired && !spec.anchored) {
    flags.push({
      level: 'fail',
      code: 'tip-over',
      message: `Unanchored tip-over margin is only ${tip.margin} (needs >= 1.0). This unit must be fixed to the wall.`
    });
  }
  if (!racking.pass) {
    flags.push({ level: 'fail', code: 'racking', message: racking.action });
  }
  if (joinery.substituted) {
    flags.push({ level: 'warn', code: 'joinery-substituted', message: joinery.selectedBecause });
  }
  if (nest.overallUtilisation < 0.5 && nest.sheetCount > 1) {
    flags.push({
      level: 'warn',
      code: 'low-sheet-yield',
      message: `Only ${Math.round(nest.overallUtilisation * 100)}% of the purchased sheets ends up as parts. The grain constraint forces whole panels to be oriented the same way. Reduce height/width or batch this with a second project.`
    });
  }
  if (nest.unplaced.length) {
    flags.push({ level: 'fail', code: 'unplaceable-part', message: `${nest.unplaced.length} part(s) do not fit on a sheet.` });
  }
  return flags;
}

function round1(n) { return Math.round(n * 10) / 10; }
function round2(n) { return Math.round(n * 100) / 100; }
