/**
 * Economic Engine — live cost tracking as the design changes.
 *
 * Rules that keep this honest:
 *  1. A price is only used if it exists in the vendor price book, which only contains
 *     prices that came back from a real tool result. Nothing is estimated.
 *  2. Bulk MOQ tiers are used but flagged: a tier price at MOQ 400 is not the price a
 *     person pays for one build, so every such line carries `basisMismatch: true` and
 *     the total is reported as an unrealistically LOW bound for those lines.
 *  3. Unpriced lines are surfaced as `unpriced`, never silently dropped.
 *  4. Only one currency is summed at a time. Lines in another currency are reported
 *     separately or converted only if an explicit FX rate is supplied by the caller
 *     (an invented rate is worse than no total).
 */

import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { resolveRegion } from './regions.js';

const here = dirname(fileURLToPath(import.meta.url));

export const DEFAULT_PRICE_BOOK_PATH = join(here, '..', '..', 'vendor', 'price-book.json');

export function loadPriceBook(path = DEFAULT_PRICE_BOOK_PATH) {
  return JSON.parse(readFileSync(path, 'utf8'));
}

/**
 * @param {object} cutList result of buildCutList()
 * @param {object} options
 * @param {object} [options.priceBook]
 * @param {string} [options.currency] currency to total in (default: book default)
 * @param {number} [options.cutServiceFactorMm2] if set, add a per-sheet CNC cut-service line item at quote stage only
 */
export function costBuild(cutList, options = {}) {
  const book = options.priceBook || loadPriceBook();
  const region = resolveRegion(options.region);
  // A region profile carries its own currency; an explicit caller currency still wins.
  const currency = options.currency || region?.currency || book.defaultCurrency;
  const lines = [];
  const unpriced = [];
  const otherCurrency = [];

  const add = (key, qty, role, extra = {}) => {
    const item = book.items[key];
    if (!item) {
      unpriced.push({ key, qty, role, label: key, reason: 'not present in price book' });
      return;
    }
    if (item.price == null) {
      unpriced.push({ key, qty, role, label: item.label, reason: item.note || 'not sourced', url: item.url });
      return;
    }
    const line = {
      key,
      label: item.label,
      qty,
      unit: item.unit,
      unitPrice: item.price,
      currency: item.currency,
      lineTotal: round2(item.price * qty),
      basis: item.basis,
      moq: item.moq ?? null,
      supplier: item.supplier,
      listing: item.listing,
      url: item.url,
      asOf: book.asOf,
      // A bulk tier is only usable if you actually order at least the MOQ.
      basisMismatch: item.basis === 'bulk-moq' && (item.moq ?? 1) > qty,
      role,
      ...extra
    };
    if (item.currency !== currency) otherCurrency.push(line);
    else lines.push(line);
  };

  // Sheet goods. The key comes from the region profile when one is given, so changing
  // supply mode (container tier vs local) changes the price source, not the code path.
  const t = cutList.spec.thicknessMm;
  const carcassKey = region?.carcassSheetPriceKey || `sheet-${t}mm-birch-plywood-2440x1220`;
  if (book.items[carcassKey]) {
    add(carcassKey, cutList.nesting.carcassSheetCount, 'material');
  } else {
    unpriced.push({
      key: carcassKey,
      qty: cutList.nesting.carcassSheetCount,
      role: 'material',
      label: `${t} mm ${cutList.material.label} sheet`,
      reason: region
        ? `no sourced price for region "${region.id}" at this thickness`
        : 'no sourced price for this thickness — only 18 mm was priced'
    });
  }
  if (cutList.nesting.backSheetCount) {
    add(region?.backPanelPriceKey || 'sheet-6mm-back-panel', cutList.nesting.backSheetCount, 'material');
  }

  // Consumables driven by the joinery method.
  const j = cutList.joinery;
  if (j.id === 'pocket-screw') {
    const totalScrews = cutList.fasteners.reduce((s, f) => s + f.count, 0);
    add('pocket-screws-32mm-500ct', Math.max(1, Math.ceil(totalScrews / 500)), 'consumable', {
      note: `prorated from a 500-count pack for ${totalScrews} screws`
    });
  } else if (j.id === 'confirmat') {
    const totalScrews = cutList.fasteners.reduce((s, f) => s + f.count, 0);
    add('confirmat-screws-7x50', totalScrews, 'consumable');
  } else if (j.id === 'dowel') {
    const totalDowels = cutList.fasteners.reduce((s, f) => s + f.count, 0);
    add('dowel-pins-44mm-250ct', Math.max(1, Math.ceil(totalDowels / 250)), 'consumable');
  }

  // Safety requirement.
  if (cutList.checks.tipOver.anchoredRequired) {
    add('wall-anchor-kit-4pack', 1, 'safety');
  }

  // Tools are reported separately from build cost.
  const tools = [];
  if (j.id === 'pocket-screw') {
    const kit = book.items['pocket-hole-jig-kit'];
    if (kit && kit.price != null) {
      tools.push({
        key: 'pocket-hole-jig-kit',
        label: kit.label,
        qty: 1,
        unitPrice: kit.price,
        currency: kit.currency,
        lineTotal: kit.price,
        url: kit.url,
        note: 'one-off tool purchase; reusable across builds'
      });
    }
  }

  // Tax is reported as its own line and added to the total, but is NOT pushed into
  // `lines`: it is not a purchased item, and counting it would inflate pricedLines.
  let tax = null;
  if (region?.gstRate) {
    const subtotal = round2(lines.reduce((s, l) => s + l.lineTotal, 0));
    tax = {
      label: `GST ${(region.gstRate * 100).toFixed(0)}%`,
      rate: region.gstRate,
      amount: round2(subtotal * region.gstRate)
    };
  }

  const total = round2(lines.reduce((s, l) => s + l.lineTotal, 0) + (tax?.amount ?? 0));
  const toolTotal = round2(tools.reduce((s, l) => s + l.lineTotal, 0));
  const mismatched = lines.filter((l) => l.basisMismatch);

  return {
    asOf: book.asOf,
    currency,
    region: region
      ? {
          id: region.id,
          label: region.label,
          supplyMode: region.supplyMode,
          sheetMm: region.sheetMm,
          freightModelled: region.freightModelled ?? false,
          cutServiceIncluded: region.cutServiceIncluded ?? false
        }
      : null,
    lines,
    tools,
    total,
    tax,
    toolTotal,
    otherCurrency,
    unpriced,
    confidence: {
      pricedLines: lines.length,
      unpricedLines: unpriced.length,
      anyBulkTierPriced: mismatched.length > 0,
      note:
        unpriced.length || mismatched.length
          ? 'This is a partial cost. See `unpriced` for lines with no verified price and `basisMismatch` for bulk-tier prices that a single build cannot actually buy at.'
          : 'All lines priced from verified listings.'
    }
  };
}

/**
 * Marginal cost of a design change — the point of a live economic engine.
 * Returns only the network effect, not the whole build cost.
 */
export function deltaCost(before, after) {
  return {
    beforeTotal: before.total,
    afterTotal: after.total,
    delta: round2(after.total - before.total),
    currency: after.currency,
    newUnpriced: after.unpriced.length - before.unpriced.length
  };
}

function round2(n) {
  return Math.round(n * 100) / 100;
}
