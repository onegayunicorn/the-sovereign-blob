/**
 * Region / supply-mode profiles.
 *
 * This is the code behind the "Mode A vs Mode B" sourcing decision. A profile pins the
 * sheet size the nesting runs against and the price-book keys the cost engine draws on,
 * so switching from container-scale supply to local fabrication is a configuration change
 * rather than a fork of the engine.
 *
 * The default is deliberately the bulk profile: existing behaviour and the existing test
 * suite do not move when this file is added.
 */

import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const CONFIG = join(HERE, '..', '..', 'config', 'regions.json');

let cache = null;

export function loadRegions() {
  if (!cache) cache = JSON.parse(readFileSync(CONFIG, 'utf8'));
  return cache;
}

/**
 * Accepts a profile id, a profile object (already resolved), or nothing.
 * Returns null when nothing is supplied, which tells callers to keep legacy defaults.
 */
export function resolveRegion(idOrProfile) {
  if (!idOrProfile) return null;
  if (typeof idOrProfile === 'object') return idOrProfile;
  const profile = loadRegions().regions[idOrProfile];
  if (!profile) {
    const known = Object.keys(loadRegions().regions).join(', ');
    throw new Error(`unknown region "${idOrProfile}" — known regions: ${known}`);
  }
  return profile;
}

export function defaultRegionId() {
  return loadRegions().default;
}

/** Nesting sheet for a region, or null to fall back to DEFAULT_SHEET. */
export function regionSheet(region) {
  if (!region?.sheetMm) return null;
  return { lengthMm: region.sheetMm.lengthMm, widthMm: region.sheetMm.widthMm };
}
