/**
 * Metaball field + iso-contour extraction.
 *
 * F(x, y) = sum over nodes of  w * r^2 / max(d^2, eps)
 * A point is inside the blob when F exceeds the threshold. The visible outline is the
 * contour F = threshold, extracted with marching squares so the surface is a real
 * geometric object rather than a stack of drawn circles.
 *
 * Everything here is pure and deterministic, which is what lets the test suite assert
 * on the surface (area, centroid, containment) instead of only on pixels.
 */

const EPS = 1e-6;
export const DEFAULT_THRESHOLD = 1.0;

export function fieldAt(nodes, x, y) {
  let f = 0;
  for (const n of nodes) {
    const dx = x - n.x;
    const dy = y - n.y;
    const d2 = dx * dx + dy * dy;
    f += ((n.w ?? 1) * n.r * n.r) / Math.max(d2, EPS);
  }
  return f;
}

export function isInside(nodes, x, y, threshold = DEFAULT_THRESHOLD) {
  return fieldAt(nodes, x, y) >= threshold;
}

/** Normalised density 0..1 for shading, clamped where the field blows up near a node. */
export function densityAt(nodes, x, y, threshold = DEFAULT_THRESHOLD) {
  const f = fieldAt(nodes, x, y);
  return Math.max(0, Math.min(1, f / (threshold * 2.5)));
}

/** Bounding box of the surface, sampled on a grid. */
export function surfaceBounds(nodes, { res = 96, threshold = DEFAULT_THRESHOLD } = {}) {
  let minX = 1, minY = 1, maxX = 0, maxY = 0, hits = 0;
  for (let i = 0; i <= res; i++) {
    for (let j = 0; j <= res; j++) {
      const x = i / res;
      const y = j / res;
      if (isInside(nodes, x, y, threshold)) {
        hits++;
        if (x < minX) minX = x;
        if (y < minY) minY = y;
        if (x > maxX) maxX = x;
        if (y > maxY) maxY = y;
      }
    }
  }
  if (!hits) return { empty: true, hits: 0 };
  return { empty: false, hits, x: minX, y: minY, w: maxX - minX, h: maxY - minY, areaFraction: hits / ((res + 1) * (res + 1)) };
}

export function centroid(nodes, { res = 96, threshold = DEFAULT_THRESHOLD } = {}) {
  let sx = 0, sy = 0, n = 0;
  for (let i = 0; i <= res; i++) {
    for (let j = 0; j <= res; j++) {
      const x = i / res;
      const y = j / res;
      if (isInside(nodes, x, y, threshold)) {
        sx += x;
        sy += y;
        n++;
      }
    }
  }
  return n ? { x: sx / n, y: sy / n, samples: n } : { x: null, y: null, samples: 0 };
}

/**
 * Marching squares. Returns closed/open polylines in normalised space.
 * Corner layout:  v0=(i,j) v1=(i+1,j) v2=(i+1,j+1) v3=(i,j+1)
 */
export function contour(nodes, { res = 64, threshold = DEFAULT_THRESHOLD } = {}) {
  const step = 1 / res;
  const segments = [];

  const interp = (xa, ya, va, xb, yb, vb) => {
    const denom = vb - va;
    const t = Math.abs(denom) < EPS ? 0.5 : (threshold - va) / denom;
    return [xa + (xb - xa) * t, ya + (yb - ya) * t];
  };

  for (let i = 0; i < res; i++) {
    for (let j = 0; j < res; j++) {
      const x0 = i * step, y0 = j * step, x1 = x0 + step, y1 = y0 + step;
      const v0 = fieldAt(nodes, x0, y0);
      const v1 = fieldAt(nodes, x1, y0);
      const v2 = fieldAt(nodes, x1, y1);
      const v3 = fieldAt(nodes, x0, y1);
      let idx = 0;
      if (v0 >= threshold) idx |= 1;
      if (v1 >= threshold) idx |= 2;
      if (v2 >= threshold) idx |= 4;
      if (v3 >= threshold) idx |= 8;
      if (idx === 0 || idx === 15) continue;

      const bottom = () => interp(x0, y0, v0, x1, y0, v1);
      const right = () => interp(x1, y0, v1, x1, y1, v2);
      const top = () => interp(x0, y1, v3, x1, y1, v2);
      const left = () => interp(x0, y0, v0, x0, y1, v3);

      const table = {
        1: [left(), bottom()],
        2: [bottom(), right()],
        3: [left(), right()],
        4: [right(), top()],
        5: [left(), top()],
        6: [bottom(), top()],
        7: [left(), top()],
        8: [top(), left()],
        9: [top(), bottom()],
        10: [bottom(), left()],
        11: [top(), right()],
        12: [right(), left()],
        13: [right(), bottom()],
        14: [bottom(), right()]
      };
      const seg = table[idx];
      if (seg) segments.push(seg);
    }
  }

  return stitch(segments);
}

function key(p) {
  return `${Math.round(p[0] * 1e4)}:${Math.round(p[1] * 1e4)}`;
}

function stitch(segments) {
  const byStart = new Map();
  segments.forEach((s, i) => {
    const k = key(s[0]);
    if (!byStart.has(k)) byStart.set(k, []);
    byStart.get(k).push(i);
  });
  const used = new Array(segments.length).fill(false);
  const polylines = [];

  for (let i = 0; i < segments.length; i++) {
    if (used[i]) continue;
    used[i] = true;
    const line = [segments[i][0], segments[i][1]];
    // walk forward
    for (;;) {
      const candidates = byStart.get(key(line[line.length - 1])) || [];
      const nextIdx = candidates.find((c) => !used[c]);
      if (nextIdx === undefined) break;
      used[nextIdx] = true;
      line.push(segments[nextIdx][1]);
      if (key(line[line.length - 1]) === key(line[0])) break;
    }
    polylines.push(line);
  }
  polylines.sort((a, b) => b.length - a.length);
  return polylines;
}

/** Total surface perimeter in normalised units — a cheap shape-complexity measure. */
export function perimeter(polylines) {
  let p = 0;
  for (const line of polylines) {
    for (let i = 1; i < line.length; i++) {
      p += Math.hypot(line[i][0] - line[i - 1][0], line[i][1] - line[i - 1][1]);
    }
  }
  return p;
}

/** Shrink-wrap report used by the prototype UI and the tests. */
export function describeSurface(nodes, options = {}) {
  const pl = contour(nodes, options);
  return {
    threshold: options.threshold ?? DEFAULT_THRESHOLD,
    polylines: pl.length,
    largestPolylinePoints: pl.length ? pl[0].length : 0,
    perimeter: Number(perimeter(pl).toFixed(4)),
    bounds: surfaceBounds(nodes, options),
    centroid: centroid(nodes, options)
  };
}
