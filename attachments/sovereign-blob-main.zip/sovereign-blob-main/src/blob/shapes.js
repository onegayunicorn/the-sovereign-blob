/**
 * Shape programs — the "fluid pixels".
 *
 * A shape is a set of metaball nodes in normalised 0..1 space. The renderer samples
 * the field these nodes emit; the field's iso-contour is what you see as the blob.
 *
 * The important honesty point: the blob never "becomes" matter. What actually happens
 * is a two-stage transition:
 *   1. an amorphous node cloud (no design information)
 *   2. a shape program whose node layout is derived from the user's spoken dimensions
 *   3. a rectilinear plan whose coordinates are the REAL cut-list geometry
 * Stage 3 is the only one that is manufacturable, and it is exact. Stages 1-2 are a
 * visualisation of the same numbers, not a separate source of truth.
 */

/** Deterministic LCG so the same seed always produces the same cloud. */
function lcg(seed) {
  let s = seed >>> 0;
  return () => {
    s = (1664525 * s + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

export function amorphous(seed = 1, count = 14) {
  const rnd = lcg(seed);
  const nodes = [];
  for (let i = 0; i < count; i++) {
    nodes.push({
      x: 0.15 + rnd() * 0.7,
      y: 0.1 + rnd() * 0.8,
      r: 0.06 + rnd() * 0.09,
      w: 0.6 + rnd() * 0.4
    });
  }
  return { kind: 'amorphous', nodes, seed };
}

/**
 * Bookshelf shape program: two verticals plus N horizontals, laid out to the
 * proportions of the real spec so the visual already carries the geometry.
 */
export function bookshelfShape(spec = {}) {
  const shelves = Math.max(2, spec.shelves ?? 5);
  const nodes = [];
  // Node spacing is chosen at ~2.2 x radius: below ~2x the field never dips under the
  // threshold between nodes (the whole outline floods), above ~2.5x the limbs break up
  // into beads. This is the constraint that decides the look of the blob.
  const R = 0.045;
  const nodesPerVertical = 9; // spacing 0.105
  for (const vx of [0.16, 0.84]) {
    for (let i = 0; i < nodesPerVertical; i++) {
      const t = i / (nodesPerVertical - 1);
      nodes.push({ x: vx, y: 0.08 + t * 0.84, r: R, w: 1 });
    }
  }
  for (let i = 0; i < shelves; i++) {
    const t = shelves === 1 ? 0.5 : i / (shelves - 1);
    const y = 0.08 + t * 0.84; // shelf rows land on vertical nodes, where they would be joined
    const nodesPerShelf = 7; // spacing 0.113
    for (let j = 0; j < nodesPerShelf; j++) {
      const u = j / (nodesPerShelf - 1);
      nodes.push({ x: 0.16 + u * 0.68, y, r: R, w: 1 });
    }
  }
  return { kind: 'bookshelf', nodes };
}

export function tableShape() {
  const nodes = [];
  for (const vx of [0.18, 0.82]) {
    for (let i = 0; i < 5; i++) nodes.push({ x: vx, y: 0.3 + (i / 4) * 0.6, r: 0.05, w: 1 });
  }
  for (let j = 0; j < 7; j++) nodes.push({ x: 0.16 + (j / 6) * 0.68, y: 0.28, r: 0.05, w: 1 });
  return { kind: 'table', nodes };
}

export function genericBoxShape() {
  const nodes = [];
  const ring = [
    [0.2, 0.15], [0.5, 0.1], [0.8, 0.15], [0.85, 0.5], [0.8, 0.85], [0.5, 0.9], [0.2, 0.85], [0.15, 0.5]
  ];
  for (const [x, y] of ring) nodes.push({ x, y, r: 0.11, w: 1 });
  return { kind: 'generic', nodes };
}

export function shapeForTemplate(template, spec) {
  switch (template) {
    case 'bookshelf':
      return bookshelfShape(spec);
    case 'table':
      return tableShape();
    default:
      return genericBoxShape();
  }
}

/**
 * Morph between two shape programs. Node counts differ, so the shorter list is
 * padded with zero-radius nodes pinned to the target position — the surface then
 * grows node-for-node instead of snapping.
 */
export function morph(from, to, t) {
  const n = Math.max(from.nodes.length, to.nodes.length);
  const nodes = [];
  for (let i = 0; i < n; i++) {
    const a = from.nodes[i];
    const b = to.nodes[i];
    const ax = a ? a.x : b.x;
    const ay = a ? a.y : b.y;
    const bx = b ? b.x : a.x;
    const by = b ? b.y : a.y;
    const ar = a ? a.r : 0;
    const br = b ? b.r : 0;
    // Residual wobble while the shape is still forming. It is zero at BOTH ends so that
    // t=0 is exactly the start shape and t=1 is exactly the target shape — otherwise the
    // settled visual would not match the geometry that actually gets cut.
    const wobble = Math.sin(Math.PI * t) * 0.012;
    // Node weight must be interpolated too. Dropping it (hard-coding w: 1) silently
    // inflates the surface, so t=0 would no longer reproduce the start shape.
    const aw = a ? (a.w ?? 1) : 0;
    const bw = b ? (b.w ?? 1) : 0;
    nodes.push({
      x: ax + (bx - ax) * t + Math.sin(i * 2.3) * wobble,
      y: ay + (by - ay) * t + Math.cos(i * 1.7) * wobble,
      r: ar + (br - ar) * t,
      w: aw + (bw - aw) * t
    });
  }
  return { kind: to.kind, nodes, progress: t };
}

/**
 * The settled state: exact rectangles from the real cut list, in millimetres.
 * This replaces the field entirely — the renderer draws this when progress = 1.
 */
export function rectilinearPlan(cutList) {
  const { spec } = cutList;
  const t = spec.thicknessMm;
  const rects = [];
  // sides
  rects.push({ id: 'side-L', x: 0, y: 0, w: t, h: spec.heightMm, kind: 'side' });
  rects.push({ id: 'side-R', x: spec.widthMm - t, y: 0, w: t, h: spec.heightMm, kind: 'side' });
  // horizontals
  for (let i = 0; i < spec.shelves; i++) {
    const y = i * ((spec.heightMm - t) / Math.max(1, spec.shelves - 1));
    rects.push({ id: `shelf-${i + 1}`, x: t, y: Math.min(y, spec.heightMm - t), w: spec.widthMm - 2 * t, h: t, kind: 'shelf' });
  }
  if (spec.plinth) {
    rects.push({
      id: 'plinth',
      x: t,
      y: spec.heightMm - t - spec.plinthHeightMm,
      w: spec.widthMm - 2 * t,
      h: spec.plinthHeightMm,
      kind: 'plinth'
    });
  }
  return { kind: 'plan', units: 'mm', widthMm: spec.widthMm, heightMm: spec.heightMm, rects };
}

/**
 * Section depth profile — used by the SVG plan export to draw the side elevation
 * with the shelf positions at their true heights.
 */
export function elevations(cutList) {
  const { spec } = cutList;
  const t = spec.thicknessMm;
  const shelfYs = [];
  for (let i = 0; i < spec.shelves; i++) {
    const y = i * ((spec.heightMm - t) / Math.max(1, spec.shelves - 1));
    shelfYs.push(Math.min(y, spec.heightMm - t));
  }
  return {
    front: { widthMm: spec.widthMm, heightMm: spec.heightMm, shelfYs, thicknessMm: t },
    side: { widthMm: spec.depthMm, heightMm: spec.heightMm, shelfYs, thicknessMm: t },
    clearBaysMm: shelfYs.slice(1).map((y, i) => Math.round(y - (shelfYs[i] + t)))
  };
}
