/**
 * Canvas renderer for the blob.
 *
 * Three display states, all driven by the same numbers the engine computed:
 *   field    - density-shaded metaball surface (the amorphous / forming states)
 *   contour  - the iso-contour outline, stroked in the Reality band colour
 *   plan     - the settled rectilinear geometry in millimetres, dimensioned
 *
 * The transition between them is a progress value, not a state machine: at progress 1
 * the field is gone and the plan is exact.
 */

import { fieldAt, contour, densityAt, DEFAULT_THRESHOLD } from './field.js';

export const PALETTE = {
  background: '#0A0A10',
  primary: '#00E5FF',
  secondary: '#00FFCC',
  warn: '#FFB020',
  fail: '#FF3B30',
  text: '#D8FFF7',
  grid: 'rgba(0,229,255,0.12)'
};

/** Fit a millimetre plan into the canvas, preserving aspect ratio. */
export function planViewport(plan, width, height, padding = 28) {
  const scale = Math.min((width - padding * 2) / plan.widthMm, (height - padding * 2) / plan.heightMm);
  const offsetX = (width - plan.widthMm * scale) / 2;
  const offsetY = (height - plan.heightMm * scale) / 2;
  return { scale, offsetX, offsetY, toPx: (x, y) => [offsetX + x * scale, offsetY + y * scale] };
}

export function drawField(ctx, nodes, { width, height, colour, progress = 0, threshold = DEFAULT_THRESHOLD }) {
  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = PALETTE.background;
  ctx.fillRect(0, 0, width, height);

  if (progress < 1) {
    // Low-resolution field rasterised into an offscreen buffer, then scaled up. The
    // grid is coarse on purpose: the metaball surface is smooth, the sampling is not,
    // and a soft upscale is what makes it read as fluid rather than as a grid.
    const gw = 96;
    const gh = Math.round((gw * height) / width);
    const buf = ctx.createImageData(gw, gh);
    const rgb = hexToRgb(colour);
    for (let j = 0; j < gh; j++) {
      for (let i = 0; i < gw; i++) {
        const x = i / (gw - 1);
        const y = j / (gh - 1);
        const f = fieldAt(nodes, x, y);
        const d = Math.max(0, Math.min(1, f / (threshold * 2.2)));
        const inside = d > 0.42;
        const k = (j * gw + i) * 4;
        buf.data[k] = inside ? rgb[0] : 10;
        buf.data[k + 1] = inside ? rgb[1] : 10;
        buf.data[k + 2] = inside ? rgb[2] : 16;
        buf.data[k + 3] = inside ? Math.round(120 + 135 * Math.min(1, d)) : 0;
      }
    }
    const off = document.createElement('canvas');
    off.width = gw;
    off.height = gh;
    off.getContext('2d').putImageData(buf, 0, 0);
    ctx.imageSmoothingEnabled = true;
    ctx.globalAlpha = 1 - progress;
    ctx.drawImage(off, 0, 0, width, height);
    ctx.globalAlpha = 1;

    // Contour stroke on top, so the surface has an edge rather than a fuzzy halo.
    const lines = contour(nodes, { res: 72, threshold });
    ctx.lineWidth = 1.6;
    ctx.strokeStyle = colour;
    ctx.globalAlpha = 1 - progress;
    for (const line of lines) {
      ctx.beginPath();
      line.forEach(([x, y], i) => {
        const px = x * width;
        const py = y * height;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      });
      if (line.length > 3) ctx.closePath();
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }
}

export function drawPlan(ctx, plan, { width, height, colour, showDimensions = true }) {
  const vp = planViewport(plan, width, height);
  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = PALETTE.background;
  ctx.fillRect(0, 0, width, height);

  // millimetre grid every 100 mm, for scale
  ctx.strokeStyle = PALETTE.grid;
  ctx.lineWidth = 0.5;
  for (let x = 0; x <= plan.widthMm; x += 100) {
    const [px] = vp.toPx(x, 0);
    ctx.beginPath();
    ctx.moveTo(px, vp.offsetY);
    ctx.lineTo(px, vp.offsetY + plan.heightMm * vp.scale);
    ctx.stroke();
  }
  for (let y = 0; y <= plan.heightMm; y += 100) {
    const [, py] = vp.toPx(0, y);
    ctx.beginPath();
    ctx.moveTo(vp.offsetX, py);
    ctx.lineTo(vp.offsetX + plan.widthMm * vp.scale, py);
    ctx.stroke();
  }

  for (const r of plan.rects) {
    const [px, py] = vp.toPx(r.x, plan.heightMm - r.y - r.h);
    const w = r.w * vp.scale;
    const h = r.h * vp.scale;
    ctx.fillStyle = r.kind === 'side' ? 'rgba(0,229,255,0.18)' : r.kind === 'plinth' ? 'rgba(255,176,32,0.16)' : 'rgba(0,255,204,0.14)';
    ctx.strokeStyle = colour;
    ctx.lineWidth = 1;
    ctx.fillRect(px, py, Math.max(1, w), Math.max(1, h));
    ctx.strokeRect(px, py, Math.max(1, w), Math.max(1, h));
  }

  const [ox, oy] = vp.toPx(0, plan.heightMm);
  ctx.strokeStyle = PALETTE.primary;
  ctx.lineWidth = 1.4;
  ctx.strokeRect(ox, oy, plan.widthMm * vp.scale, plan.heightMm * vp.scale);

  if (showDimensions) {
    ctx.fillStyle = PALETTE.text;
    ctx.font = '11px ui-monospace, monospace';
    ctx.fillText(`${plan.widthMm} mm`, ox, oy - 6);
    ctx.save();
    ctx.translate(ox - 8, oy + plan.heightMm * vp.scale);
    ctx.rotate(-Math.PI / 2);
    ctx.fillText(`${plan.heightMm} mm`, 0, 0);
    ctx.restore();
  }
  return vp;
}

export function hexToRgb(hex) {
  const h = hex.replace('#', '');
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}

export function densitySample(nodes, x, y, threshold = DEFAULT_THRESHOLD) {
  return densityAt(nodes, x, y, threshold);
}
