/**
 * PDF Build Packet — written from scratch, no dependency (spec section 12).
 *
 * The spec's reasoning for PDF before DXF is right: PDFs prove usefulness to humans, and the
 * first audience is the person who wants to build the shelf. So this packet is written for a
 * person standing in a workshop — measurements, cut list, hardware, cost, tools, assembly
 * order, load rating, safety, and the confidence score with the reasons it is not 1.0.
 *
 * The generator emits a byte-accurate xref table because a PDF with a wrong xref opens in
 * some viewers and not others, which is the worst possible outcome for a file whose whole job
 * is to be openable. `verifyPdf()` re-reads the bytes it produced and checks every offset
 * points at the object it claims — used by the test suite, so a regression here fails a test
 * rather than failing on someone's laptop.
 */

const PAGE = { width: 595.28, height: 841.89, margin: 42 };

const ascii = (s) =>
  String(s ?? '')
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201C\u201D]/g, '"')
    .replace(/[\u2013\u2014]/g, '-')
    .replace(/[^\x20-\x7E\n]/g, '?');

const escapeText = (s) => ascii(s).replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');

/** Naive wrap on character count. Good enough for a monospaced-ish build packet, and it
 *  never splits a word, which is what actually matters for readability. */
function wrap(text, maxChars) {
  const words = ascii(text).split(' ');
  const lines = [];
  let line = '';
  for (const w of words) {
    if (!line.length) line = w;
    else if ((line + ' ' + w).length <= maxChars) line += ' ' + w;
    else {
      lines.push(line);
      line = w;
    }
  }
  lines.push(line);
  return lines;
}

/**
 * Turn the design into a flat list of styled lines, then paginate.
 * `kind` is 'h1' | 'h2' | 'text' | 'kv' | 'gap'.
 */
export function buildPacketLines({ sbm, result, assembly = [] }) {
  const cl = result.cutList;
  const out = [];

  // buildAssemblySequence() returns { steps, stepCount }, while the SBM carries a mapped
  // array. Normalise both to one shape here rather than at every call site — and prefer the
  // manifest's copy, because the manifest is the thing every export is supposed to derive from.
  const rawSteps = Array.isArray(assembly) ? assembly : assembly?.steps;
  const steps = (rawSteps?.length ? rawSteps : sbm.assembly ?? []).map((s) => ({
    step: s.step,
    title: s.title ?? null,
    detail: s.detail ?? s.description ?? '',
    reason: s.reason ?? null
  }));
  const push = (kind, text) => out.push({ kind, text });
  const gap = () => push('gap', '');

  push('h1', 'Sovereign Blob - Build Packet');
  push('kv', `Project: ${sbm.project.name}  (${sbm.project.id})`);
  push('kv', `Generated: ${new Date().toISOString()}`);
  push('kv', `SBM version: ${sbm.sbmVersion}   Engine: ${sbm.audit.engineVersion}`);
  gap();

  push('h2', `Reality: ${sbm.reality.status}  |  Score ${sbm.reality.score}/100  |  Confidence ${sbm.reality.confidence}`);
  push('kv', `Structural ${sbm.reality.checks.structural} | Physical ${sbm.reality.checks.physical} | Economic ${sbm.reality.checks.economic} | Manufacturing ${sbm.reality.checks.manufacturing}`);
  for (const w of sbm.reality.warnings ?? []) push('text', `- ${w}`);
  gap();

  push('h2', '1. Measurements');
  push('kv', `Unit: ${cl.spec.widthMm} W x ${cl.spec.heightMm} H x ${cl.spec.depthMm} D mm, ${cl.spec.shelves} horizontal panel(s)`);
  push('kv', `Shelf clear span: ${cl.spanMm} mm    Clear bay height: ${cl.clearBayMm} mm`);
  push('kv', `Wall: ${sbm.spatial.wallWidth} x ${sbm.spatial.wallHeight} mm (confidence ${sbm.spatial.confidence}, source ${sbm.spatial.source})`);
  if (sbm.spatial.source === 'assumed-from-intent') {
    push('text', '- No wall scan was recorded. These are the spoken dimensions, not measurements.');
  }
  gap();

  push('h2', '2. Material');
  for (const m of sbm.materials) {
    push('kv', `${m.name} @ ${m.thickness} mm`);
    push('text', `   density ${m.density} kg/m3, E ${m.elasticModulus} MPa${m.provenanceVerified ? '' : ' (handbook value, NOT a supplier datasheet)'}`);
    push('text', `   ${m.sheetsRequired} sheet(s) required. Sheet cost ${m.sheetCost ?? 'unknown'} ${sbm.costing.currency}`);
  }
  push('kv', `Sheet layout: ${sbm.fabrication.sheetLayout}`);
  gap();

  push('h2', '3. Cut list');
  push('kv', 'Label                              Qty   W x H x T (mm)');
  for (const c of sbm.fabrication.cutList) {
    push('text', `${c.label.padEnd(34).slice(0, 34)} ${String(c.qty).padStart(3)}   ${c.width} x ${c.height} x ${c.thickness}`);
  }
  push('text', '');
  push('text', 'Grain direction matters: every panel must be cut with the face grain running along its LONG dimension. Do not rotate a part across the grain to save material.');
  gap();

  push('h2', '4. Hardware');
  const hardware = result.cost.lines.filter((l) => l.role !== 'material');
  if (!hardware.length) push('text', '- none listed');
  for (const h of hardware) push('text', `- ${h.qty} x ${h.label} - ${h.lineTotal} ${h.currency}`);
  gap();

  push('h2', '5. Estimated cost');
  for (const l of result.cost.lines) {
    push('text', `- ${l.qty} x ${l.label} - ${l.lineTotal} ${l.currency}${l.basisMismatch ? '  [bulk tier, below MOQ]' : ''}`);
  }
  if (result.cost.tax) push('text', `- ${result.cost.tax.label} - ${result.cost.tax.amount} ${result.cost.currency}`);
  push('kv', `TOTAL: ${result.cost.total} ${result.cost.currency}   Budget: ${sbm.costing.budgetStatus}`);
  for (const u of sbm.costing.unpricedLines) push('text', `- UNPRICED: ${u} (no verified price - not estimated)`);
  push('text', 'Fabrication cost is not included because no quote has been received. The total above is a lower bound.');
  gap();

  push('h2', '6. Tools required');
  if (!sbm.fabrication.toolsRequired.length) push('text', '- see assembly steps');
  for (const t of sbm.fabrication.toolsRequired) push('text', `- ${t}`);
  gap();

  push('h2', '7. Assembly sequence');
  for (const s of steps) {
    push('text', `${s.step}. ${s.title ? s.title + ' - ' : ''}${s.detail}`);
    if (s.reason) push('text', `     why: ${s.reason}`);
  }
  for (const s of result.intent.openQuestions ?? []) push('text', `? ${s}`);
  gap();

  push('h2', '8. Load rating');
  const def = cl.checks.shelfDeflection;
  push('kv', `Design load: ${cl.spec.loadPerShelfKg} kg per shelf`);
  push('kv', `Predicted long-term deflection: ${def.longTermMm} mm (immediate ${def.immediateMm} mm), allowance ${def.limitMm} mm`);
  push('kv', `Verdict: ${def.pass ? 'PASS' : 'FAIL'} at ${Math.round(def.utilisation * 100)}% of allowance`);
  push('kv', `Total unit mass: ${cl.totalMassKg} kg`);
  push('kv', `Tip-over margin: ${cl.checks.tipOver.margin}${cl.checks.tipOver.anchoredRequired ? ' - WALL FIXING REQUIRED' : ''}`);
  gap();

  push('h2', '9. Safety warnings');
  if (cl.checks.tipOver.anchoredRequired) {
    push('text', '- This unit must be fixed to the wall. A tall narrow case that is not fixed is a tip-over hazard, particularly with children present.');
  }
  if (!sbm.reality.checks.structural.includes('PASS')) {
    push('text', '- The structural check has NOT passed at this thickness. Do not build to this cut list until it does.');
  }
  push('text', '- 18 mm nominal board commonly measures 17.4-17.8 mm. Measure the board before cutting; thinner board deflects more.');
  if (sbm.reality.blockers.length) {
    push('text', '- BLOCKING ISSUES:');
    for (const b of sbm.reality.blockers) push('text', `    ${b}`);
  }
  gap();

  push('h2', '10. What this packet does not know');
  for (const b of sbm.reality.confidenceBasis ?? []) push('text', `- ${b}`);
  if (!(sbm.reality.confidenceBasis ?? []).length) push('text', '- nothing outstanding');
  push('text', `Confidence ${sbm.reality.confidence} is derived from information completeness, not from a model's opinion.`);

  return out;
}

function paginate(lines) {
  const pages = [];
  let current = [];
  let y = PAGE.height - PAGE.margin;
  const leadingFor = (kind) => (kind === 'h1' ? 26 : kind === 'h2' ? 22 : kind === 'gap' ? 12 : 13);

  for (const line of lines) {
    const wrapped = line.kind === 'text' ? wrap(line.text, line.text.length > 40 && /^\s/.test(line.text) ? 96 : 92) : [line.text];
    for (const piece of wrapped) {
      const leading = leadingFor(line.kind);
      if (y - leading < PAGE.margin) {
        pages.push(current);
        current = [];
        y = PAGE.height - PAGE.margin;
      }
      current.push({ kind: line.kind, text: piece });
      y -= leading;
    }
  }
  if (current.length || !pages.length) pages.push(current);
  return pages;
}

function contentStream(lines) {
  const parts = ['BT'];
  let y = PAGE.height - PAGE.margin;
  let font = null;
  const sizeFor = (kind) => (kind === 'h1' ? 16 : kind === 'h2' ? 12 : 9.5);
  const fontFor = (kind) => (kind === 'h1' || kind === 'h2' ? '/F2' : '/F1');

  for (const line of lines) {
    const size = sizeFor(line.kind);
    const want = fontFor(line.kind);
    const leading = line.kind === 'h1' ? 26 : line.kind === 'h2' ? 22 : line.kind === 'gap' ? 12 : 13;
    if (want !== font || size !== (size ?? null)) {
      parts.push(`${want} ${size} Tf`);
      font = want;
    }
    if (line.text) {
      parts.push(`1 0 0 1 ${PAGE.margin} ${y.toFixed(2)} Tm`);
      parts.push(`(${escapeText(line.text)}) Tj`);
    }
    y -= leading;
  }
  parts.push('ET');
  return parts.join('\n');
}

/** Build the PDF. Returns { bytes, pages, lineCount }. */
export function buildBuildPacketPDF(input) {
  const lines = buildPacketLines(input);
  const pages = paginate(lines);

  const objects = [];
  const addObj = (body) => {
    objects.push(body);
    return objects.length; // 1-based object number
  };

  const catalogNo = addObj('<< /Type /Catalog /Pages 2 0 R >>');
  const pagesNo = addObj(''); // placeholder, filled once kids are known
  const fontRegular = addObj('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
  const fontBold = addObj('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');

  const pageNos = [];
  const kids = [];
  for (const p of pages) {
    const stream = contentStream(p);
    const contentNo = addObj(`<< /Length ${Buffer.byteLength(stream, 'latin1')} >>\nstream\n${stream}\nendstream`);
    const pageNo = addObj(
      `<< /Type /Page /Parent ${pagesNo} 0 R /MediaBox [0 0 ${PAGE.width} ${PAGE.height}] ` +
        `/Resources << /Font << /F1 ${fontRegular} 0 R /F2 ${fontBold} 0 R >> >> /Contents ${contentNo} 0 R >>`
    );
    pageNos.push(pageNo);
    kids.push(`${pageNo} 0 R`);
  }

  objects[pagesNo - 1] = `<< /Type /Pages /Kids [${kids.join(' ')}] /Count ${pages.length} >>`;

  // Assemble with byte-accurate offsets.
  const chunks = [];
  let offset = 0;
  const offsets = [];
  const writeChunk = (s) => {
    const buf = Buffer.from(s, 'latin1');
    chunks.push(buf);
    offset += buf.length;
  };

  writeChunk('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n');
  objects.forEach((body, i) => {
    offsets.push(offset);
    writeChunk(`${i + 1} 0 obj\n${body}\nendobj\n`);
  });

  const xrefOffset = offset;
  let xref = `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  for (const off of offsets) xref += `${String(off).padStart(10, '0')} 00000 n \n`;
  writeChunk(xref);
  writeChunk(`trailer\n<< /Size ${objects.length + 1} /Root ${catalogNo} 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`);

  return { bytes: Buffer.concat(chunks), pages: pages.length, lineCount: lines.length, objects: objects.length };
}

/**
 * Independent structural check of the produced bytes: re-read the xref table from the raw
 * buffer and confirm every offset lands exactly on "<n> 0 obj".
 */
export function verifyPdf(bytes) {
  const text = Buffer.isBuffer(bytes) ? bytes.toString('latin1') : String(bytes);
  const problems = [];

  if (!text.startsWith('%PDF-')) problems.push('missing %PDF header');
  if (!text.trimEnd().endsWith('%%EOF')) problems.push('missing %%EOF trailer');

  const startxrefMatch = text.match(/startxref\s+(\d+)/);
  if (!startxrefMatch) {
    problems.push('no startxref');
    return { ok: false, problems, objectsChecked: 0 };
  }
  const xrefOffset = Number(startxrefMatch[1]);
  const atOffset = text.slice(xrefOffset, xrefOffset + 5);
  if (atOffset !== 'xref\n') problems.push(`startxref points to ${JSON.stringify(atOffset)}, not "xref"`);

  const xrefBody = text.slice(xrefOffset);
  const header = xrefBody.match(/xref\s+0\s+(\d+)\s/);
  if (!header) problems.push('malformed xref header');
  const count = header ? Number(header[1]) : 0;

  const entries = [...xrefBody.matchAll(/^(\d{10}) (\d{5}) ([nf])\s*$/gm)];
  if (entries.length !== count) problems.push(`xref has ${entries.length} entries, header says ${count}`);

  let objectsChecked = 0;
  entries.forEach(([, off, , type], i) => {
    if (type !== 'n') return;
    const objOffset = Number(off);
    const expected = `${i} 0 obj`;
    const actual = text.slice(objOffset, objOffset + expected.length);
    if (actual !== expected) {
      problems.push(`xref entry ${i} points to ${JSON.stringify(actual)}, expected ${JSON.stringify(expected)}`);
    } else {
      objectsChecked++;
    }
  });

  // Every declared object must exist.
  for (let i = 1; i < count; i++) {
    if (!text.includes(`\n${i} 0 obj`)) problems.push(`object ${i} declared but not present`);
  }

  return { ok: problems.length === 0, problems, objectsChecked, pages: (text.match(/\/Type \/Page[^s]/g) || []).length };
}
