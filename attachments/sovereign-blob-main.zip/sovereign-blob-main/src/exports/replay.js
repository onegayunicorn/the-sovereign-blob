/**
 * Conversation Replay (spec section 12).
 *
 * Purpose, in the spec's words: trust. Every "why is this 21 mm?" question is answered here.
 *
 * Which means the replay is only honest if it records the REJECTED steps too. A timeline that
 * jumps from "build me a bookshelf" to "21 mm, all good" is a sales document. The value is in
 * showing that 18 mm was tried, failed for a stated physical reason, and what the engine
 * offered instead — because that is the reasoning a person needs in order to trust the result,
 * and it is also the record that makes a wrong verdict debuggable.
 */

import { statusForScore } from '../proto/state.js';

const round = (n, d = 2) => (typeof n === 'number' ? Math.round(n * 10 ** d) / 10 ** d : n);

export function buildReplay({ project, result, anchors = [], anchorResult = null, overrides = {}, exports: exportMap = {}, physicalValidation = null }) {
  const at = new Date().toISOString();
  const cl = result.cutList;
  const cost = result.cost;
  const def = cl.checks.shelfDeflection;
  const entries = [];
  let seq = 0;
  const add = (kind, detail, extra = {}) => {
    entries.push({ seq: ++seq, at, kind, detail, ...extra });
  };

  // 1. What the user actually said. Recorded first and verbatim: everything after this is an
  //    interpretation of it, and the reader needs to be able to judge the interpretation
  //    against the original words.
  add('voice', `Voice input: "${result.utterance}"`, { raw: result.utterance });

  // 2. What was extracted, and critically, what was NOT stated by the user.
  const fromUser = [];
  const fromDefault = [];
  for (const [slot, s] of Object.entries(result.intent.slots ?? {})) {
    (s.source === 'user' ? fromUser : fromDefault).push(`${slot}=${s.value}`);
  }
  add(
    'intent',
    `Intent extracted: goal=${result.intent.kind}. Stated by user: ${fromUser.join(', ') || '(nothing)'}. Assumed from defaults: ${fromDefault.join(', ') || '(nothing)'}.`,
    { stated: fromUser, assumed: fromDefault, confidence: round(result.intent.confidence, 2) }
  );

  if ((result.intent.openQuestions ?? []).length) {
    add('intent', `Open questions raised: ${result.intent.openQuestions.join(' | ')}`, {
      openQuestions: result.intent.openQuestions
    });
  }

  // 3. Constraint changes requested.
  for (const m of result.intent.modifications ?? []) {
    add('constraint', `User asked to change ${m.slot} by ${m.delta > 0 ? '+' : ''}${m.delta}`, { modification: m });
  }
  for (const [slot, value] of Object.entries(overrides ?? {})) {
    add('constraint', `Override applied: ${slot} = ${value}`, { slot, value });
  }

  // 4. Engineering: the geometry that resulted.
  add(
    'engineering',
    `Geometry generated: ${cl.spec.widthMm} x ${cl.spec.heightMm} x ${cl.spec.depthMm} mm, ${cl.spec.shelves} horizontals, ${cl.spec.thicknessMm} mm material. Shelf clear span ${cl.spanMm} mm, clear bay ${cl.clearBayMm} mm, total mass ${cl.totalMassKg} kg.`,
    { spec: cl.spec, spanMm: cl.spanMm }
  );
  add(
    'engineering',
    `Joinery: ${cl.joinery.label}. Nesting: ${cl.nesting.carcassSheetCount} sheet(s) at ${Math.round((cl.nesting.carcass.overallUtilisation ?? 0) * 100)}% yield on a ${cl.nesting.carcass.sheet.lengthMm}x${cl.nesting.carcass.sheet.widthMm} sheet.`,
    { joinery: cl.joinery.id, sheets: cl.nesting.carcassSheetCount }
  );

  // 5. Reality: the verdict, WITH the rejected option.
  add(
    'reality',
    `Structural check: predicted long-term sag ${def.longTermMm} mm against a ${def.limitMm} mm allowance (${Math.round(def.utilisation * 100)}% of limit) — ${def.pass ? 'PASS' : 'FAIL'}.`,
    { predicted: def, verdict: def.pass ? 'PASS' : 'FAIL' }
  );
  if (!def.pass && cl.remedy) {
    const r = cl.remedy;
    const opts = [
      r.thickerPasses ? `${r.thickerSheetMm} mm stock → ${r.thickerDeflectionMm} mm` : null,
      r.midRailAtHalfSpanPasses ? `mid-rail at half span → ${r.midRailDeflectionMm} mm` : null,
      r.deeperShelfPasses ? `${r.deeperShelfMm} mm deep shelf → ${r.deeperShelfDeflectionMm} mm` : null
    ].filter(Boolean);
    add('reality', `Thickness ${cl.spec.thicknessMm} mm REJECTED. Corrections that pass: ${opts.join('; ') || 'none found'}.`, {
      remedy: r
    });
  }
  // Status is recomputed with the spec's bands, and a blocking anchor overrides the band —
  // the same two rules the manifest applies, so the replay cannot tell a different story
  // from the manifest it is describing.
  const bandStatus = statusForScore(result.reality.score);
  const status = (anchorResult?.blocking ?? []).length ? 'BLOCKED' : bandStatus;
  add(
    'reality',
    `Reality score ${Math.round(result.reality.score)}/100 → ${status}${status !== bandStatus ? ` (score band says ${bandStatus}, overridden by a locked anchor violation)` : ''}. Tip-over margin ${cl.checks.tipOver.margin}${cl.checks.tipOver.anchoredRequired ? ' — wall fixing required' : ''}. Racking ${cl.checks.racking.pass ? 'PASS' : 'FAIL'}.`,
    { score: result.reality.score, status, bandStatus }
  );
  if ((cost.unpriced ?? []).length) {
    add('reality', `Cost left partially unknown: no verified price for ${cost.unpriced.map((u) => u.label).join(', ')}. Total is a lower bound.`, {
      unpriced: cost.unpriced
    });
  }

  // 6. Anchors: advisory and blocking kept visibly separate.
  for (const a of anchors) {
    if (a.locked) add('anchor', `Anchor "${a.name}" is LOCKED at ${a.value} ${a.unit}.`, { anchor: a });
  }
  for (const v of anchorResult?.violations ?? []) {
    add(
      'anchor',
      `Anchor "${v.name}" ${v.blocking ? 'VIOLATED (locked — blocks the build)' : 'not met (advisory)'}: ${v.message} Correction: ${v.recommendation}`,
      { violation: v }
    );
  }

  // 7. Exports produced, then the physical result if there is one.
  for (const [format, file] of Object.entries(exportMap ?? {})) {
    if (file) add('export', `${format.toUpperCase()} generated: ${file}`, { format, file });
  }
  if (physicalValidation) {
    add('physical', `Physical validation recorded: ${JSON.stringify(physicalValidation)}`, { physicalValidation });
  } else {
    add('physical', 'Physical validation pending — the object has not been built and measured yet, so every number above is a prediction.');
  }

  return {
    replayVersion: '0.2',
    projectId: project.id,
    generatedAt: at,
    entries
  };
}
