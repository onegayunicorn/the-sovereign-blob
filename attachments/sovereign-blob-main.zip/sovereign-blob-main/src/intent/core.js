/**
 * Intent Core — turns speech text into an Intent Graph.
 *
 * IMPLEMENTATION HONESTY
 * This is a deterministic rule-and-gazetteer parser, not a language model. Sections
 * of the original concept claim the Blob "understands why"; what this actually does
 * is extract explicit slots and inferred priorities, and — critically — mark which
 * slots came from the user versus from defaults. A defaulted slot is not understanding,
 * so it lowers confidence and gets surfaced to the user as a question candidate.
 */

const NUMBER_WORDS = {
  one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10
};

const LENGTH_UNITS_MM = { mm: 1, millimetre: 1, millimetre_s: 1, cm: 10, m: 1000, metre: 1000, meter: 1000, in: 25.4, inch: 25.4, inches: 25.4, '"': 25.4, ft: 304.8, foot: 304.8, feet: 304.8 };

const KINDS = [
  { id: 'bookshelf', re: /\b(book ?shelf|bookcase|shelving|shelf|shelves|bookshelf)\b/i, template: 'bookshelf' },
  { id: 'table', re: /\b(table|desk|bench|workbench)\b/i, template: 'table' },
  { id: 'frame', re: /\b(frame|rack|stand|mount|cradle|enclosure|box)\b/i, template: 'frame' },
  { id: 'ui', re: /\b(app|ui|interface|widget|screen|dashboard)\b/i, template: 'ui' },
  { id: 'concept', re: /\b(theory|concept|simulation|physics|model)\b/i, template: 'concept' }
];

const MATERIAL_HINTS = [
  { re: /\b(birch|plywood|ply)\b/i, id: 'birch-plywood' },
  { re: /\b(mdf|fibreboard|particleboard|chipboard)\b/i, id: 'mdf' },
  { re: /\b(pine|solid wood|timber|oak|softwood|hardwood)\b/i, id: 'solid-pine' },
  { re: /\b(bamboo)\b/i, id: 'bamboo' },
  { re: /\b(steel|metal|iron)\b/i, id: 'steel-mild' },
  { re: /\b(aluminium|aluminum)\b/i, id: 'aluminium' }
];

const PROFILE_RULES = [
  { id: 'cost', label: 'Minimise cost', re: /\b(cheap|cheapest|budget|low cost|affordable|as little as possible|tight budget)\b/i },
  { id: 'storage', label: 'Maximise storage', re: /\b(as much storage as possible|maximi[sz]e storage|lots of storage|fit as many books|storage)\b/i },
  { id: 'space', label: 'Fit a small space', re: /\b(small apartment|tiny room|narrow space|small space|studio flat|tight space|corner)\b/i },
  { id: 'safety', label: 'Child / seismic safety', re: /\b(child|kid|toddler|baby|earthquake|seismic|safe|safety|tip[- ]?over)\b/i },
  { id: 'sustainability', label: 'Sustainability', re: /\b(reclaimed|sustainab|eco|recycled|low carbon|environment)\b/i },
  { id: 'aesthetic', label: 'Aesthetic direction', re: /\b(futuristic|modern|minimal|industrial|scandinavian|rustic|sleek|statement)\b/i },
  { id: 'knockdown', label: 'Must flat-pack / re-assemble', re: /\b(flat[- ]?pack|knock[- ]?down|take it apart|move house|demount)\b/i },
  { id: 'weight', label: 'Keep it light', re: /\b(light|lightweight|easy to move|one person)\b/i }
];

function parseLengths(text) {
  const out = [];
  // Pass 1: an explicit unit. The trailing \b on the unit token matters — without it
  // "5 minutes" parses as 5 metres.
  const re =
    /(\d+(?:[.,]\d+)?|one|two|three|four|five|six|seven|eight|nine|ten)\s*(?:(mm|millimetres?|cm|m|metres?|meters?|inches|inch|in|ft|feet|foot)\b|("))/gi;
  let m;
  while ((m = re.exec(text)) !== null) {
    const raw = m[1].toLowerCase();
    const value = NUMBER_WORDS[raw] ?? parseFloat(raw.replace(',', '.'));
    const unitRaw = m[2] ? m[2].toLowerCase() : '"';
    const unitKey = unitRaw.replace(/s$/, '');
    const factor = LENGTH_UNITS_MM[unitKey] ?? LENGTH_UNITS_MM[unitRaw] ?? 1;
    out.push({ valueMm: Math.round(value * factor), raw: m[0].trim(), unit: unitRaw, index: m.index });
  }

  // Pass 2: a dimension keyword with no unit — "1800 tall", "900 wide". Spoken input
  // almost never includes the unit, and silently defaulting these would be the single
  // most common way for the design to be wrong while looking confident.
  const bare = /(?<![\d.])(\d{2,5})\s*(tall|high|height|wide|width|deep|depth|long|length)\b/gi;
  while ((m = bare.exec(text)) !== null) {
    const valueMm = parseInt(m[1], 10);
    if (!out.some((o) => o.index === m.index || o.valueMm === valueMm)) {
      out.push({ valueMm, raw: m[0].trim(), unit: 'assumed-mm', index: m.index });
    }
  }

  out.sort((a, b) => a.index - b.index);
  return out;
}

/**
 * Assign measured values to slots using the nearest preceding noun.
 * "1800 tall and 900 wide" -> height=1800, width=900
 */
function assignDimensions(text, lengths) {
  const slots = { widthMm: null, heightMm: null, depthMm: null };
  const rules = [
    { slot: 'heightMm', re: /(tall|high|height)/ },
    { slot: 'widthMm', re: /(wide|width|across|long|length)/ },
    { slot: 'depthMm', re: /(deep|depth)/ }
  ];

  let prevEnd = 0;
  for (const l of lengths) {
    const raw = l.raw.toLowerCase();
    const after = text.slice(l.index + l.raw.length, l.index + l.raw.length + 14).toLowerCase();
    // Only the gap SINCE THE PREVIOUS measurement counts as "before". A wider window
    // makes one number steal another's keyword: in "1800 tall and 900 wide", a 22-char
    // lookback from "900" contains "tall" and would file 900 as the height.
    const gapBefore = text.slice(Math.max(prevEnd, l.index - 20), l.index).toLowerCase();

    let assigned = null;
    // Priority: the keyword inside the match itself, then immediately after it, then
    // the gap before it.
    for (const r of rules) if (r.re.test(raw)) { assigned = r.slot; break; }
    if (!assigned) for (const r of rules) if (r.re.test(after)) { assigned = r.slot; break; }
    if (!assigned) for (const r of rules) if (r.re.test(gapBefore)) { assigned = r.slot; break; }

    if (assigned && slots[assigned] == null) slots[assigned] = l.valueMm;
    prevEnd = l.index + l.raw.length;
  }
  // Fallback: infer slots from magnitude when the user just lists numbers.
  const leftovers = lengths.filter(
    (l) => l.valueMm !== slots.heightMm && l.valueMm !== slots.widthMm && l.valueMm !== slots.depthMm
  );
  for (const l of leftovers) {
    if (l.valueMm >= 700 && slots.heightMm == null) slots.heightMm = l.valueMm;
    else if (l.valueMm >= 400 && slots.widthMm == null) slots.widthMm = l.valueMm;
    else if (l.valueMm >= 150 && l.valueMm < 400 && slots.depthMm == null) slots.depthMm = l.valueMm;
  }
  return slots;
}

function parseShelves(text) {
  const m = /(\d+|one|two|three|four|five|six|seven|eight|nine|ten)\s*(?:fixed\s+)?(?:shelves|shelf|levels|tiers)\b/i.exec(text);
  if (!m) return null;
  const raw = m[1].toLowerCase();
  return NUMBER_WORDS[raw] ?? parseInt(raw, 10);
}

function parseBudget(text) {
  const m = /(?:under|below|less than|max|budget of|around|about)?\s*[$£€]\s?(\d+(?:[.,]\d+)?)/i.exec(text);
  if (m) return { value: parseFloat(m[1].replace(',', '.')), raw: m[0].trim() };
  return null;
}

export function parseIntent(text, options = {}) {
  const clean = String(text || '').trim();
  const lower = clean.toLowerCase();
  const lengths = parseLengths(clean);

  const kind = KINDS.find((k) => k.re.test(clean)) || { id: 'unknown', template: 'generic' };
  const materialHit = MATERIAL_HINTS.find((m) => m.re.test(clean));

  const constraints = {};
  for (const rule of PROFILE_RULES) {
    if (rule.re.test(clean)) constraints[rule.id] = { active: true, label: rule.label };
  }

  // A budget phrase without a number ("as cheap as possible") is still a cost signal,
  // but the numeric budget stays null rather than being invented.
  const money = parseBudget(clean);
  const budget = money ? money.value : null;

  const dims = assignDimensions(clean, lengths);
  const explicitShelves = parseShelves(clean);

  // Priorities start from the constraint profile, then get nudged by explicit numbers.
  const priorities = {
    storage: constraints.storage ? 95 : 60,
    cost: constraints.cost ? 90 : budget ? 85 : 40,
    sustainability: constraints.sustainability ? 80 : 30,
    safety: constraints.safety ? 90 : 50,
    aesthetics: constraints.aesthetic ? 70 : 40,
    portability: constraints.knockdown ? 80 : 20,
    fit: constraints.space ? 90 : 60
  };
  if (dims.heightMm && dims.heightMm < 1200) priorities.fit = Math.max(priorities.fit, 75);
  if (constraints.weight) priorities.portability = Math.max(priorities.portability, 75);

  const slots = {
    widthMm: { value: dims.widthMm ?? 900, source: dims.widthMm ? 'user' : 'default' },
    heightMm: { value: dims.heightMm ?? 1800, source: dims.heightMm ? 'user' : 'default' },
    depthMm: { value: dims.depthMm ?? 300, source: dims.depthMm ? 'user' : 'default' },
    shelves: { value: explicitShelves ?? 5, source: explicitShelves ? 'user' : 'default' },
    material: { value: materialHit ? materialHit.id : 'birch-plywood', source: materialHit ? 'user' : 'default' },
    budget: { value: budget, source: budget ? 'user' : 'absent' },
    anchored: { value: !!constraints.safety, source: constraints.safety ? 'user' : 'default' },
    knockdown: { value: !!constraints.knockdown, source: constraints.knockdown ? 'user' : 'default' },
    loadPerShelfKg: { value: 25, source: 'default' }
  };

  const userSlots = Object.values(slots).filter((s) => s.source === 'user').length;
  const totalSlots = Object.keys(slots).length;
  const confidence = Math.round((userSlots / totalSlots) * 100) / 100;

  const openQuestions = Object.entries(slots)
    .filter(([, s]) => s.source === 'default')
    .map(([k, s]) => ({ slot: k, assumed: s.value, question: questionFor(k, s.value) }));

  // Modification intents ("make it taller") are deltas against the current spec.
  //
  // These patterns deliberately require the COMPARATIVE or an explicit change verb.
  // A bare descriptive adjective is not an instruction: "shelves 300 deep" states a
  // depth, it does not ask for 50 mm more, and "a lower shelf" names a shelf position
  // rather than requesting a shorter unit. Both were false positives before this fix.
  const modifications = [];
  if (/\b(taller|make it higher|increase the height|raise the top)\b/i.test(lower)) modifications.push({ slot: 'heightMm', delta: +150 });
  if (/\b(shorter|make it lower|reduce the height|less tall)\b/i.test(lower)) modifications.push({ slot: 'heightMm', delta: -150 });
  if (/\b(wider|widen it|make it wider)\b/i.test(lower)) modifications.push({ slot: 'widthMm', delta: +150 });
  if (/\b(narrower|make it narrower|slimmer unit)\b/i.test(lower)) modifications.push({ slot: 'widthMm', delta: -150 });
  if (/\b(deeper|more depth|increase the depth|deeper shelves)\b/i.test(lower)) modifications.push({ slot: 'depthMm', delta: +50 });
  if (/\b(more shelves|another shelf|extra shelf|add a shelf)\b/i.test(lower)) modifications.push({ slot: 'shelves', delta: +1 });
  if (/\b(thicker|sturdier|stronger|beef it up)\b/i.test(lower)) modifications.push({ slot: 'thicknessMm', delta: +3, qualitative: 'requested thicker stock' });
  if (/\b(cheaper|cut the cost|reduce the cost|lower the cost|bring the cost down)\b/i.test(lower)) modifications.push({ slot: null, intent: 'reduce-cost' });

  // Location. SB-011 expects "current_view" for a deictic like "here", while spec section 7
  // shows "wall" for the same utterance; both are recorded in docs/SPEC-DEVIATIONS.md. A
  // deictic wins when present, because "here" is the user pointing at a specific place.
  const location = /\b(here|this wall|this spot|this space|right here)\b/i.test(clean)
    ? 'current_view'
    : /\bwall\b/i.test(clean)
      ? 'wall'
      : 'unspecified';

  return {
    utterance: clean,
    kind: kind.id,
    template: kind.template,
    location,
    slots,
    priorities,
    constraints,
    modifications,
    confidence,
    openQuestions,
    recognised: {
      dimensions: lengths.map((l) => l.raw),
      budgetRaw: money ? money.raw : null
    },
    graph: renderGraph(kind.id, slots, priorities)
  };
}

function questionFor(slot, assumed) {
  const map = {
    widthMm: `How wide should it be? Assuming ${assumed} mm.`,
    heightMm: `How tall should it be? Assuming ${assumed} mm.`,
    depthMm: `How deep should the shelves be? Assuming ${assumed} mm.`,
    shelves: `How many horizontal panels? Assuming ${assumed}.`,
    material: `Which material? Assuming ${assumed}.`,
    budget: 'Is there a budget? Without one, cost is tracked but not gated.',
    anchored: `Will this be fixed to the wall? Assuming ${assumed ? 'yes' : 'no'}.`,
    knockdown: `Does it need to flat-pack? Assuming ${assumed ? 'yes' : 'no'}.`,
    loadPerShelfKg: `How much weight per shelf? Assuming ${assumed} kg.`
  };
  return map[slot] || `Confirm ${slot}.`;
}

function renderGraph(kindId, slots, priorities) {
  const top = Object.entries(priorities).sort((a, b) => b[1] - a[1]).slice(0, 5);
  // Concrete values first, then the inferred priorities, with exactly one closing
  // branch at the end so the rendered tree is well-formed.
  const entries = [
    `size ${slots.widthMm.value} x ${slots.heightMm.value} x ${slots.depthMm.value} mm (${slots.widthMm.source === 'user' ? 'stated' : 'assumed'})`,
    `panels ${slots.shelves.value} (${slots.shelves.source === 'user' ? 'stated' : 'assumed'})`,
    `material ${slots.material.value} (${slots.material.source === 'user' ? 'stated' : 'assumed'})`,
    ...top.map(([k, v]) => `${k} priority ${v}%`)
  ];
  const lines = [kindId.toUpperCase()];
  entries.forEach((e, i) => lines.push(`${i === entries.length - 1 ? '└─' : '├─'} ${e}`));
  return lines.join('\n');
}

/**
 * Apply a modification list to a spec, returning a new spec plus the reasoning trail.
 */
export function applyModifications(spec, modifications) {
  const next = { ...spec };
  const applied = [];
  for (const mod of modifications) {
    if (mod.slot && typeof mod.delta === 'number') {
      const before = next[mod.slot];
      next[mod.slot] = Math.max(1, before + mod.delta);
      applied.push(`${mod.slot}: ${before} -> ${next[mod.slot]}`);
    } else if (mod.intent === 'reduce-cost') {
      next.joinery = 'dowel';
      next.backThicknessMm = 3;
      applied.push('reduced cost: dowel joinery and a thinner back panel');
    }
  }
  return { spec: next, applied };
}
