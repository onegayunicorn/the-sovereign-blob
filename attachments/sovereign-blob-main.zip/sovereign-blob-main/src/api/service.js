/**
 * Internal API contracts (spec section 14) — the logic behind the four endpoints.
 *
 * Kept out of the HTTP layer on purpose: the endpoint contract and the behaviour are separate
 * concerns, and the behaviour is what the tests exercise. The HTTP layer only parses, calls,
 * and serialises.
 *
 * Response envelopes match the spec exactly (`projectId`/`status`, `designId`/`status`,
 * `realityScore`/`status`, `exports`), because a client written against the spec must not
 * need changes to talk to this implementation.
 */

import { mkdirSync, writeFileSync, readFileSync, existsSync, readdirSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

import { runPipeline } from '../pipeline.js';
import { buildAssemblySequence } from '../engine/assembly.js';
import { buildSBM, validateSBM } from '../sbm/manifest.js';
import { buildReplay } from '../exports/replay.js';
import { buildBuildPacketPDF } from '../exports/pdf.js';
import { toDXF, toCutListCSV } from '../export/index.js';
import { defaultAnchors, validateAnchors, lockAnchor, unlockAnchor, attemptAnchorChange } from '../reality/anchors.js';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..', '..');
const PROJECTS_DIR = join(ROOT, 'output', 'projects');

/**
 * Unit sizing when a wall is measured. These two constants are a DELIBERATE DESIGN RULE, not a
 * measurement, so they are named and documented rather than buried:
 *   - width = measured wall width (a fitted shelf spans the wall)
 *   - height = wall height - 150 mm clearance (room for skirting, a cornice, and getting it
 *     upright without scraping the ceiling during installation)
 * This is the only place the wall influences the unit's dimensions. It is not auto-applied
 * unless `fitToWall` is set, because silently resizing someone's shelf is exactly the kind of
 * hidden behaviour the Reality Anchor model exists to prevent.
 */
export const FIT_TO_WALL = { topClearanceMm: 150 };

const slug = (s) =>
  String(s || 'project')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '') || 'project';

function ensureDir(dir) {
  mkdirSync(dir, { recursive: true });
  return dir;
}

function projectDir(id) {
  return join(PROJECTS_DIR, id);
}

function nextId(prefix, width = 3) {
  ensureDir(PROJECTS_DIR);
  const existing = existsSync(PROJECTS_DIR) ? readdirSync(PROJECTS_DIR).filter((d) => d.startsWith(prefix)) : [];
  const max = existing.reduce((acc, d) => {
    const n = Number(d.replace(`${prefix}-`, ''));
    return Number.isFinite(n) ? Math.max(acc, n) : acc;
  }, 0);
  return `${prefix}-${String(max + 1).padStart(width, '0')}`;
}

function readJson(path) {
  return JSON.parse(readFileSync(path, 'utf8'));
}

// ---------------------------------------------------------------------------
// POST /api/project/create
// ---------------------------------------------------------------------------
export function createProject({ name, objectType = 'bookshelf', region = null, id = null } = {}) {
  if (!name || typeof name !== 'string') {
    return { error: 'name is required', status: 400, details: ['body: { "name": "Room Shelf" }'] };
  }
  const projectId = id ?? nextId('proj');
  const project = {
    id: projectId,
    name,
    objectType,
    region,
    created: new Date().toISOString(),
    version: 1
  };
  ensureDir(projectDir(projectId));
  writeFileSync(join(projectDir(projectId), 'project.json'), JSON.stringify(project, null, 2));
  return { projectId, status: 'created', project };
}

// ---------------------------------------------------------------------------
// POST /api/design/generate
// ---------------------------------------------------------------------------
export function generateDesign({ projectId, intent = {}, room = null, fitToWall = null, anchors = null } = {}) {
  const project = projectId && existsSync(join(projectDir(projectId), 'project.json'))
    ? readJson(join(projectDir(projectId), 'project.json'))
    : projectId
      ? { id: projectId, name: 'Untitled', created: new Date().toISOString(), version: 1 }
      : null;

  if (!project) return { error: 'projectId is required — create a project first', status: 400 };

  const goal = intent.goal ?? project.objectType ?? 'bookshelf';
  const roomScan = room
    ? {
        wallWidthMm: Number(room.width ?? room.wallWidthMm ?? 0) || 0,
        wallHeightMm: Number(room.height ?? room.wallHeightMm ?? 0) || 0,
        roomWidthMm: Number(room.roomWidth ?? room.width ?? 0) || 0,
        roomHeightMm: Number(room.roomHeight ?? room.height ?? 0) || 0,
        depthMm: Number(room.depth ?? 0) || 0,
        confidence: Number.isFinite(room.confidence) ? room.confidence : 0.5,
        source: room.source ?? 'api-supplied',
        obstructions: room.obstructions ?? []
      }
    : null;

  // Does the request state its own dimensions? If not, a measured wall may drive them.
  const stated = ['widthMm', 'heightMm', 'depthMm'].filter((k) => intent[k] != null || (intent.constraints ?? {})[k] != null);
  // fitToWall is OPT-IN and off by default. Measured evidence: spanning an 1800 mm wall with
  // 18 mm plywood gives a 1764 mm shelf span, which sags ~39 mm long-term against a 4.9 mm
  // allowance — and NO stocked thickness passes (21 mm gives ~25 mm). Fitting the wall is not
  // free: it needs intermediate supports, which this generator does not yet add. Defaulting the
  // fit on would therefore emit wall-to-wall designs that the manifest immediately marks FAIL,
  // which teaches the user to distrust the FAIL rather than the design.
  const applyFit = fitToWall === null ? false : Boolean(fitToWall);
  const fitWarning =
    applyFit && roomScan?.wallWidthMm && (roomScan.wallWidthMm - 2 * (overrides.thicknessMm ?? 18)) > 900
      ? `Fitted width ${roomScan.wallWidthMm} mm gives a shelf span over 900 mm. At that span no stocked plywood thickness passes the deflection check without intermediate supports; expect the structural check to fail and add supports.`
      : null;

  const overrides = {};
  for (const k of ['widthMm', 'heightMm', 'depthMm', 'shelves', 'thicknessMm', 'material', 'budget', 'loadPerShelfKg', 'anchored']) {
    if (intent[k] != null) overrides[k] = intent[k];
  }
  if (applyFit && roomScan?.wallWidthMm) {
    overrides.widthMm = Math.round(roomScan.wallWidthMm);
    if (roomScan.wallHeightMm) overrides.heightMm = Math.round(roomScan.wallHeightMm - FIT_TO_WALL.topClearanceMm);
  }

  const utterance = intent.transcript ?? `build me a ${goal}`;
  const result = runPipeline(utterance, {
    region: project.region ?? undefined,
    specOverrides: overrides
  });

  const assembly = buildAssemblySequence(result.cutList);
  const designId = nextId('design');
  const anchorSet = anchors?.length
    ? anchors
    : defaultAnchors({ spec: { ...result.cutList.spec, wallMounted: true }, cutList: result.cutList, cost: result.cost, room: roomScan });

  const sbm = buildSBM({
    project: { ...project, objectType: goal },
    result: { ...result, assembly },
    roomScan,
    overrides,
    anchors: anchorSet
  });

  const validation = validateSBM(sbm, {
    cutList: result.cutList,
    cost: result.cost,
    spec: result.cutList.spec,
    room: roomScan
  });

  const dir = ensureDir(projectDir(project.id));
  const design = {
    designId,
    projectId: project.id,
    createdAt: new Date().toISOString(),
    utterance,
    overrides,
    appliedFitToWall: applyFit,
    roomScan,
    sbm,
    validation,
    status: 'generated',
    // Everything an export needs, stored WITH the design. If export had to re-derive geometry
    // from the current engine build, a later engine change would silently alter an export of an
    // older design — and a cut list that changes after the fact is worse than no cut list.
    build: { result, assembly }
  };
  writeFileSync(join(dir, `${designId}.json`), JSON.stringify(design, null, 2));
  writeFileSync(join(dir, 'latest-design.json'), JSON.stringify({ designId }, null, 2));

  return {
    designId,
    status: 'generated',
    projectId: project.id,
    realityScore: sbm.reality.score,
    realityStatus: sbm.reality.status,
    validation,
    warnings: fitWarning ? [fitWarning] : []
  };
}

function loadDesign(designId) {
  if (!existsSync(PROJECTS_DIR)) return null;
  for (const p of readdirSync(PROJECTS_DIR)) {
    const f = join(PROJECTS_DIR, p, `${designId}.json`);
    if (existsSync(f)) return { path: f, design: readJson(f) };
  }
  return null;
}

// ---------------------------------------------------------------------------
// POST /api/reality/evaluate
// ---------------------------------------------------------------------------
export function evaluateReality({ designId, anchors = null } = {}) {
  const found = designId ? loadDesign(designId) : null;
  if (!found) return { error: `unknown designId "${designId}"`, status: 404 };

  const sbm = { ...found.design.sbm };
  if (anchors) sbm.anchors = anchors;

  // Re-validate against the design's own stored geometry, so an evaluate call reflects the
  // anchor set the caller just sent rather than the one that happened to be saved.
  const result = found.design.build?.result;
  const anchorResult = result
    ? validateAnchors(sbm.anchors, {
        spec: result.cutList.spec,
        cutList: result.cutList,
        cost: result.cost,
        room: found.design.roomScan
      })
    : { violations: [], blocking: [], valid: true, warnings: [] };

  // A violated LOCKED anchor forces BLOCKED regardless of the score band (spec section 10).
  const status = anchorResult.blocking.length ? 'BLOCKED' : sbm.reality.status;
  const blockers = anchorResult.blocking.map((v) => `${v.name}: ${v.message} → ${v.recommendation}`);
  const anchorViolations = anchorResult.violations.map((v) => ({
    anchorId: v.anchorId,
    name: v.name,
    locked: v.locked,
    message: v.message,
    recommendation: v.recommendation
  }));

  const updated = {
    ...sbm,
    reality: { ...sbm.reality, status, blockers: blockers.length ? blockers : sbm.reality.blockers },
    audit: { ...sbm.audit, anchorViolations }
  };

  writeFileSync(found.path, JSON.stringify({ ...found.design, sbm: updated, lastEvaluated: new Date().toISOString() }, null, 2));

  return {
    realityScore: updated.reality.score,
    status,
    confidence: updated.reality.confidence,
    warnings: updated.reality.warnings,
    blockers: updated.reality.blockers,
    checks: updated.reality.checks,
    anchorsValid: anchorResult.valid,
    designId
  };
}

// ---------------------------------------------------------------------------
// POST /api/export
// ---------------------------------------------------------------------------
export function exportPackage({ projectId, designId = null, formats = ['pdf', 'dxf', 'sbm', 'replay'] } = {}) {
  if (!projectId) return { error: 'projectId is required', status: 400 };
  const dir = projectDir(projectId);
  if (!existsSync(dir)) return { error: `unknown projectId "${projectId}"`, status: 404 };

  const latest = existsSync(join(dir, 'latest-design.json')) ? readJson(join(dir, 'latest-design.json')) : null;
  const id = designId ?? latest?.designId;
  const found = id ? loadDesign(id) : null;
  if (!found) return { error: `no design found for project "${projectId}"`, status: 404 };

  const { design } = found;
  const sbm = design.sbm;
  const project = readJson(join(dir, 'project.json'));
  const base = slug(project.name);

  // The spec gates export on schema + reality + anchor validation all passing. A BLOCKED design
  // must not silently produce a build packet, so the refusal is explicit and carries the reason.
  const validation = validateSBM(sbm, {});
  if (!validation.schemaValid) {
    return {
      error: 'export refused: manifest failed schema validation',
      status: 422,
      details: validation.errors
    };
  }

  const written = [];
  const formatsWanted = new Set(formats);

  if (formatsWanted.has('sbm')) {
    const name = `${base}.sbm.json`;
    writeFileSync(join(dir, name), JSON.stringify(sbm, null, 2));
    written.push(name);
  }
  const { result, assembly } = design.build ?? {};
  if (!result) {
    return {
      error: 'export refused: this design was stored without its geometry, so nothing can be exported from it',
      status: 422,
      details: ['Regenerate with /api/design/generate, which stores the build inputs alongside the manifest.']
    };
  }

  if (formatsWanted.has('replay')) {
    const name = `${base}-replay.json`;
    const anchorResult = validateAnchors(sbm.anchors, {
      spec: result.cutList.spec,
      cutList: result.cutList,
      cost: result.cost,
      room: design.roomScan
    });
    const replay = buildReplay({
      project,
      result: { ...result, assembly },
      anchors: sbm.anchors,
      anchorResult,
      overrides: design.overrides ?? {},
      exports: { pdf: sbm.exports.pdf, dxf: sbm.exports.dxf, replay: sbm.exports.replay, sbm: sbm.exports.sbm }
    });
    writeFileSync(join(dir, name), JSON.stringify(replay, null, 2));
    written.push(name);
  }
  if (formatsWanted.has('dxf')) {
    const name = `${base}.dxf`;
    writeFileSync(join(dir, name), toDXF(result.cutList));
    written.push(name);
  }
  if (formatsWanted.has('csv')) {
    const name = `${base}-cut-list.csv`;
    writeFileSync(join(dir, name), toCutListCSV(result.cutList, { generatedAt: new Date().toISOString() }));
    written.push(name);
  }
  if (formatsWanted.has('pdf')) {
    const name = `${base}.pdf`;
    const pdf = buildBuildPacketPDF({ sbm, result, assembly });
    writeFileSync(join(dir, name), pdf.bytes);
    written.push(name);
  }

  return { exports: written, projectId, designId: id, validation };
}

export function loadProjectState(id) {
  const dir = projectDir(id);
  if (!existsSync(dir)) return null;
  const project = existsSync(join(dir, 'project.json')) ? readJson(join(dir, 'project.json')) : null;
  const latest = existsSync(join(dir, 'latest-design.json')) ? readJson(join(dir, 'latest-design.json')) : null;
  const design = latest ? loadDesign(latest.designId)?.design : null;
  return { project, designId: latest?.designId ?? null, design };
}

export { lockAnchor, unlockAnchor, attemptAnchorChange, validateAnchors };
export { PROJECTS_DIR };
