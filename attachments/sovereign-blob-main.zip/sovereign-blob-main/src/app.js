/**
 * UI controller. Talks to the local bridge; never touches the engine directly, so the
 * numbers on screen are the numbers the CLI and the tests produce.
 *
 * Voice: uses the browser SpeechRecognition API when available. That API is NOT
 * guaranteed to be on-device — in Chrome, recognition is typically sent to a Google
 * server. The app therefore treats voice as a convenience layer, never as the only
 * input, and says which input produced the current design. Typed input is fully local.
 */

import { drawField, drawPlan, PALETTE } from './blob/renderer.js';

const $ = (sel) => document.querySelector(sel);

const state = {
  boot: null,
  result: null,
  room: null,
  specOverrides: {},
  progress: 0,
  animating: false,
  blobFrame: null,
  reading: null
};

const els = {
  canvas: $('#blob'),
  transcript: $('#transcript'),
  runBtn: $('#run'),
  micBtn: $('#mic'),
  micState: $('#mic-state'),
  score: $('#score'),
  band: $('#band'),
  stages: $('#stages'),
  design: $('#design'),
  structure: $('#structure'),
  cost: $('#cost'),
  cutlist: $('#cutlist'),
  assembly: $('#assembly'),
  issues: $('#issues'),
  questions: $('#questions'),
  outputs: $('#outputs'),
  vendor: $('#vendor'),
  sensors: $('#sensors'),
  rfq: $('#rfq'),
  dream: $('#dream'),
  dreamOut: $('#dream-out'),
  controls: $('#controls'),
  inputNote: $('#input-note')
};

// ---------------------------------------------------------------------------
// boot
// ---------------------------------------------------------------------------
init();

async function init() {
  try {
    state.boot = await (await fetch('/api/bootstrap')).json();
  } catch (err) {
    els.inputNote.textContent = 'Bridge unreachable. Start it with: npm start';
    return;
  }
  renderBoot(state.boot);
  bindControls();
  startBlobIdle();
  subscribeTelemetry();
  els.runBtn.addEventListener('click', () => run(els.transcript.value, 'typed'));
  els.transcript.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      run(els.transcript.value, 'typed');
    }
  });
  els.micBtn.addEventListener('click', startVoice);
  els.dream.addEventListener('click', askDream);
  window.addEventListener('resize', () => draw());
  if (state.boot.latest) {
    els.transcript.value = state.boot.latest.utterance || '';
    paint(state.boot.latest);
  }
}

function renderBoot(boot) {
  els.controls.innerHTML = '';
  const rows = [
    { key: 'widthMm', label: 'Width (mm)', value: 900 },
    { key: 'heightMm', label: 'Height (mm)', value: 1800 },
    { key: 'depthMm', label: 'Depth (mm)', value: 300 },
    { key: 'shelves', label: 'Horizontals', value: 5 },
    { key: 'thicknessMm', label: 'Stock (mm)', value: 18 }
  ];
  for (const r of rows) {
    const wrap = document.createElement('label');
    wrap.className = 'field';
    wrap.innerHTML = `<span>${r.label}</span><input type="number" id="ctl-${r.key}" value="${r.value}">`;
    els.controls.appendChild(wrap);
    wrap.querySelector('input').addEventListener('change', (e) => {
      state.specOverrides[r.key] = Number(e.target.value);
    });
  }
  els.inputNote.textContent = boot.priceBook
    ? `price book ${boot.priceBook.asOf} · ${boot.priceBook.items} lines · ${boot.services.length} services registered`
    : '';
}

function bindControls() {
  $('#room-toggle').addEventListener('click', () => {
    state.room = state.room ? null : { widthMm: 1500, heightMm: 2400, depthMm: 2200, doorWidthMm: 760, doorHeightMm: 1980, skirtingHeightMm: 90, obstructions: [], source: 'manual', confidence: 1 };
    $('#room-toggle').textContent = state.room ? 'Room scan: ON' : 'Room scan: off';
  });
}

// ---------------------------------------------------------------------------
// run
// ---------------------------------------------------------------------------
async function run(utterance, source) {
  const text = String(utterance || '').trim();
  if (!text) return;
  els.runBtn.disabled = true;
  els.runBtn.textContent = 'forming…';
  startBlobIdle();
  const t0 = performance.now();
  try {
    const res = await fetch('/api/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ utterance: text, specOverrides: state.specOverrides, room: state.room })
    });
    const data = await res.json();
    if (data.error) throw new Error(data.error);
    animateTo(data, performance.now() - t0, source);
  } catch (err) {
    els.inputNote.textContent = `run failed: ${err.message}`;
  } finally {
    els.runBtn.disabled = false;
    els.runBtn.textContent = 'Form it';
  }
}

async function askDream() {
  const utterance = els.transcript.value.trim() || 'build me a bookshelf';
  els.dreamOut.textContent = 'exploring variants…';
  try {
    const dream = await (await fetch('/api/dream', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ utterance, specOverrides: state.specOverrides })
    })).json();
    els.dreamOut.innerHTML = `<div class="muted">${dream.explored} variants recomputed while you paused</div>` +
      dream.best.map((b) => `<div class="row"><code>${escapeHtml(JSON.stringify(b.change))}</code><span>${b.score} <em>${b.band}</em></span></div>`).join('');
  } catch (err) {
    els.dreamOut.textContent = `dream state failed: ${err.message}`;
  }
}

// ---------------------------------------------------------------------------
// blob animation
// ---------------------------------------------------------------------------
function startBlobIdle() {
  state.animating = false;
  const c = els.canvas;
  const ctx = c.getContext('2d');
  const t0 = performance.now();
  cancelAnimationFrame(state.blobFrame);
  const idle = () => {
    if (state.animating) return;
    const t = (performance.now() - t0) / 1000;
    const nodes = idleNodes(t);
    drawField(ctx, nodes, { width: c.width, height: c.height, colour: PALETTE.primary, progress: 0 });
    state.blobFrame = requestAnimationFrame(idle);
  };
  idle();
}

function idleNodes(t) {
  const nodes = [];
  for (let i = 0; i < 9; i++) {
    nodes.push({
      x: 0.5 + 0.22 * Math.cos(t * 0.55 + i * 0.7),
      y: 0.5 + 0.22 * Math.sin(t * 0.42 + i * 1.1),
      r: 0.09 + 0.02 * Math.sin(t + i),
      w: 0.8
    });
  }
  return nodes;
}

function animateTo(data, tookMs, source) {
  state.animating = true;
  cancelAnimationFrame(state.blobFrame);
  const c = els.canvas;
  const ctx = c.getContext('2d');
  const start = performance.now();
  const duration = 900;
  const colour = data.reality.colour;

  const targetNodes = shapeNodes(data);

  const frame = () => {
    const t = Math.min(1, (performance.now() - start) / duration);
    const eased = t * t * (3 - 2 * t);
    if (t < 1) {
      drawField(ctx, targetNodes, { width: c.width, height: c.height, colour, progress: eased * 0.85 });
      state.blobFrame = requestAnimationFrame(frame);
      return;
    }
    state.animating = false;
    paint(data);
    paintBlob(targetNodes, colour, 1);
  };
  frame();
}

function shapeNodes(data) {
  // Mirror the shape program the server used, from the same spec, so the settled visual
  // matches the geometry exactly. Sampling rather than a second shape definition.
  const { widthMm, heightMm, shelves } = data.spec;
  const aspect = Math.min(1.6, Math.max(0.5, heightMm / widthMm));
  const nodes = [];
  const cols = aspect > 1.05 ? [0.16, 0.84] : [0.1, 0.9];
  for (const vx of cols) {
    for (let i = 0; i < 9; i++) nodes.push({ x: vx, y: 0.08 + (i / 8) * 0.84, r: 0.045, w: 1 });
  }
  for (let i = 0; i < shelves; i++) {
    const y = 0.08 + (shelves === 1 ? 0.5 : i / (shelves - 1)) * 0.84;
    for (let j = 0; j < 7; j++) nodes.push({ x: 0.16 + (j / 6) * 0.68, y, r: 0.045, w: 1 });
  }
  return nodes;
}

function paintBlob(nodes, colour, progress) {
  drawField(els.canvas.getContext('2d'), nodes, { width: els.canvas.width, height: els.canvas.height, colour, progress });
  // fade the settled plan over the top, so the visual closes the loop with the cut list
  const plan = state.result?.cutList?.plan;
  if (plan && progress >= 1) {
    const ctx = els.canvas.getContext('2d');
    ctx.globalAlpha = 0.55;
    drawPlan(ctx, plan, { width: els.canvas.width, height: els.canvas.height, colour, showDimensions: false });
    ctx.globalAlpha = 1;
  }
}

// ---------------------------------------------------------------------------
// panels
// ---------------------------------------------------------------------------
function paint(data) {
  state.result = data;
  const { reality, cutList, cost, intent } = data;

  els.score.textContent = reality.score;
  els.score.style.color = reality.colour;
  els.score.style.borderColor = reality.colour;
  els.band.textContent = `${reality.band} · ${reality.status}`;
  els.band.style.color = reality.colour;

  els.stages.innerHTML = data.stages.map((s) => `
    <div class="stage">
      <span class="dot" style="background:${s.colour}"></span>
      <span class="name">${escapeHtml(s.stage)}</span>
      <span class="val" style="color:${s.colour}">${s.score}</span>
      <span class="note">${escapeHtml(s.note)}</span>
    </div>`).join('');

  els.design.innerHTML = `
    <div class="kv"><span>intent</span><b>${escapeHtml(intent.kind)} · ${Math.round(intent.confidence * 100)}% stated</b></div>
    <pre class="graph">${escapeHtml(intent.graph)}</pre>
    <div class="kv"><span>size</span><b>${data.spec.widthMm} × ${data.spec.heightMm} × ${data.spec.depthMm} mm</b></div>
    <div class="kv"><span>panels</span><b>${data.spec.shelves} horizontals · clear bay ${cutList.clearBayMm} mm</b></div>
    <div class="kv"><span>material</span><b>${escapeHtml(cutList.material.label)} @ ${data.spec.thicknessMm} mm</b></div>
    <div class="kv"><span>joinery</span><b>${escapeHtml(cutList.joinery.label)}</b></div>
    <div class="reason">${escapeHtml(cutList.joinery.selectedBecause)}</div>
    <div class="kv"><span>mass</span><b>${cutList.totalMassKg} kg</b></div>`;

  const d = cutList.checks.shelfDeflection;
  els.structure.innerHTML = `
    <div class="kv"><span>shelf span</span><b>${cutList.spanMm} mm</b></div>
    <div class="kv"><span>long-term sag</span><b style="color:${d.pass ? PALETTE.secondary : PALETTE.fail}">${d.longTermMm} mm / ${d.limitMm} mm ${d.pass ? 'PASS' : 'FAIL'}</b></div>
    <div class="kv"><span>span / deflection</span><b>L/${d.spanRatio}</b></div>
    <div class="kv"><span>tip-over margin</span><b style="color:${cutList.checks.tipOver.pass ? PALETTE.secondary : PALETTE.fail}">${cutList.checks.tipOver.margin}${cutList.checks.tipOver.anchoredRequired ? ' (anchor required)' : ''}</b></div>
    <div class="kv"><span>racking</span><b>${escapeHtml(cutList.checks.racking.mechanism)}</b></div>
    <div class="kv"><span>sheets</span><b>${cutList.nesting.carcassSheetCount} carcass (${Math.round(cutList.nesting.carcass.overallUtilisation * 100)}% yield)${cutList.nesting.backSheetCount ? ` + ${cutList.nesting.backSheetCount} back` : ''}</b></div>
    ${cutList.remedy ? `<div class="reason">${remedyText(cutList.remedy)}</div>` : ''}`;

  els.cost.innerHTML = `
    <div class="kv total"><span>priced subtotal</span><b>${cost.total} ${cost.currency}</b></div>
    <div class="muted">price book ${cost.asOf} · ${cost.lines.length} priced · ${cost.unpriced.length} unpriced</div>
    <table>${cost.lines.map((l) => `
      <tr><td>${l.qty} ×</td><td>${escapeHtml(l.label)}</td><td class="num">${l.lineTotal} ${l.currency}</td></tr>
      ${l.basisMismatch ? `<tr class="warn"><td></td><td colspan="2">bulk tier MOQ ${l.moq} — not buyable at this quantity</td></tr>` : ''}
    `).join('')}</table>
    ${cost.unpriced.map((u) => `<div class="warn">unpriced: ${escapeHtml(u.label)} — ${escapeHtml(u.reason)}</div>`).join('')}
    ${cost.tools.length ? `<div class="muted">tools (one-off): ${cost.tools.map((t) => `${escapeHtml(t.label)} ${t.lineTotal} ${t.currency}`).join(', ')}</div>` : ''}`;

  els.cutlist.innerHTML = `<table>
    <tr><th>part</th><th class="num">L</th><th class="num">W</th><th class="num">T</th><th class="num">qty</th><th>banded</th></tr>
    ${cutList.parts.map((p) => `<tr>
      <td>${escapeHtml(p.label)}</td><td class="num">${p.lengthMm}</td><td class="num">${p.widthMm}</td>
      <td class="num">${p.thicknessMm}</td><td class="num">${p.qty}</td><td>${escapeHtml((p.edgesBanded || []).join('+') || '—')}</td>
    </tr>`).join('')}
    <tr class="muted"><td colspan="6">fasteners: ${cutList.fasteners.map((f) => `${f.count} × ${escapeHtml(f.label)}`).join(' · ') || 'none'} · edge banding ${cutList.edgeBandingMm} mm</td></tr>
  </table>`;

  els.assembly.innerHTML = data.assembly.steps.map((s) => `
    <details><summary>${s.step}. ${escapeHtml(s.title)}</summary>
      <p>${escapeHtml(s.detail)}</p>
      <p class="reason">${escapeHtml(s.reason)}</p>
      <p class="muted">tools: ${escapeHtml((s.tools || []).join(', ') || 'none')}</p>
    </details>`).join('');

  els.issues.innerHTML = [
    ...reality.issues.map((i) => `<div class="issue">${escapeHtml(i)}</div>`),
    ...reality.mitigations.map((m) => `<div class="fix">${escapeHtml(m)}</div>`),
    ...cutList.flags.map((f) => `<div class="flag ${f.level}">[${f.code}] ${escapeHtml(f.message)}</div>`)
  ].join('') || '<div class="muted">no blocking issues</div>';

  els.questions.innerHTML = data.openQuestions.length
    ? data.openQuestions.map((q) => `<div class="q">${escapeHtml(q.question)}</div>`).join('')
    : '<div class="muted">every slot was stated by you</div>';

  els.outputs.innerHTML = (data.files || []).map((f) => `<a href="/api/output/${f}" target="_blank">${f}</a>`).join('') +
    `<a href="/api/output/latest.json" target="_blank">latest.json</a>`;

  els.vendor.innerHTML = data.vendor.routes.map((r) => `
    <div class="route">
      <b>${escapeHtml(r.itemKey)}</b>
      <span class="pill">${escapeHtml(r.route)}</span>
      <span class="muted">${escapeHtml(r.action || r.reason)}</span>
      ${r.url ? `<a href="${r.url}" target="_blank" rel="noopener">listing</a>` : ''}
    </div>`).join('');

  els.rfq.textContent = data.vendor.rfq.body;
  els.sensors.dataset.pending = '1';
  renderSensors();
  paintBlob(shapeNodes(data), reality.colour, 1);
  els.inputNote.textContent = `generated ${new Date(data.generatedAt).toLocaleTimeString()} · ${data.files.length} files written to output/`;
}

function remedyText(remedy) {
  const parts = [];
  if (remedy.thickerPasses) parts.push(`${remedy.thickerSheetMm} mm stock → ${remedy.thickerDeflectionMm} mm`);
  if (remedy.midRailAtHalfSpanPasses) parts.push(`mid-rail → ${remedy.midRailDeflectionMm} mm`);
  if (remedy.deeperShelfPasses) parts.push(`shelf depth ${remedy.deeperShelfMm} mm → ${remedy.deeperShelfDeflectionMm} mm`);
  return parts.length ? `Remedies: ${parts.join(' · ')}` : 'No single-parameter remedy works.';
}

// ---------------------------------------------------------------------------
// voice
// ---------------------------------------------------------------------------
function startVoice() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) {
    els.micState.textContent = 'no speech API in this browser — type instead';
    return;
  }
  const rec = new SR();
  rec.lang = navigator.language || 'en-US';
  rec.interimResults = true;
  rec.continuous = false;
  els.micState.textContent = 'listening… (browser STT may use a network service)';
  rec.onresult = (e) => {
    const text = Array.from(e.results).map((r) => r[0].transcript).join('');
    els.transcript.value = text;
    if (e.results[e.results.length - 1].isFinal) {
      els.micState.textContent = 'captured (via browser speech API)';
      run(text, 'voice');
    }
  };
  rec.onerror = (e) => {
    els.micState.textContent = `speech error: ${e.error}`;
  };
  rec.start();
}

// ---------------------------------------------------------------------------
// telemetry
// ---------------------------------------------------------------------------
function subscribeTelemetry() {
  const es = new EventSource('/api/stream');
  es.addEventListener('telemetry', (e) => {
    const data = JSON.parse(e.data);
    state.reading = data.reading;
    state.window = data.window;
    renderSensors();
  });
  es.onerror = () => {
    els.sensors.innerHTML = '<div class="warn">telemetry stream lost — is the node posting?</div>';
  };
}

function renderSensors() {
  if (!state.reading) {
    els.sensors.innerHTML = `<div class="muted">no sensor node connected. The ESP32 node POSTs to /api/telemetry every 5 s. Configure firmware/esp32-sensor-node and set its host to this bridge.</div>`;
    return;
  }
  const r = state.reading;
  els.sensors.innerHTML = `
    <div class="kv"><span>node</span><b>${escapeHtml(r.deviceId)} · ${r.ageSeconds}s ago</b></div>
    ${Object.entries(r.values).map(([k, v]) => `<div class="kv"><span>${k}</span><b>${v}</b></div>`).join('')}
    ${Object.entries(r.derived).map(([k, v]) => `<div class="kv"><span>${k}</span><b>${v}</b></div>`).join('')}
    ${(r.advisories || []).map((a) => `<div class="fix">${escapeHtml(a)}</div>`).join('')}
    ${(r.warnings || []).map((w) => `<div class="warn">${escapeHtml(w)}</div>`).join('')}
    <div class="muted">${escapeHtml(r.note || '')}</div>`;
}

// ---------------------------------------------------------------------------
function draw() {
  if (state.result) paintBlob(shapeNodes(state.result), state.result.reality.colour, 1);
}

function escapeHtml(s) {
  return String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
