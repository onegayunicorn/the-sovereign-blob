/**
 * Export layer — the actual output package.
 *
 * Formats that matter, and why:
 *   CSV   cut list for a human at the saw
 *   SVG   nested sheet layout + elevation, printable, and previewable in the app
 *   DXF   R12 ASCII, units = millimetres, so a CNC bureau or a laser cutter can take
 *         the nesting directly. This is the file that converts a design into a job.
 *   JSON  the full package, including every check, so the design is re-openable
 *         without the app (local-first means the file has to stand alone)
 *
 * DXF is deliberately minimal (LINE entities only, R12 flavour) because that is the
 * lowest common denominator every cutter accepts. It is not a substitute for the
 * bureau's own nester, which will usually re-nest for their machine.
 */

export const DXF_INSUNITS_MM = 4;

export function toCutListCSV(cutList, { generatedAt } = {}) {
  const header = ['part', 'qty', 'length_mm', 'width_mm', 'thickness_mm', 'material', 'grain', 'edges_banded', 'mass_kg'].join(',');
  const rows = cutList.parts.map((p) =>
    [
      csv(p.label),
      p.qty,
      p.lengthMm,
      p.widthMm,
      p.thicknessMm,
      csv(cutList.material.label),
      // Grain direction is a property of the PART, not of the stock: a plywood sheet is
      // grain-sensitive but a square offcut cut from it is not. Reading it off
      // cutList.material made this column always 'n/a', which is worse than useless on
      // a shop floor.
      p.grainSensitive ? 'length' : 'n/a',
      csv((p.edgesBanded || []).join('+') || 'none'),
      (p.massKg ?? 0).toFixed(2)
    ].join(',')
  );
  const meta = [
    `# Sovereign Blob cut list`,
    `# generated: ${generatedAt || new Date().toISOString()}`,
    `# carcass sheet: ${cutList.nesting.carcass.sheet.lengthMm} x ${cutList.nesting.carcass.sheet.widthMm} mm`,
    `# ${cutList.nesting.carcassSheetCount} sheet(s) at ${Math.round(cutList.nesting.carcass.overallUtilisation * 100)}% yield`,
    `# joinery: ${cutList.joinery.label}`,
    `# shelf span ${cutList.spanMm} mm, predicted long-term sag ${cutList.checks.shelfDeflection.longTermMm} mm (limit ${cutList.checks.shelfDeflection.limitMm} mm)`,
    `# total mass ${cutList.totalMassKg} kg`
  ].join('\n');
  return `${meta}\n${header}\n${rows.join('\n')}\n`;
}

export function toNestedSVG(cutList, { scale = 0.25, includeElevation = true } = {}) {
  const nests = [cutList.nesting.carcass];
  let yOffset = 0;
  const parts = [];

  const title = (x, y, text, size = 16) =>
    `<text x="${x}" y="${y}" fill="#7ffbe6" font-family="monospace" font-size="${size}">${esc(text)}</text>`;

  parts.push(title(20, 30, `Sovereign Blob — nested sheet layout (${cutList.nesting.carcassSheetCount} sheet(s), ${Math.round(cutList.nesting.carcass.overallUtilisation * 100)}% yield)`));

  for (const nest of nests) {
    for (const sheet of nest.sheets) {
      const w = nest.sheet.widthMm * scale;
      const h = nest.sheet.lengthMm * scale;
      const ox = 20;
      const oy = 60 + yOffset;
      parts.push(
        `<rect x="${ox}" y="${oy}" width="${w}" height="${h}" fill="#0f1020" stroke="#00E5FF" stroke-width="1.5"/>`
      );
      for (const p of sheet.parts) {
        parts.push(
          `<rect x="${ox + p.y * scale}" y="${oy + p.x * scale}" width="${p.h * scale}" height="${p.w * scale}" fill="rgba(0,255,204,0.10)" stroke="#00FFCC" stroke-width="0.8" data-part="${esc(p.id)}" data-rotated="${p.rotated}"/>`
        );
        if (p.h * scale > 26) {
          parts.push(
            `<text x="${ox + p.y * scale + 4}" y="${oy + p.x * scale + 14}" fill="#d8fff7" font-family="monospace" font-size="9">${esc(p.id)} ${p.lengthMm}x${p.widthMm}${p.rotated ? ' R' : ''}</text>`
          );
        }
      }
      parts.push(title(ox, oy - 6, `sheet ${sheet.index} — ${nest.sheet.lengthMm} x ${nest.sheet.widthMm} mm`, 12));
      yOffset += h + 60;
    }
  }

  if (includeElevation && cutList.plan) {
    const ox = 20;
    const oy = 60 + yOffset;
    const s = 0.18;
    const w = cutList.plan.widthMm * s;
    const h = cutList.plan.heightMm * s;
    parts.push(title(ox, oy - 6, 'front elevation', 12));
    for (const r of cutList.plan.rects) {
      parts.push(
        `<rect x="${ox + r.x * s}" y="${oy + (cutList.plan.heightMm - r.y - r.h) * s}" width="${Math.max(1, r.w * s)}" height="${Math.max(1, r.h * s)}" fill="${r.kind === 'side' ? 'rgba(0,229,255,0.18)' : 'rgba(0,255,204,0.14)'}" stroke="#00FFCC" stroke-width="0.7" data-kind="${r.kind}"/>`
      );
    }
    parts.push(
      `<rect x="${ox}" y="${oy}" width="${w}" height="${h}" fill="none" stroke="#00E5FF" stroke-width="1.2"/>`
    );
    yOffset += h + 60;
  }

  const width = 20 + cutList.nesting.carcass.sheet.widthMm * scale + 40;
  const height = 60 + yOffset + 20;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${Math.round(width)}" height="${Math.round(height)}" viewBox="0 0 ${Math.round(width)} ${Math.round(height)}"><rect width="100%" height="100%" fill="#0A0A10"/>${parts.join('')}</svg>`;
}

export function toDXF(cutList, { includeSheetOutline = true } = {}) {
  const lines = ['0', 'SECTION', '2', 'HEADER'];
  lines.push('9', '$INSUNITS', '70', String(DXF_INSUNITS_MM));
  lines.push('0', 'ENDSEC', '0', 'SECTION', '2', 'ENTITIES');

  const addLine = (x1, y1, x2, y2, layer) => {
    lines.push('0', 'LINE', '8', layer, '10', fmt(x1), '20', fmt(y1), '11', fmt(x2), '21', fmt(y2));
  };
  const addRect = (x, y, w, h, layer) => {
    // y up, origin bottom-left of the sheet
    addLine(x, y, x + w, y, layer);
    addLine(x + w, y, x + w, y + h, layer);
    addLine(x + w, y + h, x, y + h, layer);
    addLine(x, y + h, x, y, layer);
  };

  const sheet = cutList.nesting.carcass.sheet;
  let xOffset = 0;

  cutList.nesting.carcass.sheets.forEach((s, i) => {
    const ox = xOffset;
    if (includeSheetOutline) addRect(ox, 0, sheet.widthMm, sheet.lengthMm, 'SHEET');
    for (const p of s.parts) {
      // The packer works in sheet coordinates (x along length). DXF y is up, so the
      // part is placed with its length along +Y to match the sheet's own axes.
      addRect(ox + p.y, p.x, p.h, p.w, p.thicknessMm === cutList.spec.thicknessMm ? 'CAR005' : 'CAR003');
    }
    xOffset += sheet.widthMm + 100;
  });

  if (cutList.nesting.back.sheets.length) {
    const bsheet = cutList.nesting.back.sheet;
    const ox = xOffset;
    addRect(ox, 0, bsheet.widthMm, bsheet.lengthMm, 'SHEET');
    for (const s of cutList.nesting.back.sheets) {
      for (const p of s.parts) addRect(ox + p.y, p.x, p.h, p.w, 'BACK');
    }
  }

  lines.push('0', 'ENDSEC', '0', 'EOF');
  return lines.join('\n') + '\n';
}

export function toPackageJSON(result, { generatedAt } = {}) {
  return JSON.stringify(
    {
      format: 'sovereign-blob/package@1',
      generatedAt: generatedAt || new Date().toISOString(),
      units: 'mm',
      intent: result.intent,
      spec: result.cutList.spec,
      reality: { score: result.reality.score, band: result.reality.band, dimensions: result.reality.dimensions, issues: result.reality.issues, mitigations: result.reality.mitigations },
      checks: result.cutList.checks,
      remedy: result.cutList.remedy,
      material: result.cutList.material,
      joinery: { id: result.cutList.joinery.id, label: result.cutList.joinery.label, reason: result.cutList.joinery.selectedBecause },
      parts: result.cutList.parts,
      nesting: {
        carcassSheetCount: result.cutList.nesting.carcassSheetCount,
        backSheetCount: result.cutList.nesting.backSheetCount,
        carcass: result.cutList.nesting.carcass.sheets,
        back: result.cutList.nesting.back.sheets
      },
      fasteners: result.cutList.fasteners,
      edgeBandingMm: result.cutList.edgeBandingMm,
      totalMassKg: result.cutList.totalMassKg,
      cost: result.cost,
      assembly: result.assembly,
      flags: result.cutList.flags,
      provenance: {
        priceBookAsOf: result.cost.asOf,
        materialDataVerified: result.cutList.material.verified,
        note: 'Structural figures are first-order hand calculations, not a structural certificate. Verify material modulus against a supplier datasheet before cutting.'
      }
    },
    null,
    2
  );
}

function fmt(n) {
  return (Math.round(n * 1000) / 1000).toString();
}
function csv(s) {
  const v = String(s ?? '');
  return /[",\n]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v;
}
function esc(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
