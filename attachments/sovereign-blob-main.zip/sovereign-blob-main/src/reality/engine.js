/**
 * Reality Engine — continuous "can this exist?" scoring.
 *
 * DESIGN INTEGRITY NOTE
 * This is deliberately NOT a language model guessing a score. Every dimension is a
 * deterministic function of numbers the engineering engine already computed
 * (deflection utilisation, tip-over margin, sheet yield, priced/unpriced lines).
 * Given the same design it always returns the same score, and the breakdown shows
 * exactly which term moved it. That is what makes it usable as a design gate rather
 * than as decoration.
 *
 * Bands drive the blob's colour:
 *   green  >= 80  buildable as drawn
 *   amber  60-79  buildable with the listed mitigations
 *   red    <  60  do not build as drawn
 */

export const BANDS = {
  green: { min: 80, colour: '#00FFCC', label: 'buildable as drawn' },
  amber: { min: 60, colour: '#FFB020', label: 'buildable with mitigations' },
  red: { min: 0, colour: '#FF3B30', label: 'do not build as drawn' }
};

export const WEIGHTS = {
  physics: 0.3,
  safety: 0.25,
  manufacturability: 0.15,
  cost: 0.15,
  complexity: 0.1,
  energy: 0.05
};

function clamp(n, lo = 0, hi = 100) {
  return Math.max(lo, Math.min(hi, n));
}

function band(score) {
  if (score >= BANDS.green.min) return 'green';
  if (score >= BANDS.amber.min) return 'amber';
  return 'red';
}

/**
 * Stage 1-3 (intent / form / geometry): the only hard numbers available are the
 * dimensions themselves. Everything structural is still unknown, so the score is
 * explicitly capped and the reason string says so.
 */
export function scoreFormStage({ spec, roomCheck = null }) {
  const issues = [];
  let s = 100;

  const aspect = spec.heightMm / spec.widthMm;
  if (aspect > 4) {
    issues.push(`height/width ratio ${aspect.toFixed(2)} is very tall and narrow — unstable before it is even built`);
    s -= 25;
  }
  if (spec.bayClearMm > 450) {
    issues.push(`clear bay of ${spec.bayClearMm} mm is taller than a standard book; you are paying for air`);
    s -= 10;
  }
  if (spec.bayClearMm < 180) {
    issues.push(`clear bay of ${spec.bayClearMm} mm will not take a hardback`);
    s -= 15;
  }
  if (spec.depthMm < 200) {
    issues.push(`depth ${spec.depthMm} mm is shallower than most art books`);
    s -= 10;
  }
  if (roomCheck && !roomCheck.fits) {
    issues.push(...roomCheck.issues);
    s -= 40;
  }

  return {
    stage: 'form',
    complete: false,
    score: clamp(s),
    band: band(clamp(s)),
    colour: BANDS[band(clamp(s))].colour,
    dimensions: { physics: null, safety: null, manufacturability: null, cost: null, complexity: null, energy: null },
    issues,
    caveat: 'Structural and cost dimensions are not yet computed; this score only reflects proportions and fit.'
  };
}

/**
 * Full score, once the cut list and cost exist.
 */
export function scoreReality({ spec, cutList, cost }) {
  const dimensions = {};
  const issues = [];
  const mitigations = [];

  // --- physics -------------------------------------------------------------
  const def = cutList.checks.shelfDeflection;
  let sagScore;
  if (def.pass) {
    sagScore = clamp(100 - 25 * def.utilisation);
  } else {
    sagScore = clamp(60 - 60 * (def.utilisation - 1));
    issues.push(
      `Shelf sag: ${def.longTermMm} mm predicted long-term against a ${def.limitMm} mm allowance (${Math.round(def.utilisation * 100)}%).`
    );
    if (cutList.remedy) {
      if (cutList.remedy.thickerPasses) {
        mitigations.push(`Use ${cutList.remedy.thickerSheetMm} mm stock on the shelves — predicted sag drops to ${cutList.remedy.thickerDeflectionMm} mm.`);
      }
      if (cutList.remedy.midRailAtHalfSpanPasses) {
        mitigations.push(`Add a mid-rail or centre divider: halving the span drops predicted sag to ${cutList.remedy.midRailDeflectionMm} mm without changing material.`);
      }
      if (cutList.remedy.deeperShelfPasses) {
        mitigations.push(`Increase shelf depth to ${cutList.remedy.deeperShelfMm} mm — sag ${cutList.remedy.deeperShelfDeflectionMm} mm.`);
      }
      if (!cutList.remedy.thickerPasses && !cutList.remedy.midRailAtHalfSpanPasses && !cutList.remedy.deeperShelfPasses) {
        issues.push('No single-parameter fix works; reduce the span materially or change material.');
      }
    }
  }

  const tip = cutList.checks.tipOver;
  const tipScore = tip.pass ? clamp(70 + 30 * Math.min(1, tip.margin - 1)) : clamp(tip.margin * 100);

  const rack = cutList.checks.racking;
  const rackScore = rack.pass ? 100 : 40;
  if (!rack.pass) issues.push(`Racking: ${rack.action}`);

  dimensions.physics = Math.round(0.5 * sagScore + 0.3 * tipScore + 0.2 * rackScore);

  // --- safety --------------------------------------------------------------
  let safety = 100;
  if (tip.anchoredRequired && !spec.anchored) {
    safety -= 35;
    issues.push(`Tip-over margin ${tip.margin} with no wall fixing. This is the leading furniture injury mechanism in homes with children.`);
    mitigations.push('Fix the unit to the wall (studs, or rated hollow-wall anchors) — the cost engine already prices an anti-tip kit.');
  }
  if (spec.widthMm >= 600 && spec.heightMm >= 1200 && !spec.anchored) safety -= 10;
  const unbanded = cutList.parts.some((p) => p.edgesBanded && p.edgesBanded.length > 0) ? 0 : 5;
  safety -= unbanded;
  if (spec.loadPerShelfKg > 40) {
    safety -= 10;
    issues.push(`${spec.loadPerShelfKg} kg per shelf is above a normal domestic book load (25 kg); verify with a real load test.`);
  }
  dimensions.safety = clamp(safety);

  // --- manufacturability ---------------------------------------------------
  const yieldPct = cutList.nesting.carcass.overallUtilisation;
  let mfg = yieldPct >= 0.65 ? 100 : yieldPct >= 0.5 ? 88 : yieldPct >= 0.4 ? 72 : 55;
  if (cutList.nesting.carcass.unplaced.length) {
    mfg = 0;
    issues.push('At least one part does not fit on a standard sheet at any rotation.');
  }
  if (cutList.nesting.carcassSheetCount > 1) {
    mfg -= 5;
    mitigations.push(`Two sheets are required at ${Math.round(yieldPct * 100)}% yield — the grain constraint forces the orientation. Batch with a second project or trim the height to reduce offcut.`);
  }
  const distinctOps = new Set(cutList.parts.flatMap((p) => p.edgesBanded || [])).size + (cutList.joinery.tooling || []).length;
  if (distinctOps > 8) mfg -= 5;
  dimensions.manufacturability = clamp(mfg);

  // --- cost ----------------------------------------------------------------
  // If the user gave a budget, affordability is the question. If not, the honest
  // question is how much of the cost is actually knowable.
  if (spec.budget) {
    const ratio = cost.total / spec.budget;
    dimensions.cost = clamp(ratio <= 0.8 ? 100 : ratio <= 1 ? 90 - (ratio - 0.8) * 100 : 82 - (ratio - 1) * 200);
    if (ratio > 1) {
      issues.push(`Priced subtotal ${cost.total} ${cost.currency} is over the ${spec.budget} ${cost.currency} budget.`);
      mitigations.push('Switch the joinery to dowels, drop the back panel to 3 mm, or reduce shelf count.');
    }
  } else {
    const unpricedPenalty = cost.unpriced.length * 8;
    const mismatchPenalty = cost.lines.filter((l) => l.basisMismatch).length * 12;
    dimensions.cost = clamp(100 - unpricedPenalty - mismatchPenalty, 40, 100);
    if (cost.unpriced.length) {
      issues.push(`${cost.unpriced.length} line(s) in the bill of materials have no verified price, so the total is a partial figure.`);
    }
    const mismatched = cost.lines.filter((l) => l.basisMismatch);
    if (mismatched.length) {
      issues.push(`${mismatched.length} line(s) are priced at a bulk MOQ tier you cannot buy at for one build.`);
      mitigations.push('Set a budget or a target quantity so the Economic Engine can price at the right tier.');
    }
  }

  // --- complexity ----------------------------------------------------------
  const partCount = cutList.parts.reduce((s, p) => s + p.qty, 0);
  let complexity = clamp(100 - Math.max(0, partCount - 8) * 3);
  const jointCount = cutList.fasteners.reduce((s, f) => s + f.count, 0);
  if (jointCount > 60) complexity -= 10;
  if (cutList.joinery.substituted) complexity -= 5;
  dimensions.complexity = clamp(complexity);

  // --- energy --------------------------------------------------------------
  // Computable part: router path length / feed rate. Not an estimate of embodied
  // energy, which needs a supplier EPD that we do not have.
  const pathMm = cutList.nesting.carcass.sheets.reduce(
    (s, sheet) => s + sheet.parts.reduce((a, p) => a + 2 * (p.lengthMm + p.widthMm), 0),
    0
  );
  const cncMinutes = Math.round((pathMm / 3000) * 10) / 10; // 3000 mm/min feed, typical nesting router
  dimensions.energy = clamp(100 - Math.max(0, cncMinutes - 20) * 0.5);

  const combined = Math.round(
    Object.entries(WEIGHTS).reduce((sum, [k, w]) => sum + dimensions[k] * w, 0)
  );

  return {
    stage: 'full',
    complete: true,
    dimensions,
    weights: WEIGHTS,
    score: clamp(combined),
    band: band(clamp(combined)),
    colour: BANDS[band(clamp(combined))].colour,
    issues,
    mitigations,
    cnc: { pathLengthMm: Math.round(pathMm), estimatedMinutes: cncMinutes, feedRateMmPerMin: 3000 },
    status: clamp(combined) >= 80 ? 'PASS' : clamp(combined) >= 60 ? 'REVIEW' : 'FAIL'
  };
}

/**
 * Dream State: when the user pauses, explore single-parameter variants and keep the
 * ones that improve the Reality Score. This is a deterministic neighbourhood search,
 * not a generative model — every variant is a real recomputation.
 */
export function exploreVariants(buildFn, spec, scoreFn, options = {}) {
  const maxVariants = options.maxVariants ?? 12;
  const dimensions = [
    { key: 'thicknessMm', values: [15, 18, 21, 25] },
    { key: 'shelves', values: [spec.shelves - 1, spec.shelves, spec.shelves + 1] },
    { key: 'depthMm', values: [250, 300, 350] },
    { key: 'joinery', values: ['pocket-screw', 'dado', 'dowel', null] },
    { key: 'backPanel', values: [true, false] },
    { key: 'anchored', values: [true] }
  ];

  const results = [];
  for (const d of dimensions) {
    for (const value of d.values) {
      if (value === spec[d.key]) continue;
      if (d.key === 'shelves' && value < 2) continue;
      const variantSpec = { ...spec, [d.key]: value };
      if (d.key === 'joinery' && value === null) variantSpec.knockdown = true;
      try {
        const built = buildFn(variantSpec);
        const scored = scoreFn(built);
        results.push({
          change: { [d.key]: value },
          score: scored.score,
          band: scored.band,
          total: built.cost?.total ?? null,
          currency: built.cost?.currency ?? null
        });
      } catch (err) {
        results.push({ change: { [d.key]: value }, error: String(err && err.message) });
      }
      if (results.length >= maxVariants) break;
    }
    if (results.length >= maxVariants) break;
  }

  const usable = results.filter((r) => !r.error);
  usable.sort((a, b) => b.score - a.score);
  return {
    explored: results.length,
    // `recommended` is the single highest-scoring variant, so callers do not have to re-sort.
    // It is what surfaced the wall-anchored variant scoring 77 -> READY against 72 CAUTION for
    // the free-standing design: the design was never fixed by thicker material, it was fixed by
    // anchoring the unit to the wall.
    recommended: usable[0] ?? null,
    best: usable.slice(0, 3),
    worst: usable.slice(-1),
    note: 'Each variant is a full recomputation of geometry, load check and cost. No variant is proposed without being checked.'
  };
}
