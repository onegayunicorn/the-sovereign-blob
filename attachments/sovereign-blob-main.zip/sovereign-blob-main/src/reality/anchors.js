/**
 * Reality Anchors — the anti-drift mechanism (spec section 10, AC SB-060).
 *
 * THE RULE, exactly as specified: if a LOCKED anchor is violated, status is BLOCKED. No
 * silent overrides, no hidden workarounds, and the engine must explain the violation and
 * the recommended correction.
 *
 * An unlocked anchor is advisory: a violation is recorded in the manifest's audit trail and
 * raised as a warning, but it does not stop the build. That distinction is deliberate. If
 * every anchor blocked on violation, a first draft could never be iterated, and the user
 * would learn to unlock everything — which is the same as having no anchors. Locking is how
 * the user says "this one is not negotiable", and only that statement has teeth.
 */

/** Anchor types accepted on input. The spec uses `anchorType` in section 10 and `type` in
 *  the SBM example; both are read, `anchorType` is what gets written. */
const TYPES = new Set(['physical', 'spatial', 'safety', 'economic', 'material', 'regulatory', 'aesthetic']);

/** The spec's stated safe working load for anchor C (35 kg per shelf). Independent of the
 *  design's requested load on purpose — see the rationale on the anchor itself. */
export const DEFAULT_MAX_SHELF_LOAD_KG = 35;

function normaliseType(t) {
  const v = String(t ?? '').toLowerCase();
  if (!TYPES.has(v)) {
    throw new Error(`unknown anchor type "${t}" — expected one of ${[...TYPES].join(', ')}`);
  }
  return v;
}

/**
 * Build the standard bookshelf anchor set (spec section 10: Wall, Floor, Maximum Load,
 * Material Set, Budget) from the design. All start unlocked; the user or app locks the ones
 * that must not move.
 */
export function defaultAnchors({ spec, cutList, cost, room } = {}) {
  const anchors = [];
  const push = (a) => anchors.push({ ...a, anchorType: normaliseType(a.anchorType), type: normaliseType(a.anchorType) });

  push({
    anchorId: 'anchor-wall-001',
    anchorType: 'physical',
    name: 'Wall',
    value: spec?.wallMounted ? 'wall-mounted' : 'attachment point available',
    unit: 'attachment',
    locked: false,
    rationale: 'The unit attaches here. A tall narrow case that is not fixed is a tip-over hazard, not just a stability preference.'
  });

  push({
    anchorId: 'anchor-floor-001',
    anchorType: 'physical',
    name: 'Floor',
    value: 'level',
    unit: 'reference',
    locked: false,
    rationale: 'Gravity reference. Every vertical dimension is measured from this plane.'
  });

  push({
    anchorId: 'anchor-load-001',
    anchorType: 'physical',
    name: 'Maximum Shelf Load',
    value: spec?.maxLoadKg ?? DEFAULT_MAX_SHELF_LOAD_KG,
    unit: 'kg',
    locked: false,
    rationale:
      'Safe working load PER SHELF (spec section 10 anchor C). Deliberately independent of the load the current design asks for: a ceiling derived from the thing it constrains can never be violated, which makes it decoration rather than an anchor. Set spec.maxLoadKg to change it.'
  });

  push({
    anchorId: 'anchor-material-001',
    anchorType: 'material',
    name: 'Material Set',
    value: spec?.approvedMaterials?.join(', ') ?? (spec?.material ?? 'birch-plywood'),
    unit: 'material',
    locked: false,
    rationale: 'Approved materials. A substitution outside this set invalidates the structural check, because the modulus changes with it.'
  });

  push({
    anchorId: 'anchor-budget-001',
    anchorType: 'economic',
    name: 'Budget',
    value: spec?.budget ?? (cost?.total ?? 0),
    unit: cost?.currency ?? 'AUD',
    locked: false,
    rationale: 'Cost ceiling. Locked, it stops an "improvement" that quietly doubles the build cost.'
  });

  if (room?.wallWidthMm) {
    push({
      anchorId: 'anchor-wall-bounds-001',
      anchorType: 'spatial',
      name: 'Wall Bounds',
      value: room.wallWidthMm,
      unit: 'mm',
      locked: false,
      rationale: `Wall measured at ${room.wallWidthMm} mm wide. A design wider than this does not fit, whatever else it gets right.`
    });
  }

  return anchors;
}

/** Normalise anchors that came from outside (an API call, a saved SBM). */
export function normaliseAnchors(input = []) {
  return input.map((a) => {
    const t = normaliseType(a.anchorType ?? a.type);
    return { ...a, anchorType: t, type: t, locked: Boolean(a.locked) };
  });
}

/**
 * Validate anchors against the design. Returns every violation found, each carrying the
 * expected value, the actual value, and what to do about it — because "BLOCKED" with no
 * explanation is a bug in a tool whose job is to explain.
 */
export function validateAnchors(anchors = [], { spec, cutList, cost, room } = {}) {
  const list = normaliseAnchors(anchors);
  const violations = [];
  const warnings = [];

  const add = (anchor, expected, actual, message, recommendation, blocking) => {
    const record = {
      anchorId: anchor.anchorId,
      anchorType: anchor.anchorType,
      name: anchor.name,
      locked: anchor.locked,
      expected,
      actual,
      message,
      recommendation,
      blocking: Boolean(blocking)
    };
    if (anchor.locked) violations.push(record);
    else warnings.push(record);
  };

  for (const a of list) {
    switch (a.anchorId) {
      case 'anchor-wall-001': {
        const needsFixing = cutList?.checks?.tipOver?.anchoredRequired;
        if (needsFixing && spec && !spec.anchored) {
          add(
            a,
            'fixed to wall',
            `free-standing (tip-over margin ${cutList.checks.tipOver.margin})`,
            `Tip-over margin ${cutList.checks.tipOver.margin} means this unit must be fixed to the wall, and the design is free-standing.`,
            'Set anchored: true and include the wall fixing kit. A French cleat rated to at least 60 kg is the intended method for this unit.',
            a.locked
          );
        }
        break;
      }
      case 'anchor-load-001': {
        const request = spec?.loadPerShelfKg;
        const limit = Number(a.value);
        if (Number.isFinite(request) && Number.isFinite(limit) && request > limit) {
          add(
            a,
            `<= ${limit} ${a.unit}`,
            `${request} ${a.unit}`,
            `Design load ${request} kg per shelf exceeds the locked maximum of ${limit} kg.`,
            `Either lower the design load to ${limit} kg or raise this anchor deliberately and re-run the structural check, because the thickness verdict depends on it.`,
            a.locked
          );
        }
        break;
      }
      case 'anchor-material-001': {
        const approved = String(a.value)
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean);
        if (spec?.material && approved.length && !approved.includes(spec.material)) {
          add(
            a,
            approved.join(', '),
            spec.material,
            `Material "${spec.material}" is outside the approved set.`,
            'Substituting the board changes the elastic modulus, so the deflection result no longer applies. Re-run the structural check with the new material, or pick an approved one.',
            a.locked
          );
        }
        break;
      }
      case 'anchor-budget-001': {
        const ceiling = Number(a.value);
        const total = cost?.total;
        if (Number.isFinite(ceiling) && Number.isFinite(total) && total > ceiling) {
          add(
            a,
            `<= ${ceiling} ${a.unit}`,
            `${total} ${cost?.currency ?? a.unit}`,
            `Total ${total} ${cost?.currency ?? ''} exceeds the budget ceiling of ${ceiling} ${a.unit}.`,
            'Reduce sheet count or step down a grade. Note that the material line may be a bulk tier the build cannot buy at, in which case the real cost is higher still.',
            a.locked
          );
        }
        break;
      }
      case 'anchor-wall-bounds-001': {
        const wall = Number(a.value);
        const width = spec?.widthMm;
        if (Number.isFinite(wall) && Number.isFinite(width) && width > wall) {
          add(
            a,
            `<= ${wall} ${a.unit}`,
            `${width} ${a.unit}`,
            `Design width ${width} mm exceeds the measured wall width of ${wall} mm.`,
            'Reduce the width, or re-measure the wall if the scan confidence was low.',
            a.locked
          );
        }
        break;
      }
      default:
        // Unknown anchor ids are carried through untouched rather than guessed at.
        break;
    }
  }

  const lockedViolations = violations.filter((v) => v.blocking);
  return {
    valid: lockedViolations.length === 0,
    violations: [...violations, ...warnings].sort((x, y) => Number(y.blocking) - Number(x.blocking)),
    blocking: lockedViolations,
    warnings
  };
}

/**
 * Lock an anchor. Locking is the point at which an advisory constraint becomes a hard gate,
 * so it returns the updated set rather than mutating in place.
 */
export function lockAnchor(anchors, anchorId) {
  const list = normaliseAnchors(anchors);
  const found = list.find((a) => a.anchorId === anchorId);
  if (!found) throw new Error(`cannot lock unknown anchor "${anchorId}"`);
  return list.map((a) => (a.anchorId === anchorId ? { ...a, locked: true } : a));
}

export function unlockAnchor(anchors, anchorId) {
  const list = normaliseAnchors(anchors);
  if (!list.some((a) => a.anchorId === anchorId)) throw new Error(`cannot unlock unknown anchor "${anchorId}"`);
  return list.map((a) => (a.anchorId === anchorId ? { ...a, locked: false } : a));
}

/**
 * Attempt to change a locked anchor's value. This always fails, and says why. There is no
 * override path: an override flag is the "hidden workaround" the spec forbids, and any flag
 * that exists will eventually be set by something that should not be setting it.
 */
export function attemptAnchorChange(anchors, anchorId, newValue) {
  const list = normaliseAnchors(anchors);
  const found = list.find((a) => a.anchorId === anchorId);
  if (!found) throw new Error(`cannot change unknown anchor "${anchorId}"`);
  if (found.locked) {
    return {
      accepted: false,
      blocking: true,
      anchorId,
      message: `Anchor "${found.name}" is locked at ${found.value} ${found.unit}. Locked anchors cannot be changed.`,
      recommendation: `Unlock "${found.name}" explicitly first, then re-run the Reality Engine. Changing it silently is exactly the concept drift anchors exist to prevent.`
    };
  }
  return {
    accepted: true,
    blocking: false,
    anchorId,
    before: found.value,
    after: newValue,
    anchors: list.map((a) => (a.anchorId === anchorId ? { ...a, value: newValue } : a))
  };
}
