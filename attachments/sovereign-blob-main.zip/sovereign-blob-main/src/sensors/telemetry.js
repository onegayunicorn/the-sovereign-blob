/**
 * Telemetry bridge payload contract + decoder for the ESP32 sensor node.
 *
 * Payload (JSON, one object per reading):
 * {
 *   deviceId: string, ts: epoch ms,
 *   tempC, humidityPct, pressureHpa, lux,
 *   ax, ay, az (g), gx, gy, gz (deg/s),
 *   batteryV, rssiDbm, fw: string
 * }
 *
 * WHAT IS DERIVED, AND WHAT IS DELIBERATELY NOT
 *  - Derived exactly: tilt/orientation from the accelerometer, vibration energy,
 *    telemetry freshness, node health.
 *  - NOT derived: equilibrium moisture content of the timber. Converting temperature
 *    and RH into a moisture content needs a sorption model plus species data, and
 *    guessing it would produce a precise-looking number with no basis. Instead the
 *    reading is compared against a threshold band that the user defines in
 *    config/environment.json, and the module says so.
 */

export const REQUIRED_FIELDS = ['deviceId', 'ts'];
export const NUMERIC_RANGES = {
  tempC: [-40, 85],
  humidityPct: [0, 100],
  pressureHpa: [300, 1100],
  lux: [0, 200000],
  ax: [-16, 16],
  ay: [-16, 16],
  az: [-16, 16],
  gx: [-2000, 2000],
  gy: [-2000, 2000],
  gz: [-2000, 2000],
  batteryV: [2.5, 6],
  rssiDbm: [-120, 0]
};

export const DEFAULT_ENVIRONMENT = {
  comfortRhRange: [35, 60],
  comfortTempRangeC: [15, 30],
  stalenessSeconds: 60
};

export function parseTelemetry(raw, options = {}) {
  const env = { ...DEFAULT_ENVIRONMENT, ...(options.environment || {}) };
  let payload = raw;
  if (typeof raw === 'string') {
    try {
      payload = JSON.parse(raw);
    } catch (err) {
      return { ok: false, errors: [`payload is not valid JSON: ${err.message}`] };
    }
  }
  if (!payload || typeof payload !== 'object') {
    return { ok: false, errors: ['payload must be an object'] };
  }

  const errors = [];
  const warnings = [];
  for (const f of REQUIRED_FIELDS) {
    if (payload[f] === undefined || payload[f] === null || payload[f] === '') errors.push(`missing required field: ${f}`);
  }
  const values = {};
  for (const [field, [lo, hi]] of Object.entries(NUMERIC_RANGES)) {
    const v = payload[field];
    if (v === undefined || v === null) continue;
    const n = Number(v);
    if (Number.isNaN(n)) {
      errors.push(`${field} is not a number`);
      continue;
    }
    if (n < lo || n > hi) {
      // Out of range means either a wiring fault or a wrong scaling factor.
      errors.push(`${field}=${n} is outside the plausible range ${lo}..${hi} — check the sensor scaling, not the room`);
      continue;
    }
    values[field] = n;
  }
  if (errors.length) return { ok: false, errors, warnings };

  const ts = Number(payload.ts);
  const now = options.now ?? Date.now();
  const ageSeconds = Math.max(0, Math.round((now - ts) / 1000));
  if (ageSeconds > env.stalenessSeconds) {
    warnings.push(`Reading is ${ageSeconds}s old (node sends every ~5s); the bridge or the node has stopped.`);
  }

  const derived = {};
  if (values.ax !== undefined && values.ay !== undefined && values.az !== undefined) {
    const mag = Math.hypot(values.ax, values.ay, values.az) || 1e-9;
    derived.resultantG = round3(mag);
    derived.tiltDeg = round2((Math.acos(clamp(values.az / mag, -1, 1)) * 180) / Math.PI);
    derived.rollDeg = round2((Math.atan2(values.ay, values.az) * 180) / Math.PI);
    derived.pitchDeg = round2((Math.atan2(-values.ax, Math.hypot(values.ay, values.az)) * 180) / Math.PI);
    if (Math.abs(mag - 1) > 0.25) {
      warnings.push(`Resultant acceleration ${derived.resultantG} g is not ~1 g — the node is being moved, or the accelerometer is uncalibrated.`);
    }
  }
  if (values.gx !== undefined) {
    derived.vibrationRms = round2(Math.sqrt((values.gx ** 2 + (values.gy ?? 0) ** 2 + (values.gz ?? 0) ** 2) / 3));
    if (derived.vibrationRms > 25) {
      warnings.push(`Vibration RMS ${derived.vibrationRms} deg/s — machinery or footfall nearby; depth scans taken now will be noisy.`);
    }
  }

  const advisories = [];
  if (values.humidityPct !== undefined) {
    const [lo, hi] = env.comfortRhRange;
    if (values.humidityPct < lo) {
      advisories.push(`RH ${values.humidityPct}% is below the configured ${lo}-${hi}% band: solid timber will shrink across the grain and joints can open. Sheet goods move far less.`);
    } else if (values.humidityPct > hi) {
      advisories.push(`RH ${values.humidityPct}% is above the configured ${lo}-${hi}% band: solid timber will swell; leave clearance in dadoes and do not glue wide panels across the grain.`);
    }
  }
  if (values.tempC !== undefined) {
    const [lo, hi] = env.comfortTempRangeC;
    if (values.tempC < lo || values.tempC > hi) {
      advisories.push(`Temperature ${values.tempC} C is outside ${lo}-${hi} C: solvent and water-based finishes will not cure predictably.`);
    }
  }
  if (values.lux !== undefined) {
    advisories.push(
      values.lux > 2000
        ? `${Math.round(values.lux)} lx in the room: a high-gloss finish will show every sanding mark — choose matt or satin.`
        : `${Math.round(values.lux)} lx in the room: low light hides surface defects, so inspect the finish with a raking light before signing off.`
    );
  }
  if (payload.batteryV !== undefined && values.batteryV !== undefined && values.batteryV < 3.3) {
    advisories.push(`Node battery ${values.batteryV} V: replace or recharge — a brown-out resets the sensor bus mid-scan.`);
  }
  if (values.rssiDbm !== undefined && values.rssiDbm < -85) {
    advisories.push(`Link ${values.rssiDbm} dBm is marginal; readings will drop out. Move the node or the access point.`);
  }

  return {
    ok: true,
    deviceId: payload.deviceId,
    ts,
    ageSeconds,
    values,
    derived,
    advisories,
    warnings,
    note: 'Temperature and RH are reported as measured. Moisture content of the timber is NOT computed: that needs a sorption model and species data.'
  };
}

/** Rolling window summary for the UI (keeps the last N readings). */
export function summariseWindow(readings) {
  if (!readings.length) return { count: 0 };
  const nums = (key) => readings.map((r) => r.values?.[key]).filter((v) => typeof v === 'number');
  const stat = (key) => {
    const arr = nums(key);
    if (!arr.length) return null;
    const mean = arr.reduce((a, b) => a + b, 0) / arr.length;
    return { min: round2(Math.min(...arr)), max: round2(Math.max(...arr)), mean: round2(mean) };
  };
  return {
    count: readings.length,
    tempC: stat('tempC'),
    humidityPct: stat('humidityPct'),
    lux: stat('lux'),
    vibrationFromDerived: readings.map((r) => r.derived?.vibrationRms).filter(Boolean).slice(-20)
  };
}

function clamp(n, lo, hi) {
  return Math.max(lo, Math.min(hi, n));
}
function round2(n) {
  return Math.round(n * 100) / 100;
}
function round3(n) {
  return Math.round(n * 1000) / 1000;
}
