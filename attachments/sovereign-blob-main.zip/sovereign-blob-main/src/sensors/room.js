/**
 * Sensor-Reality Fusion — room context.
 *
 * WHAT THIS ACTUALLY DOES vs WHAT IT DOES NOT
 *  - It DOES take a structured room scan (manual entry, or a payload produced by an
 *    ARCore Depth / ARKit scene-mesh capture) and check the design against it.
 *  - It DOES do the access check that actually stops builds: can the finished unit, or
 *    the largest single panel, get through the door and around the turn.
 *  - It DOES NOT measure the room itself. Measuring a wall needs a depth sensor or a
 *    calibrated stereo baseline. That lives in the Android capture layer
 *    (see firmware/ and docs/RoomScan contract below); this module is the consumer
 *    of that data, and it is honest about which fields a phone can and cannot produce.
 *
 * RoomScan contract (all lengths mm, all coordinates relative to the chosen corner):
 * {
 *   widthMm, heightMm, depthMm,            // room envelope
 *   doorWidthMm, doorHeightMm,             // narrowest opening on the route
 *   skirtingHeightMm,                      // floor obstruction at the wall
 *   obstructions: [{label, xMm, yMm, wMm, dMm}],
 *   source: 'manual' | 'arcore-depth' | 'arkit-scene-mesh',
 *   confidence: 0..1,                      // supplied by the capture layer
 *   gyroLevel: boolean                     // phone was held level during capture
 * }
 */

export const DEFAULT_CLEARANCE_MM = 50;

export function validateRoom(scan, unitDims, options = {}) {
  const clearance = options.clearanceMm ?? DEFAULT_CLEARANCE_MM;
  const issues = [];
  const notes = [];
  const checks = {};

  if (!scan) {
    return { fits: true, checks: {}, issues: [], notes: ['No room scan supplied — fit and access are unchecked.'], scanned: false };
  }

  const footprint = { w: unitDims.widthMm, d: unitDims.depthMm, h: unitDims.heightMm };

  // 1. footprint against the room envelope
  const fitsWidth = footprint.w + clearance <= (scan.widthMm ?? Infinity);
  const fitsDepth = footprint.d + clearance <= (scan.depthMm ?? Infinity);
  checks.footprint = { pass: fitsWidth && fitsDepth, wallSpaceNeededMm: footprint.w + clearance, fitsWidth, fitsDepth };
  if (!fitsWidth) issues.push(`Unit is ${footprint.w} mm wide; only ${scan.widthMm} mm of wall is available (needs ${footprint.w + clearance} mm with clearance).`);
  if (!fitsDepth) issues.push(`Unit is ${footprint.d} mm deep; room depth allows ${scan.depthMm} mm.`);

  // 2. ceiling
  const fitsHeight = footprint.h + 20 <= (scan.heightMm ?? Infinity);
  checks.height = { pass: fitsHeight, unitHeightMm: footprint.h, roomHeightMm: scan.heightMm ?? null };
  if (!fitsHeight) issues.push(`Unit is ${footprint.h} mm tall; ceiling is at ${scan.heightMm} mm. It cannot be stood up in place — assemble it lying down and tilt up, or reduce height.`);

  // 3. skirting: a unit pushed flat to the wall leans unless the plinth is set back
  if (scan.skirtingHeightMm) {
    checks.skirting = {
      skirtingHeightMm: scan.skirtingHeightMm,
      pass: true,
      action: `Set the back panel in by at least ${scan.skirtingHeightMm} mm at the base, or notch the plinth — a plinth against skirting makes the top lean forward.`
    };
    notes.push(checks.skirting.action);
  }

  // 4. obstructions
  if (Array.isArray(scan.obstructions) && scan.obstructions.length) {
    const clashes = scan.obstructions.filter((o) => {
      const overlapX = o.xMm < footprint.w + clearance && o.xMm + (o.wMm || 0) > 0;
      return overlapX;
    });
    checks.obstructions = { pass: clashes.length === 0, clashes: clashes.map((c) => ({ label: c.label, xMm: c.xMm })) };
    for (const c of clashes) {
      issues.push(`${c.label || 'obstruction'} sits within the proposed footprint (${c.xMm} mm from the corner).`);
    }
  } else {
    checks.obstructions = { pass: true, clashes: [] };
  }

  // 5. access
  const access = accessCheck(scan, unitDims, options);
  checks.access = access;
  issues.push(...access.issues);

  if (scan.source === 'manual') notes.push('Room data was entered by hand; treat clearances as nominal.');
  if (typeof scan.confidence === 'number' && scan.confidence < 0.6) {
    notes.push(`Capture confidence ${scan.confidence} is low (phone likely was not held level or the surface was specular). Re-scan.`);
  }

  return { fits: issues.length === 0, checks, issues, notes, scanned: true, source: scan.source || 'manual' };
}

/**
 * Can it get in? Two separate questions, both of which stop real builds:
 *   - flat-pack route: every part must pass the narrowest opening
 *   - assembled route: the whole unit must pass
 */
export function accessCheck(scan, unitDims, options = {}) {
  const allow = options.doorAllowanceMm ?? 20;
  const doorW = scan.doorWidthMm;
  const doorH = scan.doorHeightMm;
  const issues = [];
  const result = { doorWidthMm: doorW ?? null, doorHeightMm: doorH ?? null, assembled: null, parts: null };

  if (!doorW || !doorH) {
    return { ...result, checked: false, issues: [], note: 'No door dimensions supplied — access is unchecked.' };
  }

  const assembledFits = unitDims.heightMm <= doorH - allow && unitDims.depthMm <= doorW - allow;
  result.assembled = { pass: assembledFits, heightMm: unitDims.heightMm, depthMm: unitDims.depthMm };
  if (!assembledFits) {
    issues.push(
      `Assembled unit (${unitDims.heightMm} x ${unitDims.depthMm} mm) will not pass a ${doorW} x ${doorH} mm opening. Assemble it in the room, or design it knock-down.`
    );
  }

  if (Array.isArray(options.parts) && options.parts.length) {
    const smallestSide = (p) => Math.min(p.lengthMm, p.widthMm);
    const largestSide = (p) => Math.max(p.lengthMm, p.widthMm);
    const passable = options.parts.every((p) => smallestSide(p) <= doorW - allow && largestSide(p) <= doorH - allow);
    result.parts = {
      pass: passable,
      limitingPart: options.parts
        .map((p) => ({ label: p.label, needsMm: `${smallestSide(p)} x ${largestSide(p)}` }))
        .sort((a, b) => parseInt(b.needsMm) - parseInt(a.needsMm))[0]
    };
    if (!passable) {
      issues.push(`At least one part cannot be carried through the ${doorW} x ${doorH} mm opening — see limitingPart.`);
    }
  }

  return { ...result, checked: true, issues };
}

/**
 * Orientation guidance for a phone-based capture. This is the part a real sensor can
 * contribute right now: the IMU tells you whether the phone is aligned to the wall,
 * and the light sensor tells you whether a camera-based scan has enough signal.
 */
export function assessCaptureConditions({ tiltDeg, lux, gyroStable }) {
  const advice = [];
  let ok = true;
  if (typeof tiltDeg === 'number') {
    if (tiltDeg > 3) {
      ok = false;
      advice.push(`Phone is ${tiltDeg.toFixed(1)} deg off the wall plane. Hold it flat against the surface — at 3 deg off, a 2 m wall picks up roughly 100 mm of error.`);
    }
  }
  if (typeof lux === 'number') {
    if (lux < 30) {
      ok = false;
      advice.push(`Only ${lux} lx ambient light. Texture-poor surfaces in low light produce drifting depth estimates; add light or use a physical tape for reference points.`);
    } else if (lux > 20000) {
      advice.push(`${Math.round(lux)} lx is bright enough to blow out a specular wall; change the angle to avoid the reflection.`);
    }
  }
  if (gyroStable === false) {
    ok = false;
    advice.push('Gyro did not settle. Stop moving before capturing — motion during capture is the main source of scale error.');
  }
  return { ok, advice };
}
